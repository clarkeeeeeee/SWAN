/*
 * Copyright 2018-2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * 
 * You may not use this file except in compliance with the terms and conditions set forth in the
 * accompanying LICENSE.TXT file. THESE MATERIALS ARE PROVIDED ON AN "AS IS" BASIS. AMAZON SPECIFICALLY
 * DISCLAIMS, WITH RESPECT TO THESE MATERIALS, ALL WARRANTIES, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
 * THE IMPLIED WARRANTIES OF MERCHANTABI LITY, FITNESS FOR A PARTICULAR PURPOSE, AND NON-INFRINGEMENT.
 */

/*
    Note: this application is a sample only. It may omit functionality that would be required in a
    real device. The application's source code is structured to maximize illustrative utility, and not
    to suggest a reference design for any category of device or to provide a definitive framework for
    a device's firmware.
*/

/*
 *   ACK Host MCU sample application showing implementation of a Smart Light.
 *   The usage of the following capabilities is demonstrated:
 *    * Power - powers the light on/off.
 *    * Brightness - controls the brightness of the LED using PWM output.
 *    * Mode (Shutoff time) - shuts the light of after the specified time.
 *    * Mode (Blinking Speed) - sets the light blinking speed.
*/

#include "ack.h"
#include "ack_brightness_controller.h"
#include "ack_user_device.h"
#include "ack_logging.h"
#include "ack_mode_controller.h"
#include "ack_power_controller.h"
#include "ack_range_controller.h"
#include "ack_toggle_controller.h"
#include "ack_dash_replenishment.h"

#include <inttypes.h>
#include <stdint.h>


#include "top.h"
#include "dev.h"
#include "heating.h"
#include "off_base.h"
#include "low_water.h"
#include "remote_counter.h"
#include "keep_warm.h"


#include "connect.h"
#include "smg.h"
#include "metrics.h"
#include "board.h"
#include "ack_metrics.h"

#ifdef NEW_APP_API
static uint16_t gDash_BoilCountsRemain;
void Init_gDash_BoilCountsRemain(uint16_t ctx)
{
	gDash_BoilCountsRemain=ctx;
}
#endif

// Component name used for logs originated from this file.
#define LOG_COMPONENT_NAME "KettleApplication"

// Forward declarations.

bool AddPresetWithBoilProperty(uint32_t propertyOrdinal, unsigned propertyFlags);
bool AddPresetWithoutBoilProperty(uint32_t propertyOrdinal, unsigned propertyFlags); 

bool AddPowerProperty(uint32_t propertyOrdinal, unsigned propertyFlags);
bool AddLightBrightnessProperty(uint32_t propertyOrdinal, unsigned propertyFlags);
bool AddLightTimerProperty(uint32_t propertyOrdinal, unsigned propertyFlags);
bool AddLightBlinkingProperty(uint32_t propertyOrdinal, unsigned propertyFlags);
ACKPropertiesBits_t ResetBlinkingMode(void);
ACKPropertiesBits_t ResetShutdownTimeMode(void);
void ProcessSetSpeedModeDirective(int32_t correlationId, bool isDelta, int32_t value);
void ProcessSetTimerModeDirective(int32_t correlationId, bool isDelta, int32_t value);
ACKPropertiesBits_t SetKettleToOnIfOff(void);
void CheckShutoffTimer(void);
void Hardware_TurnLightOn(void);
void Hardware_TurnLightOff(void);


void ProcessSetTempDegDirective(int32_t correlationId, bool isDelta, int32_t value);
bool AddTempDegProperty(uint32_t propertyOrdinal, unsigned propertyFlags);

//PreSet
void ProcessSetPreSetDirective(int32_t correlationId, bool isDelta, int32_t value);
bool AddPreSetProperty(uint32_t propertyOrdinal, unsigned propertyFlags);
//TempSet
void ProcessSetTempSetDirective(int32_t correlationId, bool isDelta, int32_t value);
bool AddTempSetProperty(uint32_t propertyOrdinal, unsigned propertyFlags);
//Status
bool AddStatusProperty(uint32_t propertyOrdinal, unsigned propertyFlags);
//CurrentTemperature
bool AddCurrentTemperatureProperty(uint32_t propertyOrdinal, unsigned propertyFlags);
//KeepWarmMinutes
bool AddKeepWarmMinutesProperty(uint32_t propertyOrdinal, unsigned propertyFlags);
void ProcessSetKeepWarmMinutesDirective(int32_t correlationId, bool isDelta, int32_t value);
//gbKeepWarmSwitch
bool AddKeepWarmSwitchProperty(uint32_t propertyOrdinal, unsigned propertyFlags);
void ProcessSetKeepWarmSwitchDirective(int32_t correlationId, bool state);
//gbSwan
bool AddSwanProperty(uint32_t propertyOrdinal, unsigned propertyFlags);
void ProcessSetSwanDirective(int32_t correlationId, bool state);
//boil counts
bool AddBoilCountsProperty(uint32_t propertyOrdinal, unsigned propertyFlags);
bool AddBoilCountsResetProperty(uint32_t propertyOrdinal, unsigned propertyFlags);
bool AddInventory_BoilCountsProperty(uint32_t propertyOrdinal, unsigned propertyFlags); 


// Application-specific property ordinals.
#define PROPERTY_POWER_STATE 0 // Power controller ordinal.
#define PROPERTY_BRIGHTNESS 1  // Brightness controller ordinal.
#define PROPERTY_TIMER_MODE 2  // Timer (mode) controller ordinal.
#define PROPERTY_SPEED_MODE 3  // Blinking (mode) controller ordinal.

#define PROPERTY_TEMP_DEG 	8
#define PROPERTY_PRE_SET 	9
#define PROPERTY_TEMP_SET 	10
#define PROPERTY_STATUS 	11
#define PROPERTY_CURRENT_TEMPERATURE 	12
#define PROPERTY_KEEP_WARM_MINUTES 		13
#define PROPERTY_PRESET_WITH_BOIL 		14
#define PROPERTY_PRESET_WITHOUT_BOIL 	15

#define PROPERTY_KEEP_WARM 				13
#define PROPERTY_SWAN	 				15

#ifdef NEW_APP_API
#define PROPERTY_BOIL_COUNTS				17
#define PROPERTY_BOIL_COUNTS_RESET			16
#define PROPERTY_INVENTORY_BOIL_COUNTS		18
#endif
// Maps an Alexa capability in this application to a routine used to add the capability's properties
// when an outbound event is being built.
ACKPropertyTableEntry_t ACKUser_PropertyTable[] =
{
    { PROPERTY_POWER_STATE, AddPowerProperty },
	{ PROPERTY_PRE_SET, AddPreSetProperty },
//	{ PROPERTY_TEMP_SET, AddTempSetProperty },
	{ PROPERTY_STATUS, AddStatusProperty },
	{ PROPERTY_CURRENT_TEMPERATURE, AddCurrentTemperatureProperty },
	{ PROPERTY_KEEP_WARM, AddKeepWarmSwitchProperty },
	{ PROPERTY_SWAN, AddSwanProperty },
	#if PCB_US
	{ PROPERTY_TEMP_DEG, AddTempDegProperty },
	#endif
	#ifdef NEW_APP_API
	{ PROPERTY_BOIL_COUNTS, AddBoilCountsProperty },
	{ PROPERTY_BOIL_COUNTS_RESET, AddBoilCountsResetProperty },
	{ PROPERTY_INVENTORY_BOIL_COUNTS, AddInventory_BoilCountsProperty },
	#endif
    { 0, NULL }
};

// All Light related properties.
static const ACKPropertiesBits_t c_lightPropertiesBits =
    ACK_PROPERTY_BIT(PROPERTY_POWER_STATE)
//	| ACK_PROPERTY_BIT(PROPERTY_TEMP_SET)
	| ACK_PROPERTY_BIT(PROPERTY_STATUS)
	| ACK_PROPERTY_BIT(PROPERTY_CURRENT_TEMPERATURE)
	| ACK_PROPERTY_BIT(PROPERTY_KEEP_WARM)
	| ACK_PROPERTY_BIT(PROPERTY_SWAN)
	#if PCB_US
	| ACK_PROPERTY_BIT(PROPERTY_TEMP_DEG)
	#endif
	#ifdef NEW_APP_API
	| ACK_PROPERTY_BIT(PROPERTY_BOIL_COUNTS_RESET)
	#endif
	//| ACK_PROPERTY_BIT(PROPERTY_PRESET_WITH_BOIL)
	//| ACK_PROPERTY_BIT(PROPERTY_PRESET_WITHOUT_BOIL)
	| ACK_PROPERTY_BIT(PROPERTY_PRE_SET);

// Mode controller instance ids.
// When multiple mode controllers are registered, each is assigned with a unique instance id.
// DO NOT CHANGE the instance ids, since they must match the device type configuration.
#define MODE_INSTANCE_TIMER 12
#define MODE_INSTANCE_BLINKING 20

#if PCB_US
#define MODE_INSTANCE_TEMP_DEG 	19
#endif

#define MODE_INSTANCE_PRE_SET 	13
#define MODE_INSTANCE_STATUS 	12
#define RANGE_INSTANCE_TEMP_SET 	10
#define RANGE_INSTANCE_CURRENT_TEMPERATURE 	11
#define MODE_INSTANCE_KEEP_WARM_MINUTES 	14
#define TOGGLE_INSTANCE_KEEP_WARM 	14
#define TOGGLE_INSTANCE_SWAN	 	15
#define TOGGLE_INSTANCE_PRE_SET_WITH_BOIL 		16
#define TOGGLE_INSTANCE_PRE_SET_WITHOUT_BOIL 	17

#ifdef NEW_APP_API
#define RANGE_INSTANCE_BOIL_COUNTS				17
#define	TOGGLE_INSTANCE_BOIL_COUNTS_RESET		16
#define	DASH_INSTANCE_BOIL_COUNTS				18
#endif

// Timer modes.
// Same as with the instance ids, these values must match the device type configuration.
#define TIMER_MODE_NONE 0
#define TIMER_MODE_5_MIN 1
#define TIMER_MODE_10_MIN 2
#define TIMER_MODE_60_MIN 3

// Blinking modes.
// Same as with the instance ids, these values must match the device type configuration.


#define MAXIMUM_BRIGHTNESS 100
#define MINIMUM_BRIGHTNESS 0

// Global variables.
uint32_t g_previousTick = 0;   // Previous Tick (used by timers logic).
uint32_t g_timerGap = 0;   // Milliseconds since the last loop.
uint8_t g_brightness = MAXIMUM_BRIGHTNESS; // Brightness.
uint8_t g_blinkingMode = SPEED_MODE_NONE;    // Blinking mode.
uint8_t g_timerMode = TIMER_MODE_NONE;   // Timer mode.
int32_t g_timerModeCountdown = 0;  // Timer countdown.
int32_t g_blinkingCountdown = 0; // Blinking countdown.
bool g_blinkingPower = false;     // Indicates power for blinking mode.





const char CanUseAppErr[]="app ctrl is not valid now";



#ifdef NEW_APP_API
void SendChangeReportIfgDash_BoilCountsRemainlsChanged(void)
{
    ACKPropertiesBits_t changedPropertiesBits = 0;

	if (gDash_BoilCountsRemain != gBoilCounts)
	{
		ACK_SendUsageReportCountMetric(
			"gDash_BoilCountsRemain have changed",
			gDash_BoilCountsRemain - gBoilCounts);

		changedPropertiesBits |= ACK_PROPERTY_BIT(PROPERTY_INVENTORY_BOIL_COUNTS);

		gDash_BoilCountsRemain = gBoilCounts;
	}
    if (changedPropertiesBits)
    {
        ACK_SendChangeReport(ack_alexa_change_report_cause_type_periodic_poll, changedPropertiesBits, 0);
		printf("SendChangeReportIfgDash_BoilCountsRemainlsChanged gDash_BoilCountsRemain=[%3d]",gDash_BoilCountsRemain);
    }
}
#endif

// Called once, for one-time initialization.
void setup(void)
{
    // Initialize ACK Host MCU Implementation Core.
    ACK_Initialize();

    // Initialize the previous tick.
    g_previousTick = ACKPlatform_TickCount();
}

// Called over and over, for main processing.
void loop(void)
{
    ACK_Process();

    // Timers are checked every loop iteration.
//    CheckShutoffTimer();

    // In order to work with timers, we save time of the previous tick and calculate the difference.
    uint32_t newTick = ACKPlatform_TickCount();
    g_timerGap = newTick - g_previousTick;
    g_previousTick = newTick;
	
	#ifdef NEW_APP_API
	SendChangeReportIfgDash_BoilCountsRemainlsChanged();
	#endif
}


void Alexa_SendChangeReportDueToLocalControl(void)
{
    // A change report has both changed properties and "related" properties. Since we have only the one
    // property (power state), and we're here to report that it changed, there are never any "related"
    // properties.
	
	ACK_SendChangeReport(
        ack_alexa_change_report_cause_type_physical_interaction,
        c_lightPropertiesBits,
        0);
}

#ifdef NEW_APP_API
void Alexa_SendChangeReport_BoilCounts(void)
{
    // A change report has both changed properties and "related" properties. Since we have only the one
    // property (power state), and we're here to report that it changed, there are never any "related"
    // properties.
	
	ACK_SendChangeReport(
        ack_alexa_change_report_cause_type_physical_interaction,
        ACK_PROPERTY_BIT(PROPERTY_BOIL_COUNTS)
		| ACK_PROPERTY_BIT(PROPERTY_INVENTORY_BOIL_COUNTS),
        0);
}
#endif
// We designate the device "in use" if (simulated) power is on.
bool ACKUser_IsDeviceInUse(void)
{
    return gbPower;
}

// Power Controller directive callback, turns on a small LED.

void ReTurnOnDisplay()
{
	gbDisplay=true;
	TurnOffDispDelayTicks=TURN_OFF_DISP_DELAY_TICKS;
}

void ACKUser_OnPowerControllerDirective(int32_t correlationId, bool powerOn)
{
    ACKPropertiesBits_t changedPropertiesBits = 0;
    bool changed;
	
//	if(gbLowWater && !LowWaterRetStatus())
//	{
//		gbforceReport=true;
//		LowWaterRemainTicksReload();
//		return;
//	}
//	if(gbLowWater)
//	{
//		gbforceReport=true;
//		if(!LowWaterRetStatus())
//			LowWaterRemainTicksReload();
//		return;
//	}
	if(gbOffBase && powerOn)
	{
		gbforceReport=true;
		Smg_ReloadOffBaseDispTicks(true);
		return;
	}
//	Smg_ReloadOffBaseDispTicks(false);
	
	if(!CanUseApp || !gbRemoteComand)
	{
		return;
		
		ACK_CompleteDirectiveWithSimpleError(
		correlationId,
		ack_alexa_error_type_not_in_operation,
		CanUseAppErr);
		gbforceReport=true;
		
		return;
	}

#ifdef ACK_LOGGING
    ACK_WriteLogFormatted(
        acp_log_level_info,
        LOG_COMPONENT_NAME,
        "Handling power directive: %s",
        powerOn ? "ON" : "OFF");
#endif

    ACK_DEBUG_PRINT_I("Controlling LED with power controller directive; light %s", powerOn ? "ON" : "OFF");

    changed = (0 == gbPower) != (0 == powerOn);
    if (changed)
    {
		ReTurnOnDisplay();
		BuzzerTime=BuzzerTimeUnit=BUZZER_TIME;
        changedPropertiesBits |= ACK_PROPERTY_BIT(PROPERTY_POWER_STATE);
        if (powerOn)
        {
            gbDisplay=true;
			DevPowerOn();
			
//			gbRemotePowerOn=true;
//			gbMetrics__kettle_start_time=true;
//			Metrics_KettleCycleCountAdd();
//			gbMetrics__kettle_start_method=true;
//			Metrics__kettle_start_method=eMetrics_KettleStartMethod_remote;
//			gbMetrics__kettle_target_temp=true;
        }
        else
        {
			ClearPreSetConfirm();
			if(DevPowerOff())
			{
//				Metrics_SetkettleEndMethod(eMetrics_kettleEndMethod_remote);
			}
        }
    }

    // Indicate that processing the directive completed successfully,
    // including a change report if and only if the power state actually changed.
    ACK_CompleteDirectiveWithSuccess(
        correlationId,ACK_PROPERTY_BIT(PROPERTY_POWER_STATE),c_lightPropertiesBits);/*
        c_lightPropertiesBits,
        changedPropertiesBits);*/
}


ACKPropertiesBits_t ResetShutdownTimeMode(void)
{
    if (g_timerMode != TIMER_MODE_NONE)
    {
        g_timerMode = TIMER_MODE_NONE;
        return ACK_PROPERTY_BIT(PROPERTY_TIMER_MODE);
    }

    return 0;
}

ACKPropertiesBits_t ResetBlinkingMode(void)
{
    if (g_blinkingMode != SPEED_MODE_NONE)
    {
        g_blinkingMode = SPEED_MODE_NONE;
        g_blinkingCountdown = 0;
        return ACK_PROPERTY_BIT(PROPERTY_SPEED_MODE);
    }

    return 0;
}

void ACKUser_OnBrightnessControllerDirective(int32_t correlationId, bool isDelta, int32_t value)
{
    ACKPropertiesBits_t changedPropertiesBits = 0;

#ifdef ACK_LOGGING
    ACK_WriteLogFormatted(
        acp_log_level_info,
        LOG_COMPONENT_NAME,
        "Handling Set Brightness directive: %d %"PRIi32,
        isDelta,
        value);
#endif

    // isDelta means that user asked to increase or decrease the brightness.
    if (isDelta)
    {
        if (g_brightness + value > MAXIMUM_BRIGHTNESS)
        {
            if (g_brightness != MAXIMUM_BRIGHTNESS)
            {
                g_brightness = MAXIMUM_BRIGHTNESS;
                changedPropertiesBits |= ACK_PROPERTY_BIT(PROPERTY_BRIGHTNESS);
            }
        }
        else if (g_brightness + value < MINIMUM_BRIGHTNESS)
        {
            if (g_brightness != MINIMUM_BRIGHTNESS)
            {
                g_brightness = MINIMUM_BRIGHTNESS;
                changedPropertiesBits |= ACK_PROPERTY_BIT(PROPERTY_BRIGHTNESS);
            }
        }
        else
        {
            g_brightness += value;
            changedPropertiesBits |= ACK_PROPERTY_BIT(PROPERTY_BRIGHTNESS);
        }
    }
    else
    {
        if ((value > MAXIMUM_BRIGHTNESS) || (value < MINIMUM_BRIGHTNESS))
        {
            ACK_CompleteDirectiveWithOutOfRangeError(
                correlationId,
                MINIMUM_BRIGHTNESS,
                MAXIMUM_BRIGHTNESS,
                NULL);

            return;
        }

        if (g_brightness != value)
        {
            g_brightness = value;
            changedPropertiesBits |= ACK_PROPERTY_BIT(PROPERTY_BRIGHTNESS);
        }
    }

    if (changedPropertiesBits)
    {
        // If power was off, turn it on.
        if (!gbPower)
        {
            gbPower = true;
            changedPropertiesBits |= ACK_PROPERTY_BIT(PROPERTY_POWER_STATE);
        }

        Hardware_TurnLightOn();
    }


    // Indicate that processing the directive completed successfully,
    // including a change report if and only if the brightness state actually changed.
    ACK_CompleteDirectiveWithSuccess(
        correlationId,
        c_lightPropertiesBits,
        changedPropertiesBits);
}

ACKPropertiesBits_t SetKettleToOnIfOff(void)
{
    if (!gbPower)
    {
        gbRemotePowerOn=true;
		
		gbPower = true;
		DevClrTempSetTicks();
		KeepWarmReloadKeepWarmTime();
        return ACK_PROPERTY_BIT(PROPERTY_POWER_STATE);
    }

    return 0;
}

// Example: Mode Controller.
// In this example two instances are supported:
//   12 to control light timer
//   13 to control light blinking mode
void ACKUser_OnModeControllerDirective(int32_t correlationId, uint32_t instance, bool isDelta, int32_t value)
{
#ifdef ACK_LOGGING
    ACK_WriteLogFormatted(
        acp_log_level_info,
        LOG_COMPONENT_NAME,
        "Handling Mode directive: %"PRIu32" isDelta: %u value: %d",
        instance,
        isDelta,
        value);
#endif

    switch (instance)
    {
	
	case MODE_INSTANCE_PRE_SET:
        ProcessSetPreSetDirective(correlationId, isDelta, value);
        break;
	
	#if PCB_US
	case MODE_INSTANCE_TEMP_DEG:
        ProcessSetTempDegDirective(correlationId, isDelta, value);
        break;
	#endif
	
//	case MODE_INSTANCE_KEEP_WARM_MINUTES:
//		ProcessSetKeepWarmMinutesDirective(correlationId, isDelta, value);
//		break;
	
    default:
        ACK_DEBUG_PRINT_E("Mode controller - not supported instance id: %u", instance);
        break;
    }
}
void ACKUser_OnRangeControllerDirective(
    int32_t correlationId,
    uint32_t instance,
    bool isDelta,
    double value,
    bool isDefaultDelta)
{
#ifdef ACK_LOGGING
    ACK_WriteLogFormatted(
        acp_log_level_info,
        LOG_COMPONENT_NAME,
        "Handling Range directive: %"PRIu32" isDelta: %u value: %d",
        instance,
        isDelta,
        value);
#endif

    switch (instance)
    {
		case RANGE_INSTANCE_TEMP_SET:
			ProcessSetTempSetDirective(correlationId, isDelta, value);
			break;
		
		
    default:
        ACK_DEBUG_PRINT_E("Range controller - not supported instance id: %u", instance);
        break;
    }
}



static void ProcessSetPresetWithBoilDirective(int32_t correlationId, bool state)
{
    ACKPropertiesBits_t changedPropertiesBits = 0;
	uint8_t pre_set=PreSet;

	if(!CanUseApp || gbLowWater)
	{
//		if(gbLowWater)
//			LowWaterRemainTicksReload();
		
		ACK_CompleteDirectiveWithSimpleError(
		correlationId,
		ack_alexa_error_type_not_in_operation,
		CanUseAppErr);
		gbforceReport=true;
		
		return;
	}

   
    {
        if (gbPresetWithBoil != state)
        {
            gbPresetWithBoil = state;
            changedPropertiesBits |= ACK_PROPERTY_BIT(PROPERTY_PRESET_WITH_BOIL);
        }
    }

    if (changedPropertiesBits)
    {
    }

    ACK_CompleteDirectiveWithSuccess(
        correlationId,ACK_PROPERTY_BIT(PROPERTY_PRESET_WITH_BOIL),c_lightPropertiesBits);/*
        c_lightPropertiesBits,
        changedPropertiesBits);*/
}
static void ProcessSetPresetWithoutBoilDirective(int32_t correlationId, bool state)
{
    ACKPropertiesBits_t changedPropertiesBits = 0;
	uint8_t pre_set=PreSet;

	if(!CanUseApp || gbLowWater)
	{
//		if(gbLowWater)
//			LowWaterRemainTicksReload();
		
		ACK_CompleteDirectiveWithSimpleError(
		correlationId,
		ack_alexa_error_type_not_in_operation,
		CanUseAppErr);
		gbforceReport=true;
		
		return;
	}

    
    {
	if (gbPresetWithoutBoil != state)
	{
		gbPresetWithoutBoil = state;
		changedPropertiesBits |= ACK_PROPERTY_BIT(PROPERTY_PRESET_WITHOUT_BOIL);
	}
    }

    if (changedPropertiesBits)
    {
		BuzzerTime=BuzzerTimeUnit=BUZZER_TIME;
    }

    ACK_CompleteDirectiveWithSuccess(
        correlationId,ACK_PROPERTY_BIT(PROPERTY_PRESET_WITHOUT_BOIL),c_lightPropertiesBits);/*
        c_lightPropertiesBits,
        changedPropertiesBits);*/
}
void ProcessSetKeepWarmSwitchDirective(int32_t correlationId, bool state)
{
    ACKPropertiesBits_t changedPropertiesBits = 0;

	#if PCB_US
	if(!CanUseApp || (state && PreSet>10))
	#else
	if(!CanUseApp || (state && PreSet==6))
	#endif
	{
		BuzzerTimeUnit=BUZZER_TIME;
		BuzzerTime=BuzzerTimeUnit*3;
		
		ACK_CompleteDirectiveWithSimpleError(
		correlationId,
		ack_alexa_error_type_not_in_operation,
		CanUseAppErr);
		gbforceReport=true;
		return;
	}
   
	if (gbKeepWarmSwitch != state)
	{
		gbKeepWarmSwitch = state;
		changedPropertiesBits |= ACK_PROPERTY_BIT(PROPERTY_KEEP_WARM);
		BuzzerTime=BuzzerTimeUnit=BUZZER_TIME;
	}

    if (changedPropertiesBits)
    {
		if(KeepWarmRetStatus() && !gbKeepWarmSwitch)
			DevPowerOff();
		ReTurnOnDisplay();
    }

    ACK_CompleteDirectiveWithSuccess(
        correlationId,ACK_PROPERTY_BIT(PROPERTY_KEEP_WARM),c_lightPropertiesBits);/*
        c_lightPropertiesBits,
        changedPropertiesBits);*/
}
void ProcessSetSwanDirective(int32_t correlationId, bool state)
{
    ACKPropertiesBits_t changedPropertiesBits = 0;

	if(!CanUseApp)// || (state && PreSet==6))
	{
		BuzzerTimeUnit=BUZZER_TIME;
		BuzzerTime=BuzzerTimeUnit*3;
		
		ACK_CompleteDirectiveWithSimpleError(
		correlationId,
		ack_alexa_error_type_not_in_operation,
		CanUseAppErr);
		gbforceReport=true;
		return;
	}
   
	if (gbSwan != state)
	{
		gbSwan = state;
		changedPropertiesBits |= ACK_PROPERTY_BIT(PROPERTY_SWAN);
		BuzzerTime=BuzzerTimeUnit=BUZZER_TIME;
	}

    if (changedPropertiesBits)
    {
		if(gbSwan)
		{
//			UpdateTempSet_CausePreSet(6);
//			UpdateTempSet();
//			ReTurnOnDisplay();
//			gbKeepWarmSwitch=false;
			
			gbDisplay=true;
			DevPowerOn();
			ReTurnOnDisplay();
		}
		#if(!SWAN_SYNC_PRESET)
		else
		{
			ClearPreSetConfirm();
			if(DevPowerOff())
			{
//				Metrics_SetkettleEndMethod(eMetrics_kettleEndMethod_remote);
			}
		}
		#endif
    }
	
//	gbSwan=1;

    ACK_CompleteDirectiveWithSuccess(
        correlationId,ACK_PROPERTY_BIT(PROPERTY_SWAN),c_lightPropertiesBits);/*
        c_lightPropertiesBits,
        changedPropertiesBits);*/
}
#ifdef NEW_APP_API
void ProcessSetBoilCountsResetDirective(int32_t correlationId, bool state)
{
    ACKPropertiesBits_t changedPropertiesBits = 0;

	if(!CanUseApp)// || (state && PreSet==6))
	{
		BuzzerTimeUnit=BUZZER_TIME;
		BuzzerTime=BuzzerTimeUnit*3;
		
		ACK_CompleteDirectiveWithSimpleError(
		correlationId,
		ack_alexa_error_type_not_in_operation,
		CanUseAppErr);
		gbforceReport=true;
		return;
	}
   
	if (gbBoilTo100Degree_CountsReset != state)
	{
		gbBoilTo100Degree_CountsReset = state;
		changedPropertiesBits |= ACK_PROPERTY_BIT(PROPERTY_BOIL_COUNTS_RESET);
		BuzzerTime=BuzzerTimeUnit=BUZZER_TIME;
	}

    if (changedPropertiesBits)
    {
		if(gbBoilTo100Degree_CountsReset)
		{
			gbDisplay=true;
			ReTurnOnDisplay();
			gBoilCounts=DEFAULT_BOIL_100_DEGREE_COUNTS;
		}
    }

    ACK_CompleteDirectiveWithSuccess(
        correlationId,ACK_PROPERTY_BIT(PROPERTY_BOIL_COUNTS_RESET),c_lightPropertiesBits);/*
        c_lightPropertiesBits,
        changedPropertiesBits);*/
}
#endif
void ACKUser_OnToggleControllerDirective(int32_t correlationId, uint32_t instance, bool state)
{
#ifdef ACK_LOGGING
    ACK_WriteLogFormatted(
        acp_log_level_info,
        LOG_COMPONENT_NAME,
        "Handling Range directive: %"PRIu32" isDelta: %u value: %d",
        instance,
        isDelta,
        value);
#endif

    switch (instance)
    {
		case TOGGLE_INSTANCE_KEEP_WARM:
			ProcessSetKeepWarmSwitchDirective(correlationId,  state);
			break;
		case TOGGLE_INSTANCE_SWAN:
			ProcessSetSwanDirective(correlationId,  state);
			break;
		
		#ifdef NEW_APP_API
		case TOGGLE_INSTANCE_BOIL_COUNTS_RESET:
			ProcessSetBoilCountsResetDirective(correlationId,  state);
			break;
		#endif
//		case TOGGLE_INSTANCE_PRE_SET_WITH_BOIL:
//			ProcessSetPresetWithBoilDirective(correlationId,  state);
//			break;
//		case TOGGLE_INSTANCE_PRE_SET_WITHOUT_BOIL:
//			ProcessSetPresetWithoutBoilDirective(correlationId,  state);
//			break;
		
    default:
        ACK_DEBUG_PRINT_E("Range controller - not supported instance id: %u", instance);
        break;
    }
}



void ProcessSetTimerModeDirective(int32_t correlationId, bool isDelta, int32_t value)
{
    ACKPropertiesBits_t changedPropertiesBits = 0;
	
	if(!CanUseApp || !gbRemoteComand || gbLowWater)
	{
		ACK_CompleteDirectiveWithSimpleError(
		correlationId,
		ack_alexa_error_type_not_in_operation,
		CanUseAppErr);
		gbforceReport=true;
		return;
	}

    if (isDelta)
    {
        if ((g_timerMode + value > TIMER_MODE_60_MIN) || (g_timerMode + value < TIMER_MODE_NONE))
        {
            // The user tries to get value out of supported range.
            // Complete directive with an error.
            ACK_CompleteDirectiveWithOutOfRangeError(
                correlationId,
                TIMER_MODE_NONE,
                TIMER_MODE_60_MIN,
                NULL);

            return;
        }

        g_timerMode += value;
        changedPropertiesBits |= ACK_PROPERTY_BIT(PROPERTY_TIMER_MODE);
    }
    else
    {
        if (g_timerMode != value)
        {
            g_timerMode = value;
            changedPropertiesBits |= ACK_PROPERTY_BIT(PROPERTY_TIMER_MODE);
        }
    }

    if (changedPropertiesBits)
    {
        // If power was off, turn it on.
        changedPropertiesBits |= SetKettleToOnIfOff();

        // Set timer countdown
        switch (g_timerMode)
        {
        case TIMER_MODE_5_MIN:
            g_timerModeCountdown = 300000;
            break;
        case TIMER_MODE_10_MIN:
            g_timerModeCountdown = 600000;
            break;
        case TIMER_MODE_60_MIN:
            g_timerModeCountdown = 3600000;
            break;
        default:
            g_timerModeCountdown = 0;
            break;
        }
    }

    ACK_CompleteDirectiveWithSuccess(
        correlationId,
        c_lightPropertiesBits,
        changedPropertiesBits);
}

void ProcessSetSpeedModeDirective(int32_t correlationId, bool isDelta, int32_t value)
{
    ACKPropertiesBits_t changedPropertiesBits = 0;

	if(!CanUseApp || !gbRemoteComand || gbLowWater)
	{
		ACK_CompleteDirectiveWithSimpleError(
		correlationId,
		ack_alexa_error_type_not_in_operation,
		CanUseAppErr);
		gbforceReport=true;
		
		return;
	}
	
    if (isDelta)
    {
        if ((g_blinkingMode + value > SPEED_MODE_HIGH) || (g_blinkingMode + value < SPEED_MODE_NONE))
        {
            // The user tries to get value out of supported range.
            // Complete directive with an error.
            ACK_CompleteDirectiveWithOutOfRangeError(
                correlationId,
                SPEED_MODE_NONE,
                SPEED_MODE_HIGH,
                NULL);

            return;
        }

        g_blinkingMode += value;
        changedPropertiesBits |= ACK_PROPERTY_BIT(PROPERTY_SPEED_MODE);
    }
    else
    {
        if (g_blinkingMode != value)
        {
            g_blinkingMode = value;
            changedPropertiesBits |= ACK_PROPERTY_BIT(PROPERTY_SPEED_MODE);
        }
    }

    if (changedPropertiesBits)
    {
        // If power was off, turn it on.
        changedPropertiesBits |= SetKettleToOnIfOff();
        g_blinkingPower = true;
    }

    ACK_CompleteDirectiveWithSuccess(
        correlationId,
        c_lightPropertiesBits,
        changedPropertiesBits);
}







void ProcessSetPreSetDirective(int32_t correlationId, bool isDelta, int32_t value)
{
    ACKPropertiesBits_t changedPropertiesBits = 0;
	uint8_t pre_set=PreSet;

	if(!CanUseApp || gbLowWater)
	{
//		if(gbLowWater)
//			LowWaterRemainTicksReload();
		
		ACK_CompleteDirectiveWithSimpleError(
		correlationId,
		ack_alexa_error_type_not_in_operation,
		CanUseAppErr);
		gbforceReport=true;
		
		return;
	}

    if (isDelta)
    {
        if ((pre_set + value > PRE_SET_MAX) || (pre_set + value < PRE_SET_MIN))
        {
            // The user tries to get value out of supported range.
            // Complete directive with an error.
            ACK_CompleteDirectiveWithOutOfRangeError(
                correlationId,
                PRE_SET_MIN,
                PRE_SET_MAX,
                NULL);

            return;
        }

        pre_set += value;
        changedPropertiesBits |= ACK_PROPERTY_BIT(PROPERTY_PRE_SET);
    }
    else
    {
        if (pre_set != value)
        {
            pre_set = value;
            changedPropertiesBits |= ACK_PROPERTY_BIT(PROPERTY_PRE_SET);
        }
    }

    if (changedPropertiesBits)
    {
        // If power was off, turn it on.
//        changedPropertiesBits |= SetKettleToOnIfOff();
		
		#if PCB_US
		if(pre_set&1)
			gTempratureUnit=eTempratureUnit_Celsius;
		else
			gTempratureUnit=eTempratureUnit_Fahrenheit;
		#else
		gTempratureUnit=eTempratureUnit_Celsius;
		#endif
		BuzzerTime=BuzzerTimeUnit=BUZZER_TIME;
		UpdateTempSet_CausePreSet(pre_set);
		UpdateTempSet();
		ReTurnOnDisplay();
		
		#if PCB_US
		if(pre_set!=11 && pre_set!=12)
		#else
		if(pre_set!=6)
		#endif
		{
			gbKeepWarmSwitch=true;
			#if(SWAN_SYNC_PRESET)
			gbSwan=false;
			#endif
		}
		else
		{
			gbKeepWarmSwitch=false;
			#if(SWAN_SYNC_PRESET)
			gbSwan=true;
			#endif
		}
    }

    ACK_CompleteDirectiveWithSuccess(
        correlationId,ACK_PROPERTY_BIT(PROPERTY_PRE_SET),c_lightPropertiesBits);/*
        c_lightPropertiesBits,
        changedPropertiesBits);*/
}


void ProcessSetTempDegDirective(int32_t correlationId, bool isDelta, int32_t value)
{
    ACKPropertiesBits_t changedPropertiesBits = 0;
	uint8_t pre_set=PreSet;

	if(!CanUseApp || gbLowWater)
	{
		ACK_CompleteDirectiveWithSimpleError(
		correlationId,
		ack_alexa_error_type_not_in_operation,
		CanUseAppErr);
		gbforceReport=true;
		return;
	}

    if (isDelta)
    {
        if ((gTempratureUnit + value > eTempratureUnit_Fahrenheit) || (gTempratureUnit + value < eTempratureUnit_Celsius))
        {
            // The user tries to get value out of supported range.
            // Complete directive with an error.
            ACK_CompleteDirectiveWithOutOfRangeError(
                correlationId,
                eTempratureUnit_Celsius,
                eTempratureUnit_Fahrenheit,
                NULL);

            return;
        }

        gTempratureUnit += value;
        changedPropertiesBits |= ACK_PROPERTY_BIT(PROPERTY_TEMP_DEG);
    }
    else
    {
        if (gTempratureUnit != value)
        {
            gTempratureUnit = value;
            changedPropertiesBits |= ACK_PROPERTY_BIT(PROPERTY_TEMP_DEG);
        }
    }

    if (changedPropertiesBits)
    {
		BuzzerTime=BuzzerTimeUnit=BUZZER_TIME;
		DevTempUnitX();
		ReTurnOnDisplay();
    }

    ACK_CompleteDirectiveWithSuccess(
        correlationId,ACK_PROPERTY_BIT(PROPERTY_TEMP_DEG),c_lightPropertiesBits);/*
        c_lightPropertiesBits,
        changedPropertiesBits);*/
}


int32_t ValidValue_ErrTempSetOutOfRange;
extern bool gbTempSet101Report;
static bool RetErrTempSetOutOfRange(int32_t value,int32_t correlationId)
{
	if(value>TEMP_CELSIUS_SET_MAX || value<TEMP_CELSIUS_SET_MIN)
	{
		ACK_CompleteDirectiveWithOutOfRangeError(
			correlationId,
			TEMP_CELSIUS_SET_MIN,
			TEMP_CELSIUS_SET_MAX,
			NULL);
		if(value>TEMP_CELSIUS_SET_MAX)
			ValidValue_ErrTempSetOutOfRange=TEMP_CELSIUS_SET_MAX;
		if(value<TEMP_CELSIUS_SET_MIN)
			ValidValue_ErrTempSetOutOfRange=TEMP_CELSIUS_SET_MIN;
//			if(ValidValue_ErrTempSetOutOfRange==TempSet)
//				gbTempSet101Report=true;
		return true;
	}
	return false;
}

void ProcessSetTempSetDirective(int32_t correlationId, bool isDelta, int32_t value)
{
    ACKPropertiesBits_t changedPropertiesBits = 0;
	int32_t value_tmp=value;
	bool bTempSetOutOfRange=false;

	if(!CanUseApp || !gbRemoteComand)
	{
//		if(gbLowWater)
//			LowWaterRemainTicksReload();
		
		ACK_CompleteDirectiveWithSimpleError(
		correlationId,
		ack_alexa_error_type_not_in_operation,
		CanUseAppErr);
		gbforceReport=true;
		
		return;
	}
	
    if (isDelta)
    {
		value_tmp+=TempSet;
		
		if (RetErrTempSetOutOfRange(value_tmp,correlationId))
        {
            gbforceReport=true;
			bTempSetOutOfRange=true;
			value_tmp=ValidValue_ErrTempSetOutOfRange;
        }
        changedPropertiesBits |= ACK_PROPERTY_BIT(PROPERTY_TEMP_SET);
    }
    else
    {
        if (RetErrTempSetOutOfRange(value_tmp,correlationId))
        {
            gbforceReport=true;
			bTempSetOutOfRange=true;
			value_tmp=ValidValue_ErrTempSetOutOfRange;
        }
		
//		if (TempSet != value_tmp)
        {
            changedPropertiesBits |= ACK_PROPERTY_BIT(PROPERTY_TEMP_SET);
        }
    }

    if (changedPropertiesBits)
    {
        // If power was off, turn it on.
//        changedPropertiesBits |= SetKettleToOnIfOff();
		
		TempSet = value_tmp;
		PreSet=6;
		#if(SWAN_SYNC_PRESET)
		gbSwan=true;
		#endif
		UpdateTempSet_CelsiusFromTempSet();
    }
	if(bTempSetOutOfRange)
	{
		return;
	}

     ACK_CompleteDirectiveWithSuccess(
        correlationId,ACK_PROPERTY_BIT(PROPERTY_TEMP_SET),c_lightPropertiesBits);/*
        c_lightPropertiesBits,
        changedPropertiesBits);*/
}


#define KEEP_WARM_TIME_MAX		12
#define KEEP_WARM_TIME_MIN		1

void ProcessSetKeepWarmMinutesDirective(int32_t correlationId, bool isDelta, int32_t value)
{
    ACKPropertiesBits_t changedPropertiesBits = 0;

//	if(!CanUseApp || !gbRemoteComand || gbLowWater)
//	{
//		if(gbLowWater)
//			LowWaterRemainTicksReload();
//		
//		ACK_CompleteDirectiveWithSimpleError(
//		correlationId,
//		ack_alexa_error_type_not_in_operation,
//		CanUseAppErr);
//		gbforceReport=true;
//		
//		return;
//	}

    if (isDelta)
    {
        if ((KeepWarmMinutes + value > KEEP_WARM_TIME_MAX) || (KeepWarmMinutes + value < KEEP_WARM_TIME_MIN))
        {
            // The user tries to get value out of supported range.
            // Complete directive with an error.
            ACK_CompleteDirectiveWithOutOfRangeError(
                correlationId,
                KEEP_WARM_TIME_MIN,
                KEEP_WARM_TIME_MAX,
                NULL);

            return;
        }

        KeepWarmMinutes += value;
        changedPropertiesBits |= ACK_PROPERTY_BIT(PROPERTY_KEEP_WARM_MINUTES);
    }
    else
    {
        if (KeepWarmMinutes != value)
        {
            KeepWarmMinutes = value;
            changedPropertiesBits |= ACK_PROPERTY_BIT(PROPERTY_KEEP_WARM_MINUTES);
        }
    }

    if (changedPropertiesBits)
    {
        KeepWarmMinutesBkp=KeepWarmMinutes;
		KeepWarmReloadKeepWarmTime();
		if(!KeepWarmMinutesBkp && KeepWarmRetStatus())
		{
			if(DevPowerOff())
				Metrics_SetkettleEndMethod(eMetrics_kettleEndMethod_remote);
			if(gbRemotePowerOn)
				gRemoteCounter++;
		}
		if(gbPower && gbReadyStatus)
			KeepWarmStart();
		// If power was off, turn it on.
//        changedPropertiesBits |= SetKettleToOnIfOff();
    }

   ACK_CompleteDirectiveWithSuccess(
        correlationId,ACK_PROPERTY_BIT(PROPERTY_KEEP_WARM_MINUTES),c_lightPropertiesBits);/*
        c_lightPropertiesBits,
        changedPropertiesBits);*/
}
// Shutoff timer will shut the device off, when timer is elapsed.
void CheckShutoffTimer(void)
{
    ACKPropertiesBits_t changedPropertiesBits = 0;

    if (g_timerMode == TIMER_MODE_NONE)
    {
        // Timer is off.
        return;
    }

    if (g_timerModeCountdown <= 0)
    {
        // Timer elapsed.
        g_timerModeCountdown = 0;
        g_timerMode = TIMER_MODE_NONE;
        gbPower = false;
        changedPropertiesBits |= ACK_PROPERTY_BIT(PROPERTY_TIMER_MODE);
        changedPropertiesBits |= ACK_PROPERTY_BIT(PROPERTY_POWER_STATE);
        changedPropertiesBits |= ResetBlinkingMode();
        Hardware_TurnLightOff();

        ACK_SendChangeReport(
            ack_alexa_change_report_cause_type_rule_trigger,
            c_lightPropertiesBits,
            changedPropertiesBits);
    }
    else
    {
        g_timerModeCountdown -= g_timerGap;
    }
}



// State-report callback.
void ACKUser_OnReportStateDirective(int32_t correlationId)
{
	
		// This sends all properties demonstrated in this application.
    ACK_CompleteStateReportWithSuccess(correlationId);
}

bool AddPowerProperty(uint32_t propertyOrdinal, unsigned propertyFlags)
{
    // Populate metadata about the property. 
    // Leave the time-of-sample-field 0 to cause the current time to be sent. 
    // Set the error margin to 10 milliseconds for illustrative purposes.
    ACKStateCommon_t common = { 0, 10, propertyFlags };
    ACKError_t error;

    error = ACK_AddPowerControllerProperty(&common, gbPower);

    if (ACK_NO_ERROR != error)
    {
        ACK_DEBUG_PRINT_E("Error %u adding power property to event", error);
        return false;
    }

    return true;
}

bool AddLightBrightnessProperty(uint32_t propertyOrdinal, unsigned propertyFlags)
{
    // Populate metadata about the property. 
    // Leave the time-of-sample-field 0 to cause the current time to be sent. 
    // Set the error margin to 10 milliseconds for illustrative purposes.
    ACKStateCommon_t common = { 0, 10, propertyFlags };
    ACKError_t error;

    error = ACK_AddBrightnessControllerProperty(&common, g_brightness);

    if (ACK_NO_ERROR != error)
    {
        ACK_DEBUG_PRINT_E("Error %u adding brightness property to event", error);
        return false;
    }

    return true;
}



bool AddKeepWarmSwitchProperty(uint32_t propertyOrdinal, unsigned propertyFlags)
{
    // Populate metadata about the property. 
    // Leave the time-of-sample-field 0 to cause the current time to be sent. 
    // Set the error margin to 10 milliseconds for illustrative purposes.
    ACKStateCommon_t common = { 0, 10, propertyFlags };
    ACKError_t error;

    error = ACK_AddToggleControllerProperty(TOGGLE_INSTANCE_KEEP_WARM,&common, gbKeepWarmSwitch);

    if (ACK_NO_ERROR != error)
    {
        ACK_DEBUG_PRINT_E("Error %u adding gbKeepWarmSwitch property to event", error);
        return false;
    }

    return true;
}
bool AddSwanProperty(uint32_t propertyOrdinal, unsigned propertyFlags)
{
    // Populate metadata about the property. 
    // Leave the time-of-sample-field 0 to cause the current time to be sent. 
    // Set the error margin to 10 milliseconds for illustrative purposes.
    ACKStateCommon_t common = { 0, 10, propertyFlags };
    ACKError_t error;

    error = ACK_AddToggleControllerProperty(TOGGLE_INSTANCE_SWAN,&common, gbSwan);

    if (ACK_NO_ERROR != error)
    {
        ACK_DEBUG_PRINT_E("Error %u adding gbSwan property to event", error);
        return false;
    }

    return true;
}
bool AddPresetWithBoilProperty(uint32_t propertyOrdinal, unsigned propertyFlags)
{
    // Populate metadata about the property. 
    // Leave the time-of-sample-field 0 to cause the current time to be sent. 
    // Set the error margin to 10 milliseconds for illustrative purposes.
    ACKStateCommon_t common = { 0, 10, propertyFlags };
    ACKError_t error;

    error = ACK_AddToggleControllerProperty(TOGGLE_INSTANCE_PRE_SET_WITH_BOIL,&common, gbPresetWithBoil);

    if (ACK_NO_ERROR != error)
    {
        ACK_DEBUG_PRINT_E("Error %u adding PreSet With Boil property to event", error);
        return false;
    }

    return true;
}
bool AddPresetWithoutBoilProperty(uint32_t propertyOrdinal, unsigned propertyFlags)
{
    // Populate metadata about the property. 
    // Leave the time-of-sample-field 0 to cause the current time to be sent. 
    // Set the error margin to 10 milliseconds for illustrative purposes.
    ACKStateCommon_t common = { 0, 10, propertyFlags };
    ACKError_t error;

    error = ACK_AddToggleControllerProperty(TOGGLE_INSTANCE_PRE_SET_WITHOUT_BOIL,&common, gbPresetWithoutBoil);

    if (ACK_NO_ERROR != error)
    {
        ACK_DEBUG_PRINT_E("Error %u adding PreSet With Boil property to event", error);
        return false;
    }

    return true;
}
bool AddPreSetProperty(uint32_t propertyOrdinal, unsigned propertyFlags)
{
    // Populate metadata about the property. 
    // Leave the time-of-sample-field 0 to cause the current time to be sent. 
    // Set the error margin to 10 milliseconds for illustrative purposes.
    ACKStateCommon_t common = { 0, 10, propertyFlags };
    ACKError_t error;

    error = ACK_AddModeControllerProperty(MODE_INSTANCE_PRE_SET,&common, PreSet);

    if (ACK_NO_ERROR != error)
    {
        ACK_DEBUG_PRINT_E("Error %u adding PreSet property to event", error);
        return false;
    }

    return true;
}
bool AddTempSetProperty(uint32_t propertyOrdinal, unsigned propertyFlags)
{
    // Populate metadata about the property. 
    // Leave the time-of-sample-field 0 to cause the current time to be sent. 
    // Set the error margin to 10 milliseconds for illustrative purposes.
    ACKStateCommon_t common = { 0, 10, propertyFlags };
    ACKError_t error;

    error = ACK_AddRangeControllerProperty(RANGE_INSTANCE_TEMP_SET,&common, TempSet);

    if (ACK_NO_ERROR != error)
    {
        ACK_DEBUG_PRINT_E("Error %u adding TempSet property to event", error);
        return false;
    }

    return true;
}
#ifdef NEW_APP_API
bool AddBoilCountsProperty(uint32_t propertyOrdinal, unsigned propertyFlags)
{
    // Populate metadata about the property. 
    // Leave the time-of-sample-field 0 to cause the current time to be sent. 
    // Set the error margin to 10 milliseconds for illustrative purposes.
    ACKStateCommon_t common = { 0, 10, propertyFlags };
    ACKError_t error;

    error = ACK_AddRangeControllerProperty(RANGE_INSTANCE_BOIL_COUNTS,&common, gBoilCounts);

    if (ACK_NO_ERROR != error)
    {
        ACK_DEBUG_PRINT_E("Error %u adding gBoilCounts property to event", error);
        return false;
    }

    return true;
}
bool AddBoilCountsResetProperty(uint32_t propertyOrdinal, unsigned propertyFlags)
{
    // Populate metadata about the property. 
    // Leave the time-of-sample-field 0 to cause the current time to be sent. 
    // Set the error margin to 10 milliseconds for illustrative purposes.
    ACKStateCommon_t common = { 0, 10, propertyFlags };
    ACKError_t error;

    error = ACK_AddToggleControllerProperty(TOGGLE_INSTANCE_BOIL_COUNTS_RESET,&common, gbBoilTo100Degree_CountsReset);

    if (ACK_NO_ERROR != error)
    {
        ACK_DEBUG_PRINT_E("Error %u adding gbBoilTo100Degree_CountsReset property to event", error);
        return false;
    }

    return true;
}
bool AddInventory_BoilCountsProperty(uint32_t propertyOrdinal, unsigned propertyFlags)
{
	ACKStateCommon_t common = { 0, 0, propertyFlags };
    ACKError_t error;
    ACKInventoryLevel_t inventoryLevel;

    // Add a property for the ink cartridge level to the event.
    inventoryLevel.Kind = ACK_INVENTORY_LEVEL_COUNT;
    inventoryLevel.Level.Count = gDash_BoilCountsRemain;

    error = ACK_AddInventoryLevelProperty(
        DASH_INSTANCE_BOIL_COUNTS,
        &common,
        &inventoryLevel);

    if (ACK_NO_ERROR != error)
    {
        ACK_DEBUG_PRINT_E("Error %u adding gDash_BoilCountsRemain property to event.", error);
        return false;
    }

	printf("----------AddInventory_BoilCountsProperty succ\r\n");
    return true;
}
#endif
bool AddCurrentTemperatureProperty(uint32_t propertyOrdinal, unsigned propertyFlags)
{
    // Populate metadata about the property. 
    // Leave the time-of-sample-field 0 to cause the current time to be sent. 
    // Set the error margin to 10 milliseconds for illustrative purposes.
    ACKStateCommon_t common = { 0, 10, propertyFlags };
    ACKError_t error;

    error = ACK_AddRangeControllerProperty(RANGE_INSTANCE_CURRENT_TEMPERATURE,&common, CurrentTemperature);

    if (ACK_NO_ERROR != error)
    {
        ACK_DEBUG_PRINT_E("Error %u adding CurrentTemperature property to event", error);
        return false;
    }

    return true;
}
bool AddKeepWarmMinutesProperty(uint32_t propertyOrdinal, unsigned propertyFlags)
{
    // Populate metadata about the property. 
    // Leave the time-of-sample-field 0 to cause the current time to be sent. 
    // Set the error margin to 10 milliseconds for illustrative purposes.
    ACKStateCommon_t common = { 0, 10, propertyFlags };
    ACKError_t error;

    error = ACK_AddModeControllerProperty(MODE_INSTANCE_KEEP_WARM_MINUTES,&common, KeepWarmMinutes);

    if (ACK_NO_ERROR != error)
    {
        ACK_DEBUG_PRINT_E("Error %u adding KeepWarmMinutes property to event", error);
        return false;
    }

    return true;
}
#if PCB_US
bool AddTempDegProperty(uint32_t propertyOrdinal, unsigned propertyFlags)
{
    // Populate metadata about the property. 
    // Leave the time-of-sample-field 0 to cause the current time to be sent. 
    // Set the error margin to 10 milliseconds for illustrative purposes.
    ACKStateCommon_t common = { 0, 10, propertyFlags };
    ACKError_t error;

    error = ACK_AddModeControllerProperty(MODE_INSTANCE_TEMP_DEG,&common, gTempratureUnit);

    if (ACK_NO_ERROR != error)
    {
        ACK_DEBUG_PRINT_E("Error %u adding gTempratureUnit property to event", error);
        return false;
    }

    return true;
}
#endif
bool AddStatusProperty(uint32_t propertyOrdinal, unsigned propertyFlags)
{
    // Populate metadata about the property. 
    // Leave the time-of-sample-field 0 to cause the current time to be sent. 
    // Set the error margin to 10 milliseconds for illustrative purposes.
    ACKStateCommon_t common = { 0, 10, propertyFlags };
    ACKError_t error;

    error = ACK_AddModeControllerProperty(MODE_INSTANCE_STATUS,&common, eDevStatus);

    if (ACK_NO_ERROR != error)
    {
        ACK_DEBUG_PRINT_E("Error %u adding Status property to event", error);
        return false;
    }

    return true;
}


bool AddLightTimerProperty(uint32_t propertyOrdinal, unsigned propertyFlags)
{
    // Populate metadata about the property. 
    // Leave the time-of-sample-field 0 to cause the current time to be sent. 
    // Set the error margin to 10 milliseconds for illustrative purposes.
    ACKStateCommon_t common = { 0, 10, propertyFlags };
    ACKError_t error;

    error = ACK_AddModeControllerProperty(MODE_INSTANCE_TIMER, &common, g_timerMode);

    if (ACK_NO_ERROR != error)
    {
        ACK_DEBUG_PRINT_E("Error %u adding timer mode property to event", error);
        return false;
    }

    return true;
}

bool AddLightBlinkingProperty(uint32_t propertyOrdinal, unsigned propertyFlags)
{
    // Populate metadata about the property. 
    // Leave the time-of-sample-field 0 to cause the current time to be sent. 
    // Set the error margin to 10 milliseconds for illustrative purposes.
    ACKStateCommon_t common = { 0, 10, propertyFlags };
    ACKError_t error;

    error = ACK_AddModeControllerProperty(MODE_INSTANCE_BLINKING, &common, g_blinkingMode);

    if (ACK_NO_ERROR != error)
    {
        ACK_DEBUG_PRINT_E("Error %u adding blinking mode property to event", error);
        return false;
    }

    return true;
}

// Turns light on.
// This function is hardware specific. In the current implementation it assumes PWM pin
// with 0 as off and 255 as maximum value.
void Hardware_TurnLightOn(void)
{
    uint8_t brightness = (uint8_t)(255 * (uint16_t)g_brightness / 100);
    ACKPlatform_SetDigitalPinPWMLevel(ACK_HW_PIN_SAMPLE_APPLICATIONS_LED, brightness);
}

// Turns light off.
// This function is hardware specific. In the current implementation it assumes PWM pin
// with 0 as off and 255 as maximum value.
void Hardware_TurnLightOff(void)
{
    ACKPlatform_SetDigitalPinPWMLevel(ACK_HW_PIN_SAMPLE_APPLICATIONS_LED, 0);
}
