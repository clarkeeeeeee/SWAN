#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

#include "numicro_hal.h"

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
