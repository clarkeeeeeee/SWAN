#ifndef __UART_QUE_H
#define __UART_QUE_H

#define u8 unsigned char
#define u16 unsigned int
#define u32 unsigned long
	
#define uint8 unsigned char
#define uint16 unsigned int
#define uint32 unsigned long
	
void UaerQueMain();
void UartQueInit();
void UartQuePush(u8 dat);
		
#endif /* __MAIN_H */
