#ifndef _CMD_QUEUE
#define _CMD_QUEUE

#include "uart_que.h"

#define CRC16_ENABLE 0         /*!< 如果需要CRC16校验功能，修改此宏为1(此时需要在VisualTFT工程中配CRC校验)*/
#define CMD_MAX_SIZE 10        /*!<单条指令大小，根据需要调整，尽量设置大一些*/
#define QUEUE_MAX_SIZE 50   /*!< 指令接收缓冲区大小，根据需要调整，尽量设置大一些*/

typedef unsigned char qdata;
typedef unsigned short qsize;

extern void queue_reset();
extern void queue_push(u8 _data);
extern u8 queue_find_cmd(u8 *cmd,u8 buf_len);

#endif