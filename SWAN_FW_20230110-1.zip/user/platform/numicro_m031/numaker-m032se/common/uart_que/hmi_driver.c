#include "hmi_driver.h"

#define TX_8(P1) SEND_DATA((P1)&0xFF)  //���͵����ֽ�
#define TX_8N(P,N) SendNU8((uint8 *)P,N)  //����N���ֽ�
#define TX_16(P1) TX_8((P1)>>8);TX_8(P1)  //����16λ����
#define TX_16N(P,N) SendNU16((uint16 *)P,N)  //����N��16λ����
#define TX_32(P1) TX_16((P1)>>16);TX_16((P1)&0xFFFF)  //����32λ����

#if(CRC16_ENABLE)

static uint16 _crc16 = 0xffff;
static void AddCRC16(uint8 *buffer,uint16 n,uint16 *pcrc)
{
	uint16 i,j,carry_flag,a;

	for (i=0; i<n; i++)
	{
		*pcrc=*pcrc^buffer[i];
		for (j=0; j<8; j++)
		{
			a=*pcrc;
			carry_flag=a&0x0001;
			*pcrc=*pcrc>>1;
			if (carry_flag==1)
				*pcrc=*pcrc^0xa001;
		}
	}
}

uint16 CheckCRC16(uint8 *buffer,uint16 n)
{
	uint16 crc0 = 0x0;
	uint16 crc1 = 0xffff;

	if(n>=2)
	{
		crc0 = ((buffer[n-2]<<8)|buffer[n-1]);
		AddCRC16(buffer,n-2,&crc1);
	}

	return (crc0==crc1);
}

void SEND_DATA(uint8 c)
{
	AddCRC16(&c,1,&_crc16);
	SendChar(c);
}

void BEGIN_CMD()
{
	TX_8(0XEE);
	_crc16 = 0XFFFF;//��ʼ����CRC16
}

void END_CMD()
{
	uint16 crc16 = _crc16;
	TX_16(crc16);//����CRC16
	TX_32(0XFFFCFFFF);
}

#else//NO CRC16

#define SEND_DATA(P) SendChar(P)
#define BEGIN_CMD() TX_8(0X55)
//#define END_CMD() TX_32(0XFFFCFFFF)

void END_CMD()
{
	TX_32(0X55AA5AA5);
}

#endif

void DelayMS(unsigned int n) 
{
	int i,j;  
	for(i = n;i>0;i--)
		for(j=1000;j>0;j--) ; 
}

