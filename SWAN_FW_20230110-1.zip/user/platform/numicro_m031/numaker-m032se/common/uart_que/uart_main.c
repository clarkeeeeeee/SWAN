#include "cmd_queue.h"
#include "uart_que.h"

u8 Test=0;

//void ProcessMessage(u8 *buf)
//{
//	Test++;
//}

extern void ProcessMessage(u8 *buf);
extern void ProcessEepromMessage(u8 *buf);

u8 cmd_buffer[CMD_MAX_SIZE];

void UartQueInit()
{
	queue_reset();
}
void UaerQueMain()
{
	static u8  size = 0;
	
	size = queue_find_cmd(cmd_buffer,CMD_MAX_SIZE);       
	if(size>0)
	{
		if(cmd_buffer[1]==0xa5)
			ProcessMessage(cmd_buffer);
		if(cmd_buffer[1]==0xaa)
			ProcessEepromMessage(cmd_buffer);
	}
}

void UartQuePush(u8 dat)
{
	queue_push(dat);
}
