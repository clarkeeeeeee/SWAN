#include "cmd_queue.h"

typedef struct _QUEUE
{
	u8 _head;
	u8 _tail;
	u8 _data[QUEUE_MAX_SIZE];	
}QUEUE;

QUEUE que = {0,0,0};
u8 cmd_state = 0;
u8 cmd_pos = 0;

void queue_reset()
{
	que._head = que._tail = 0;
	cmd_pos = cmd_state = 0;
}

void queue_push(u8 _data)
{
	u8 pos = (que._head+1)%QUEUE_MAX_SIZE;
	if(pos!=que._tail)//����״̬
	{
		que._data[que._head] = _data;
		que._head = pos;
	}
}

static void queue_pop(u8* _data)
{
	if(que._tail!=que._head)//�ǿ�״̬
	{
		*_data = que._data[que._tail];
		que._tail = (que._tail+1)%QUEUE_MAX_SIZE;
	}
}

static u8 queue_size()
{
	return ((que._head+QUEUE_MAX_SIZE-que._tail)%QUEUE_MAX_SIZE);
}

u8 queue_find_cmd(u8 *buffer,u8 buf_len)
{
	u8 cmd_size = 0;
	u8 _data = 0;
	static unsigned char cmd_len=0;
	
	while(queue_size()>0)
	{
		queue_pop(&_data);
		
		if(cmd_pos==0 && _data!=0X5a)//帧头出错，跳过
		    continue;
		if(cmd_pos==1 && !(_data==0Xa5 || _data==0xaa))//帧头出错，跳过
		    continue;

		if(cmd_pos<buf_len)//防止缓冲区溢出
			buffer[cmd_pos++] = _data;
			
		if(cmd_pos>=5)
			cmd_state=4;

		//�õ�������֡β
		if(cmd_state==4)
		{
			cmd_size = cmd_pos;
			cmd_state = 0;
			cmd_pos = 0;
			
			cmd_len=0;

#if(CRC16_ENABLE)
			//ȥ��ָ��ͷβEE��βFFFCFFFF����5���ֽڣ�ֻ�������ݲ���CRC
			if(!CheckCRC16(buffer+1,cmd_size-5))//CRCУ��
				return 0;

			cmd_size -= 2;//ȥ��CRC16
#endif

			return cmd_size;
		}
	}

	return 0;//û���γ�������һ֡
}