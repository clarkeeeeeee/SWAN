#ifndef __ANGEL_H
#define __ANGEL_H

#include "Hub.h"

extern uint16_t SmEnable;
extern uint8_t SmKeyPosTab[];
extern uint16_t AngelLedPosTab[];

extern uint16_t SmStepPosNow;				//��ǰλ��
extern uint16_t SmStepPosObjStart;		//��ʼĿ��λ��
extern uint16_t SmStepPosObjStop;		//����Ŀ��λ��

extern uint16_t SmClockwise;

extern uint16_t AngelGetSmOn();
extern uint8_t AngleSmInitDone();
extern void SmResetPra();
extern uint8_t AngleGetAngleKeyNum();
extern void SmRunHandle();
extern void CalcSmStepPosObj(uint16_t sm_key_msk);
extern void CalcSmStepPosObjFromApp(uint32_t sm_key_msk);
extern uint16_t AngleGetSmStepPosObjStart();
extern uint16_t AngleGetSmStepPosObjStop();
extern void AngelUpdateHubAngelLedSmPos();
extern uint16_t AngelGetSmFullSteps();
extern bool AngelCkSmArriveStopPos();
extern void CalcSmStepPosObj_BaseRodateValue(u8 rotate);
extern void CalcSmStepPosObjBaseOnExactAngel(uint32_t angel);
extern bool AngelGetIf_SmStepPosObjStart_Equal_SmStepPosObjStop();

#endif /* __MAIN_H */
