#ifndef _Led_func_
#define _Led_func_

#define	FADE_TIME	150
#define	SPEED_FADE_TIME	150
#define	HalfTo10_TIME	50
#define	PstLevel10_TIME	100
#define	PstLevelLight_TIME	150

#define	Pst10Steady_TIME	10

typedef enum
{
	pwr_ui_none=0,
	pwr_ui_steady,
	pwr_ui_fade
	
}TYPEDEF_PWR_UI;

typedef enum
{
	spd_ui_none=0,
	spd_ui_steady,
	spd_ui_flash,
	spd_ui_fade,
	spd_ui_idle
	
}TYPEDEF_SPD_UI;

typedef enum
{
	pst_10_none=0,
	pst_10_fadeup,
	pst_10_steady,
	pst_10_fadedn,
	pst_10_flash,
	
}TYPEDEF_PST_10;

typedef enum
{
	pst_ui_none=0,
	pst_ui_10_breath,
	pst_ui_steady,
	
}TYPEDEF_PST_UI;

typedef struct
{
    uint8_t  BT_DiscoveryBreatheTimer:1;
    uint8_t  USB_BreatheTimer:1;
    uint8_t  Music_BreatheTimer:1;
    uint8_t  MovieLed1_4FadeDownTimer;
    uint8_t  MovieLed2_3FadeDownTimer;
    uint8_t  SportLed_FadeUpTimer:1;
    uint8_t  VolumeLedFadeDownTimer:1;
    uint8_t  Learn_All4LedFadeDnTimer:1;
    uint8_t  Standby_BreatheTimer;
    uint8_t	LedFadeDownCnt;
    TYPEDEF_PWR_UI PWR_UI;
    uint8_t	Pwr_ui_1_sec;
    bool	PWR_HALF_FLAG;
    TYPEDEF_SPD_UI SPEED_UI;
    uint8_t	Spd_ui_1_sec;
    uint8_t	Spd_ui_flash_cnt;
    bool	Spd_FadeDnFlag;
    uint8_t	Spd_FadeDnTimer;
    uint8_t	Spd_FadeDnCnt;
    uint8_t	Half_to_10Timer;
    uint8_t	Half_to_10Cnt;
    bool 	Half_to_10Flag;
    TYPEDEF_PST_10 PST_10;
    TYPEDEF_PST_UI PST_UI;
    uint8_t	pst_10_SteadyCnt;
    uint8_t	pst_level_10Timer;
    uint8_t	pst_level_10Cnt;
    uint8_t	pst_level_100Cnt;
    uint8_t	pst_level_10FlashCnt;
    bool	pst_level_10BreathCycle;
    bool	pst_level_10Flag;
}LedDisplayTimer;
extern LedDisplayTimer LedDisp;

extern bool TK0_press; 
extern bool TK1_press; 
extern bool TK2_press;
extern bool TK3_press;
extern bool TK6_press;
extern bool TK7_press;
extern bool TK8_press;
extern bool TK9_press;

extern bool TK0_press_pre;
extern bool TK1_press_pre;
extern bool TK2_press_pre;
extern bool TK3_press_pre;
extern bool TK6_press_pre;
extern bool TK7_press_pre;
extern bool TK8_press_pre;
extern bool TK9_press_pre;

void PowerOn_Led(void);
void Power_HalfLed(void);
void Power_Level10Led(void);
void PowerStandbyBreathe_Disp(void);
void PowerLedFadeDown_Start(void);
void PowerLedFadeDown_End(void);
void PowerLed_HalfTo10Disp(void);
void PwrLed_HalfTo10_Start(void);
void PwrLed_HalfTo10_End(void);
void LightPwrLed_CancelPwrHalfTimer(void);

void SpeedLedFadeDn_Disp(void);
void PowerUI_Show(void);
void SpeedUI_Timer(void);
void SpeedUI_Show(void);
void SpeedUI_Cancel(void);

void PositionLevel10_Disp(void);
void PositionLevel10_Process(void);
void Pst_10_FadeUp_Start(void);
void Pst_10_Steady_Start(void);
void Pst_10_FadeDn_Start(void);
void Pst_10_Cancel(void);
uint8_t Pst_10_ProcessStep(void);

void PositionLevel10BreathDisp(void);
void PositionUI_Show(void);
void PositionUI_Cancel(void);


#endif

