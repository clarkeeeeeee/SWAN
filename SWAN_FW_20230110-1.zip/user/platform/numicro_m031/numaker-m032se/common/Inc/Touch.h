#ifndef _TOUCH_H_
#define _TOUCH_H_

#include "Hub.h"

#define SET_TICKS_ADJUSTABLE		3000
#define SET_TICKS_COMFIRMED			1000
#define POWER_DISP_TICKS			3000

typedef enum
{
	
	NONE,
	Adjustable,
	Comfirmed
	
}SetStatusEnum;

extern SetStatusEnum eAngleSet;
extern SetStatusEnum eFanSet;

extern u16 TouchAngelKeyMsk;
extern u16 AngleSetTicks;
extern u16 FanSetTicks;
extern u16 PowerDispTicks;
extern bool TouchKeyNull;

void TouchHandle(HubKeyEnum eKey);
u8 TouchRetLastAngelSetKeyIdx();
u8 TouchRetSecondLastAngelSetKeyIdx();
u8 TouchRetFirstValidAngelSetKeyIdx();
void TouchPowerSwitch(bool onoff);
u8 TouchSetFan(u8 fan);
void TouchLongKeyHandle();
void TouchLongKeyTicksAdd();


	
#endif








