#ifndef __PORT_H
#define __PORT_H

#define	ProductID_Bit0   PF4 
#define	ProductID_Bit1   PF5 
#define	ProductID_Bit2   PA8 
#define	ProductID_Bit3   PA9 

#define	LED_WHITE_POWER   PC14 
#define	LED_WHITE_1   PB7
#define	LED_WHITE_2   PA12
#define	LED_WHITE_3   PC1
#define	LED_WHITE_4   PC4

#define	LED_BLUE_1   PC2
#define	LED_BLUE_2   PC3
#define	LED_BLUE_4   PC5
#define	LED_BLUE_5   PF2
#define	LED_BLUE_7   PF3
#define	LED_BLUE_8   PB4
#define	LED_BLUE_10   PB6
#define	LED_BLUE_11   PC0
		
#define	OSC_CTRL_A   PA4
#define	OSC_CTRL_B   PA3
#define	OSC_CTRL_C   PA2
#define	OSC_CTRL_D   PA1
	
#define	OPTO_EN   PA0

#define	MOTOR_PWM		PA15
#define	MOTOR_CTRL		PA14

extern uint8_t offset_cnt;
extern uint8_t Tb_offset_cnt;


typedef enum
{
	motor_speed_none=0,
	motor_speed_super_low,
	motor_speed_low,
	motor_speed_middle,
	motor_speed_high,
}TYPEDEF_MOTOR_SPEED;
//extern TYPEDEF_MOTOR_SPEED Motor_Speed;




void Turn_Clockwise(void);
void Turn_AntiClockwise(void);


void Port_Init(void);
uint8_t Hardware_Product_Select(void);
void BlueLedBreathe_Disp(void);
void Motor_Pwm_Handle(void);

void turn_extra(void);
void Position_Init_Handle(void);



#endif

