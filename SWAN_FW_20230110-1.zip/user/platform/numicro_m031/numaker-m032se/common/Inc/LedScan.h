#ifndef _LED_SCAN_H_
#define _LED_SCAN_H_

#include "Hub.h"

typedef struct
{
	
	u16 BreathTimeMs;
	u16 BreathDutyStart;
	u16 BreathDutyStop;
	
	u16 BreathDutyNow;
	u16 BreathTimeUnit;
	u16 BreathTimeTicks;
	
}LedScanBreathStruct_t;

extern LedScanBreathStruct_t sLedScanBreath[];

void LedScanHandle();
void LedScanBreathHandle();

#endif








