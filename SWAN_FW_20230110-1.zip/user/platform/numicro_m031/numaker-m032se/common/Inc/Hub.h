#ifndef _HUB_H_
#define _HUB_H_

#include <stdint.h>
#include "numicro_hal.h"
#include <stdbool.h>

#define FAN_MAX		4
#define FAN_MIN		1

#define DEFAULT_WIND_DIRECTION		6

#ifndef u8 
#define u8 uint8_t
#endif
#ifndef u16 
#define u16 uint16_t
#endif
#ifndef u32 
#define u32 uint32_t
#endif

extern bool gPower;
extern u8 gFan;
extern u8 FanSave;
extern u16 gOscAngel;
extern u16 gOscAngelBkp;
extern u8 gWindDirection;
extern u8 gRotate;
extern u8 gRotateBkp;
extern u8 gRotateSwitch;

extern u8 HubInitLed;
extern u16 HubAngelLedStartSmPos;
extern u16 HubAngelLedStopSmPos;
extern bool bHubUpdateTouchAngelKeyMskFromApp;
extern bool bHubWindDirection180_SmDirClockwise;
extern bool bAckLifecycleConnectToAlexa;

extern bool UgsLedStatus;
extern bool FactoryResetLedStatus;
extern bool bHubRotate_OneCircle;

typedef enum
{
	HubKeyNULL,
	HubKeyAg1,
	HubKeyAg2,
	HubKeyAg3,
	HubKeyAg4,
	HubKeyAg5,
	HubKeyAg6,
	HubKeyAg7,
	HubKeyAg8,
	HubKeyPower,
	HubKeyAdd,
	HubKeySub,
	HubKeyUgs,
	HubKeyResetFactory,
	HubKeyLog
	
}HubKeyEnum;

typedef enum
{
	HubRotateNull=0,
	HubRotateOff,
	HubRotateClockWise,
	HubRotateNoClockWise,
}HubRotateEnum;


extern HubRotateEnum eHubRotate;
extern HubKeyEnum eHubKey;

HubKeyEnum HubGetKey();
u8 HubGetAngleKeyNum();
void HubMainHandle();
u8 HubUpdateTouchAngelKeyMskEn();
void HubIntLoopSlow();
void HubIntLoopFast();

u8 HubGet_gBlink();
void HubResetSmPra();
u8 HubGetLastAngelSetKeyIdx();
u8 HubGetSecondLastAngelSetKeyIdx();
u8 HubGetFirstValidAngelSetKeyIdx();

void HubAlexa_SendChangeReportDueToLocalControl();
void HubPowerSwitch(bool onoff);

u8 HubSetFan(u8 fan);
void HubSetTouchAngelKeyMsk(u8 msk);
void HubUpdateTouchAngelKeyMskFromApp(u16);

u8 HubGetAngleSetTicks();

void HubUpdateTouchAngelKeyMskFromAppRange(u16);

void HubSet_bHubResetFactory(bool b);
void HubSet_bHubUgs(bool b);
void HubResetAppPra();
void HubAlexaAutoSendChangeReportDueToLocalControl(bool bUpdate);

void HubPowerOnActRestoreOsc();
void HubCalcSmStepPosObj_BaseRodateValue(u8 rotate);

void HubSetRotateSwitch(bool on);

void PowerOnRestoreFan();
void PowerOnRestoreOther();
void PowerOnRestoreOSC();


#endif








