#ifndef _T_DEG_H_
#define _T_DEG_H_

#include <stdint.h>
#include "numicro_hal.h"
#include <stdbool.h>

uint16_t T_DegConvFromCToF(uint16_t c);
uint16_t T_DegConvFromFToC(uint16_t f);
uint16_t T_DegConvFromCToF2(uint16_t c_with_dot);


#endif



