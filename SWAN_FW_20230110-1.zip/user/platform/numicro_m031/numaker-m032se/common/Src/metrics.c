#include "metrics.h"
#include "ack_metrics.h"
#include "ack.h"
#include "dev.h"
#include "heating.h"
#include "keep_warm.h"
#include "off_base.h"
#include "low_water.h"
#include "time.h"


#define METRICS_BUSY		1000
uint16_t MetricsBusy=METRICS_BUSY;

void Metrics_ReloadMetricsBusy()
{
	MetricsBusy=METRICS_BUSY;
}

extern ACKLifecycleState_t ACK_LifecycleState;

sMetricsRtc_t sMetricsRtc;

uint16_t KettleCycleCount=0;
uint16_t KettleCycleCountBkp=0;
uint16_t Metrics__PreSetBkp;
uint16_t Metrics__PreSetDelayReport=0;


bool gbMetrics__kettle_start_method=false;
eMetrics_KettleStartMethod_t Metrics__kettle_start_method;

const char kettle_start_time[]="K70_start_time";
const char kettle_cycle_count[]="K70_cycle_count";

const char kettle_start_method[]="K70_start_method";
const char manual[]="manual";
const char remote[]="remote";


const char kettle_preset[]="K70_preset";
const char Boil[]="Boil";
const char Black_tea[]="Black tea";
const char Herbal_tea[]="Herbal tea";
const char Green_tea[]="Green tea";
const char White_tea[]="White tea";
const char Oolong_tea[]="Oolong tea";
const char Hot_Chocolate[]="Hot Chocolate";
const char French_Press[]="French Press";
const char Instant_Coffee[]="Instant Coffee";
const char Noodles[]="Noodles";
const char Blue_tea[]="Blue tea";
const char Yellow_tea[]="Yellow tea";
const char Rooibos_tea[]="Rooibos tea";
const char Mate[]="Mate";
const char Warm[]="Warm";
const char Ramen[]="Ramen";
const char Manual[]="Manual";
const char Honey[]="Honey";
const char Milk[]="Milk";

bool gbMetrics__kettle_target_temp=false;
uint16_t Metrics__TempSet;
uint16_t Metrics__TempSetDelayReport=0;
const char kettle_target_temp[]="K70_target_temp";

bool Metrics__gbHeatingBkp=false;
const char kettle_start_temp[]="K70_start_temp";
const char kettle_end_temp[]="K70_end_temp";

bool Metrics__gbKeepWarmBkp=false;
const char kettle_KW_program[]="K70_KW_program";

bool gbMetrics__kettle_heat_duration=false;
uint32_t Metrics__kettle_heat_duration=0;
const char kettle_heat_duration[]="K70_heat_duration";

bool gbMetrics__kettle_start_time=false;



uint32_t Metrics__Kettle_heater_life=0;
uint32_t Metrics__kettle_relay_cycle=0;
bool gbMetrics__Kettle_heater_life=false;
bool gbMetrics__kettle_relay_cycle=false;
const char Kettle_heater_life[]="K70_heater_life";
const char kettle_relay_cycle[]="K70_relay_cycle";

bool gbMetrics__kettle_end_method=false;
eMetrics_kettleEndMethod_t eMetrics_kettleEndMethod=eMetrics_kettleEndMethod_manual;
const char kettle_end_method[]="K70_end_method";

const char kettle_end_method_manual[]="manual";
const char kettle_end_method_ASO[]="ASO";
const char kettle_end_method_kettle_removed[]="kettle removed";
const char kettle_end_method_remote[]="remote";
const char kettle_end_method_low_water[]="low water";

bool gbMetrics__kettle_KW_duration=false;
uint16_t Metrics__kettle_KW_duration=0;
const char kettle_KW_duration[]="K70_KW_duration";

bool gbMetrics__LowWater=false;
const char ERR_out_of_water[]="ERR_out_of_water";

bool gbMetrics__kettle_location_BP=false;
uint16_t Metrics__kettle_location_BP=0;
const char kettle_location_BP[]="K70_location_BP";

//
bool gbMetrics__K70_change_report=false;
bool bClearMetrics__K70_change_report=false;
uint32_t Metrics__K70_change_report=0;
const char K70_change_report[]="K70_change_report";

static void K70_change_report_handle()
{
	static uint32_t ticks=0;
	
	ticks++;
	
	if(ticks==(6*60*60*1000) || ticks==(12*60*60*1000) || ticks==(18*60*60*1000) || ticks==(24*60*60*1000))
	{
		gbMetrics__K70_change_report=true;
	}
	if(ticks>=(24*60*60*1000))
	{
		ticks=0;
		bClearMetrics__K70_change_report=true;
	}
}
static bool Metrics_K70_change_report()
{
	uint16_t time;
	
	if(ACK_LifecycleState!=ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
		return false;
	
	if(gbMetrics__K70_change_report)
	{
		gbMetrics__K70_change_report=false;
		
		ACK_SendUsageReportMetricWithNumericValue(K70_change_report,Metrics__K70_change_report);
		printf("ACK_SendUsageReportMetric....K70_change_report\n");
		if(bClearMetrics__K70_change_report)
		{
			bClearMetrics__K70_change_report=false;
			Metrics__K70_change_report=0;
		}
		return true;
	}
	return false;
}
//end

void Metrics_SetKettleLocation_BP(uint16_t temperature)
{
	if(temperature==0xff)
		return;
	
	Metrics__kettle_location_BP=temperature*10;
	gbMetrics__kettle_location_BP=true;
}
void Metrics_SetkettleEndMethod(eMetrics_kettleEndMethod_t method)
{
	eMetrics_kettleEndMethod=method;
	gbMetrics__kettle_end_method=true;
	gbMetrics__kettle_relay_cycle=true;
}
static void Kettle_heater_life_handle()
{
	static uint32_t ticks=0;
	
	if(gbRelay)
	{
		if(++ticks>=(1000*60))
		{
			ticks=0;
			Metrics__Kettle_heater_life+=60;
			if(Metrics__Kettle_heater_life>5000000)
				Metrics__Kettle_heater_life=5000000;
		}
	}
}
static void kettle_relay_cycle_handle()
{
	static bool status=false;
	
	if(gbRelay)
	{
		if(!status)
		{
			status=true;
			Metrics__kettle_relay_cycle++;
			if(Metrics__kettle_relay_cycle>200000)
				Metrics__kettle_relay_cycle=200000;
//			gbMetrics__kettle_relay_cycle=true;
		}
	}
	else
		status=false;
}


static void kettle_KW_duration_handle()
{
	static bool on=false;
	static uint32_t ticks=0;
	
	if(gbKeepWarm)
	{
		on=true;
		
		if(gbKeepWarmRelay)
			ticks++;
	}
	
	if(on && !gbKeepWarm)
	{
		ticks/=1000;
		if(ticks>1800)
			ticks=1800;
		Metrics__kettle_KW_duration=ticks;
		on=false;
		gbMetrics__kettle_KW_duration=true;
	}
}
static void kettle_heat_duration_handle()
{
	static bool on=false;
	static uint32_t ticks=0;
	
	if(gbHeating && !gbOffBase)
	{
		on=true;
		ticks++;
	}
	
	if(on && !gbHeating)
	{
		ticks/=1000;
		if(ticks>1200)
			ticks=1200;
		Metrics__kettle_heat_duration=ticks;
		on=false;
		gbMetrics__kettle_heat_duration=true;
		gbMetrics__Kettle_heater_life=true;
	}
}

void Metrics_KettleCycleCountAdd()
{
	if(KettleCycleCount<METRICS_KETTLE_CYCLE_COUNT_MAX)
		KettleCycleCount++;
}

static bool Metrics_kettle_start_time()
{
	uint16_t time;
	
	if(ACK_LifecycleState!=ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
		return false;
	
	if(gbMetrics__kettle_start_time)
	{
		gbMetrics__kettle_start_time=false;
		
		time=sTime.hh*100;
		time+=sTime.mm;
		
		ACK_SendUsageReportMetricWithNumericValue(kettle_start_time,time);
		printf("ACK_SendUsageReportMetric....kettle_start_time\n");
		return true;
	}
	return false;
}
static bool Metrics_kettle_cycle_count()
{
	if(ACK_LifecycleState!=ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
		return false;
	
	if(KettleCycleCountBkp!=KettleCycleCount)
	{
		KettleCycleCountBkp=KettleCycleCount;
		
		ACK_SendUsageReportMetricWithNumericValue(kettle_cycle_count,KettleCycleCountBkp);
		printf("ACK_SendUsageReportMetricWithNumericValue....kettle_cycle_count:[%d]\n",KettleCycleCountBkp);
		return true;
	}
	return false;
}
static bool Metrics_kettle_start_method()
{
	if(ACK_LifecycleState!=ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
		return false;
	
	if(gbMetrics__kettle_start_method)
	{
		gbMetrics__kettle_start_method=false;
		
		if(Metrics__kettle_start_method==eMetrics_KettleStartMethod_manual)
			ACK_SendUsageReportMetricWithStringValue(kettle_start_method,manual);
		else
			ACK_SendUsageReportMetricWithStringValue(kettle_start_method,remote);
		printf("ACK_SendUsageReportMetricWithStringValue....kettle_start_method:[%d]\n",Metrics__kettle_start_method);
		return true;
	}
	return false;
}
static bool Metrics_kettle_preset()
{
	static bool report=false;
	
	if(ACK_LifecycleState!=ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
		return false;
	
	if(Metrics__PreSetBkp!=PreSet)
	{
		Metrics__PreSetBkp=PreSet;
		Metrics__PreSetDelayReport=10000;
		report=true;
	}
	if(report && !Metrics__PreSetDelayReport)
	{
		report=false;
		
		switch(Metrics__PreSetBkp)
		{
			case 1:
				ACK_SendUsageReportMetricWithStringValue(kettle_preset,Boil);
			break;
			case 2:
				ACK_SendUsageReportMetricWithStringValue(kettle_preset,Green_tea);
			break;
			case 3:
				ACK_SendUsageReportMetricWithStringValue(kettle_preset,Black_tea);
			break;
			case 4:
				ACK_SendUsageReportMetricWithStringValue(kettle_preset,Honey);
			break;
			case 5:
				ACK_SendUsageReportMetricWithStringValue(kettle_preset,Milk);
			break;
			case 6:
				ACK_SendUsageReportMetricWithStringValue(kettle_preset,Manual);
			break;
			
			default:
				break;
		}
		
		printf("ACK_SendUsageReportMetricWithStringValue....kettle_preset:[%d]\n",Metrics__PreSetBkp);
		return true;
	}
	return false;
}


static bool Metrics_kettle_target_temp()
{
	static bool report=false;
	
	if(ACK_LifecycleState!=ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
		return false;
	
	if(Metrics__TempSet!=TempSet_Celsius)
	{
		Metrics__TempSet=TempSet_Celsius;
		Metrics__TempSetDelayReport=10000;
		report=true;
	}
	if(gbMetrics__kettle_target_temp || (report && !Metrics__TempSetDelayReport))
	{
		gbMetrics__kettle_target_temp=report=false;
		
		ACK_SendUsageReportMetricWithNumericValue(kettle_target_temp,Metrics__TempSet);
		printf("ACK_SendUsageReportMetricWithNumericValue....kettle_target_temp:[%d]\n",Metrics__TempSet);
		return true;
	}
	return false;
}
static bool Metrics_kettle_start_and_end_temp()
{
	static bool report=false;
	
	if(ACK_LifecycleState!=ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
		return false;
	
	if(Metrics__gbHeatingBkp!=gbHeating)
	{
		Metrics__gbHeatingBkp=gbHeating;
		
		if(Metrics__gbHeatingBkp)
		{
			ACK_SendUsageReportMetricWithNumericValue(kettle_start_temp,TempNow_Celsius);
			printf("ACK_SendUsageReportMetricWithNumericValue....kettle_start_temp:[%d]\n",TempNow_Celsius);
		}
		else
		{
			ACK_SendUsageReportMetricWithNumericValue(kettle_end_temp,TempNow_Celsius);
			printf("ACK_SendUsageReportMetricWithNumericValue....kettle_end_temp:[%d]\n",TempNow_Celsius);
		}
		return true;
	}
	return false;
}
static bool Metrics_kettle_KW_program()
{
	static bool report=false;
	
	if(ACK_LifecycleState!=ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
		return false;
	
	if(Metrics__gbKeepWarmBkp!=gbKeepWarm)
	{
		Metrics__gbKeepWarmBkp=gbKeepWarm;
		
		if(Metrics__gbKeepWarmBkp)
		{
			ACK_SendUsageReportMetricWithNumericValue(kettle_KW_program,KeepWarmMinutesBkp);
			printf("ACK_SendUsageReportMetricWithNumericValue....kettle_KW_program:[%d]\n",KeepWarmMinutesBkp);
		}
		return true;
	}
	return false;
}
static bool Metrics_kettle_heat_duration()
{
	static bool report=false;
	
	if(ACK_LifecycleState!=ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
		return false;
	
	if(gbMetrics__kettle_heat_duration)
	{
		gbMetrics__kettle_heat_duration=false;
		
		ACK_SendUsageReportMetricWithNumericValue(kettle_heat_duration,Metrics__kettle_heat_duration);
		printf("ACK_SendUsageReportMetricWithNumericValue....kettle_heat_duration:[%d]\n",Metrics__kettle_heat_duration);
		return true;
	}
	return false;
}

static bool Metrics_Kettle_heater_life()
{
	static bool report=false;
	
	if(ACK_LifecycleState!=ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
		return false;
	
	if(gbMetrics__Kettle_heater_life)
	{
		gbMetrics__Kettle_heater_life=false;
		
		if(!Metrics__Kettle_heater_life)
			return false;
		ACK_SendUsageReportMetricWithNumericValue(Kettle_heater_life,Metrics__Kettle_heater_life);
		printf("ACK_SendUsageReportMetricWithNumericValue....Kettle_heater_life:[%d]\n",Metrics__Kettle_heater_life);
		return true;
	}
	return false;
}
static bool Metrics_kettle_relay_cycle()
{
	static bool report=false;
	
	kettle_relay_cycle_handle();
	
	if(ACK_LifecycleState!=ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
		return false;
	
	if(gbMetrics__kettle_relay_cycle)
	{
		gbMetrics__kettle_relay_cycle=false;
		
		ACK_SendUsageReportMetricWithNumericValue(kettle_relay_cycle,Metrics__kettle_relay_cycle);
		printf("ACK_SendUsageReportMetricWithNumericValue....kettle_relay_cycle:[%d]\n",Metrics__kettle_relay_cycle);
		return true;
	}
	return false;
}

static bool Metrics_kettle_end_method()
{
	if(ACK_LifecycleState!=ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
		return false;
	
	if(gbMetrics__kettle_end_method)
	{
		gbMetrics__kettle_end_method=false;
		
		switch(eMetrics_kettleEndMethod)
		{
			case eMetrics_kettleEndMethod_manual:
				ACK_SendUsageReportMetricWithStringValue(kettle_end_method,kettle_end_method_manual);
			break;
			case eMetrics_kettleEndMethod_ASO:
				ACK_SendUsageReportMetricWithStringValue(kettle_end_method,kettle_end_method_ASO);
			break;
			case eMetrics_kettleEndMethod_KettleRemoved:
				ACK_SendUsageReportMetricWithStringValue(kettle_end_method,kettle_end_method_kettle_removed);
			break;
			case eMetrics_kettleEndMethod_remote:
				ACK_SendUsageReportMetricWithStringValue(kettle_end_method,kettle_end_method_remote);
			break;
			case eMetrics_kettleEndMethod_LowWater:
				ACK_SendUsageReportMetricWithStringValue(kettle_end_method,kettle_end_method_low_water);
			break;
			
			default:
				break;
		}
		
		printf("ACK_SendUsageReportMetricWithStringValue....kettle_end_method:[%d]\n",eMetrics_kettleEndMethod);
		return true;
	}
	return false;
}

static bool Metrics_kettle_KW_duration()
{
	static bool report=false;
	
	if(ACK_LifecycleState!=ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
		return false;
	
	if(gbMetrics__kettle_KW_duration)
	{
		gbMetrics__kettle_KW_duration=false;
		
		ACK_SendUsageReportMetricWithNumericValue(kettle_KW_duration,Metrics__kettle_KW_duration);
		printf("ACK_SendUsageReportMetricWithNumericValue....kettle_KW_duration:[%d]\n",Metrics__kettle_KW_duration);
		return true;
	}
	return false;
}
static bool Metrics_FW_HMCU()
{
	static bool reported=false;
	
	if(ACK_LifecycleState!=ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
		return false;
	if(reported)
		return false;
	
	reported=true;
	ACK_SendUsageReportMetricWithStringValue("FW_HMCU",FIRMWARE_VERSION);
	printf("ACK_SendUsageReportMetricWithStringValue....FW_HMCU\n");
	return true;
}
static bool Metrics_ERR_out_of_water()
{
	if(ACK_LifecycleState!=ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
		return false;
	
	if(gbMetrics__LowWater!=gbLowWater)
	{
		gbMetrics__LowWater=gbLowWater;
		if(gbMetrics__LowWater)
		{
			ACK_SendErrorMetric(ERR_out_of_water);
			printf("ACK_SendErrorMetric....ERR_out_of_water\n");
			return true;
		}
	}
	return false;
}
static bool Metrics_kettle_location_BP()
{
	static bool report=false;
	
	if(ACK_LifecycleState!=ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
		return false;
	
	if(gbMetrics__kettle_location_BP)
	{
		gbMetrics__kettle_location_BP=false;
		
		ACK_SendUsageReportMetricWithNumericValue(kettle_location_BP,Metrics__kettle_location_BP);
		printf("ACK_SendUsageReportMetricWithNumericValue....kettle_location_BP:[%d]\n",Metrics__kettle_location_BP);
		return true;
	}
	return false;
}
void MetricsHandle()
{
	bool status=false;
	
	if(MetricsBusy)
		return;
	
	status=Metrics_kettle_start_time();		//FIX K70
	if(status)
	{
		MetricsBusy=METRICS_BUSY;
		return;
	}
	status=Metrics_kettle_cycle_count();	//FIX K70
	if(status)
	{
		MetricsBusy=METRICS_BUSY;
		return;
	}
	status=Metrics_kettle_start_method();	//FIX K70
	if(status)
	{
		MetricsBusy=METRICS_BUSY;
		return;
	}
	status=Metrics_kettle_preset();			//FIX K70
	if(status)
	{
		MetricsBusy=METRICS_BUSY;
		return;
	}
	status=Metrics_kettle_target_temp();	//FIX K70
	if(status)
	{
		MetricsBusy=METRICS_BUSY;
		return;
	}
	status=Metrics_kettle_start_and_end_temp();		//FIX K70
	if(status)
	{
		MetricsBusy=METRICS_BUSY;
		return;
	}
	status=Metrics_kettle_KW_program();		//FIX K70
	if(status)
	{
		MetricsBusy=METRICS_BUSY;
		return;
	}
	status=Metrics_kettle_heat_duration();	//FIX K70
	if(status)
	{
		MetricsBusy=METRICS_BUSY;
		return;
	}
	status=Metrics_Kettle_heater_life();	//FIX K70
	if(status)
	{
		MetricsBusy=METRICS_BUSY;
		return;
	}
	status=Metrics_kettle_relay_cycle();	//FIX K70
	if(status)
	{
		MetricsBusy=METRICS_BUSY;
		return;
	}
	status=Metrics_kettle_end_method();		//FIX K70
	if(status)
	{
		MetricsBusy=METRICS_BUSY;
		return;
	}
	status=Metrics_kettle_KW_duration();	//FIX K70
	if(status)
	{
		MetricsBusy=METRICS_BUSY;
		return;
	}
	status=Metrics_FW_HMCU();		//FIX K70
	if(status)
	{
		MetricsBusy=METRICS_BUSY;
		return;
	}
	status=Metrics_ERR_out_of_water();	//FIX K70
	if(status)
	{
		MetricsBusy=METRICS_BUSY;
		return;
	}
	status=Metrics_kettle_location_BP();	//FIX K70
	if(status)
	{
		MetricsBusy=METRICS_BUSY;
		return;
	}
	status=Metrics_K70_change_report();		//FIX K70
	if(status)
	{
		MetricsBusy=METRICS_BUSY;
		return;
	}
}

void MetricsHandleForTmrInt()
{
	if(Metrics__PreSetDelayReport)
		Metrics__PreSetDelayReport--;
	if(Metrics__TempSetDelayReport)
		Metrics__TempSetDelayReport--;
	if(MetricsBusy)
		MetricsBusy--;
	
	kettle_heat_duration_handle();
	Kettle_heater_life_handle();
	kettle_KW_duration_handle();
	K70_change_report_handle();
}
