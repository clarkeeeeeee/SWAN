#ifndef __LED_DRIVER_H
#define __LED_DRIVER_H

#include "numicro_hal.h"
#include "ack_logging.h"
#include <inttypes.h>
#include <stdint.h>

#define LED_DRIVER_RAM_LEN		4

extern uint8_t LedDriverRamBuf[LED_DRIVER_RAM_LEN];

bool LedDriverUpdateDisplay();



















#endif