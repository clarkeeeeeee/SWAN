
#include "board.h"
#include "port.h"
#include "top.h"

void Port_Init(void)
{
	//
//	GPIO_SetMode(PC, BIT2|BIT4|BIT5, GPIO_MODE_OUTPUT);
//	PC2=0;
//	PC4=0;
//	PC5=0;
//	GPIO_SetMode(PA, BIT4, GPIO_MODE_OUTPUT);
//	PA4=0;
//	
//	GPIO_SetMode(PB, BIT7, GPIO_MODE_OUTPUT);	//RELAY
//	PF3=0;
	
//	GPIO_SetMode(PC, BIT3, GPIO_MODE_OUTPUT);
//	PC3=0;
	
//	GPIO_SetMode(PF, BIT2, GPIO_MODE_QUASI);
//	GPIO_SetMode(PA, BIT7, GPIO_MODE_OUTPUT);
//	PA7=1;
	
//	GPIO_SetMode(PA, BIT6, GPIO_MODE_INPUT);
	
	
//	GPIO_SetMode(PB, BIT4, GPIO_MODE_INPUT);	//ZERO
//	
//	
//	GPIO_SetMode(PF, BIT2, GPIO_MODE_QUASI);
//	PF2=1;
//	
	GPIO_SetMode(PB, BIT7, GPIO_MODE_OUTPUT);
	PB7=0;
	//key
	GPIO_SetMode(PA, BIT7, GPIO_MODE_INPUT);
	GPIO_SetMode(PA, BIT6, GPIO_MODE_INPUT);
	GPIO_SetMode(PC, BIT2, GPIO_MODE_INPUT);
	GPIO_SetMode(PC, BIT3, GPIO_MODE_INPUT);
	//LED DRIVER
	GPIO_SetMode(PC, BIT1, GPIO_MODE_QUASI);
	GPIO_SetMode(PC, BIT0, GPIO_MODE_QUASI);
	PC1=1;
	PC0=1;
	
	#if PCB_US
	GPIO_SetMode(PC, BIT4, GPIO_MODE_OUTPUT);
	PC4=0;
	GPIO_SetMode(PC, BIT5, GPIO_MODE_OUTPUT);
	PC5=0;
	#endif

}



