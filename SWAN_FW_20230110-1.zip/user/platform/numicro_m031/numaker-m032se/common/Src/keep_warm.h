#ifndef _KEEP_WARM_H_
#define _KEEP_WARM_H_

#include <stdint.h>
#include "numicro_hal.h"
#include <stdbool.h>

extern bool gbKeepWarm;
extern bool gbKeepWarmRelay;
extern uint32_t KeepWarmMinutes;
extern uint32_t KeepWarmMinutesBkp;
extern bool gbKeepWarmStatusPreviousPowerCircle;
extern uint32_t KeepWarmTimeRemaine_ForSave;
extern uint32_t KeepWarmTime;
extern bool bReheat;

void KeepWarmStart();
void KeepWarmStop();
void KeepWarmHandle();
void KeepWarmHandleForTmrInt();
bool KeepWarmRetStatus();
void KeepWarmReloadKeepWarmTime();
void KeepWarmResetKeepWarmMinutes();

#endif



