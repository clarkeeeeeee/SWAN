#include "LedScan.h"
#include "top.h"

#define LED_SCAN_DUTY		100
//#define BREATH_TIME			5
#define BREATH_IRQ_TIME		1		//MS

u16 LedScanPeriod=0;

u16 LedScanDuty[14]={0};
//u16 LedScanDuty2[13]={0};


LedScanBreathStruct_t sLedScanBreath[14]={0};

#define LED14_ON		PB5=0
#define LED14_OFF		PB5=1

#define LED2_ON		PF3=0
#define LED2_OFF	PF3=1
#define LED3_ON		PB4=0
#define LED3_OFF	PB4=1
#define LED4_ON		PB6=0
#define LED4_OFF	PB6=1
#define LED5_ON		PC0=0
#define LED5_OFF	PC0=1
#define LED6_ON		PC2=0
#define LED6_OFF	PC2=1
#define LED7_ON		PC3=0
#define LED7_OFF	PC3=1
#define LED8_ON		PC5=0
#define LED8_OFF	PC5=1
#define LED1_ON		PF2=0
#define LED1_OFF	PF2=1

#define LED9_ON		PC14=0
#define LED9_OFF	PC14=1

#define LED10_ON		PB7=0
#define LED10_OFF		PB7=1
#define LED11_ON		PA12=0
#define LED11_OFF		PA12=1
#define LED12_ON		PC1=0
#define LED12_OFF		PC1=1
#define LED13_ON		PC4=0
#define LED13_OFF		PC4=1



u16 CalcDuty(u8 percent,u8 duty_factor)
{
	u16 tmp=LED_SCAN_DUTY*percent/100;
	
	return tmp*duty_factor/100;
}

void CalcBreathTimeUnit(LedScanBreathStruct_t *pLedScanBreathStruct)
{
	u16 diff;
	u16 temp;
	
	if(pLedScanBreathStruct->BreathDutyStart==pLedScanBreathStruct->BreathDutyStop)
		return;
	
	if(pLedScanBreathStruct->BreathDutyStart>pLedScanBreathStruct->BreathDutyStop)
		diff=pLedScanBreathStruct->BreathDutyStart-pLedScanBreathStruct->BreathDutyStop;
	else
		diff=pLedScanBreathStruct->BreathDutyStop-pLedScanBreathStruct->BreathDutyStart;
	
	temp=pLedScanBreathStruct->BreathTimeMs;
	temp/=BREATH_IRQ_TIME;
	temp/=diff;
	
	pLedScanBreathStruct->BreathTimeUnit=temp;
}

void UpdateLedScanBreathPra(LedScanBreathStruct_t *pLedScanBreathStruct,u16 *duty,u8 duty_factor)
{
	CalcBreathTimeUnit(pLedScanBreathStruct);
	
	if(pLedScanBreathStruct->BreathDutyStart==pLedScanBreathStruct->BreathDutyStop)
	{
		*duty=CalcDuty(pLedScanBreathStruct->BreathDutyNow=pLedScanBreathStruct->BreathDutyStop,duty_factor);
		return;
	}
	
	if(++pLedScanBreathStruct->BreathTimeTicks>=pLedScanBreathStruct->BreathTimeUnit)
		pLedScanBreathStruct->BreathTimeTicks=0;
	else
		return;
	
	if(pLedScanBreathStruct->BreathDutyStart>pLedScanBreathStruct->BreathDutyStop)
	{
		if(pLedScanBreathStruct->BreathDutyNow>pLedScanBreathStruct->BreathDutyStart || pLedScanBreathStruct->BreathDutyNow<pLedScanBreathStruct->BreathDutyStop)
		{
			pLedScanBreathStruct->BreathDutyNow=pLedScanBreathStruct->BreathDutyStart;
			*duty=CalcDuty(pLedScanBreathStruct->BreathDutyNow,duty_factor);
		}
		else
		{
			if(pLedScanBreathStruct->BreathDutyNow>pLedScanBreathStruct->BreathDutyStop)
				pLedScanBreathStruct->BreathDutyNow--;
			*duty=CalcDuty(pLedScanBreathStruct->BreathDutyNow,duty_factor);
		}
	}
	else 
	{
		if(pLedScanBreathStruct->BreathDutyNow>pLedScanBreathStruct->BreathDutyStop || pLedScanBreathStruct->BreathDutyNow<pLedScanBreathStruct->BreathDutyStart)
		{
			pLedScanBreathStruct->BreathDutyNow=pLedScanBreathStruct->BreathDutyStart;
			*duty=CalcDuty(pLedScanBreathStruct->BreathDutyNow,duty_factor);
		}
		else
		{
			if(++pLedScanBreathStruct->BreathDutyNow>=pLedScanBreathStruct->BreathDutyStop)
				pLedScanBreathStruct->BreathDutyNow=pLedScanBreathStruct->BreathDutyStop;
			*duty=CalcDuty(pLedScanBreathStruct->BreathDutyNow,duty_factor);
		}
	}
}

void LedScanTest()
{
	static u8 Ticks=0;
	
	if(Ticks<10)
	{
		sLedScanBreath[0].BreathDutyStart=0;
		sLedScanBreath[0].BreathDutyStop=0;
		sLedScanBreath[0].BreathTimeMs=1000;
	}
	else if(Ticks<20)
	{
		sLedScanBreath[0].BreathDutyStart=10;
		sLedScanBreath[0].BreathDutyStop=10;
		sLedScanBreath[0].BreathTimeMs=1000;
	}
	else if(Ticks<30)
	{
		sLedScanBreath[0].BreathDutyStart=0;
		sLedScanBreath[0].BreathDutyStop=0;
		sLedScanBreath[0].BreathTimeMs=1000;
	}
	else if(Ticks<40)
	{
		sLedScanBreath[0].BreathDutyStart=100;
		sLedScanBreath[0].BreathDutyStop=100;
		sLedScanBreath[0].BreathTimeMs=1000;
	}
	else if(Ticks<50)
	{
		sLedScanBreath[0].BreathDutyStart=0;
		sLedScanBreath[0].BreathDutyStop=0;
		sLedScanBreath[0].BreathTimeMs=1000;
	}
	else if(Ticks<80)
	{
		sLedScanBreath[0].BreathDutyStart=0;
		sLedScanBreath[0].BreathDutyStop=70;
		sLedScanBreath[0].BreathTimeMs=500;
	}
	else if(Ticks<110)
	{
		sLedScanBreath[0].BreathDutyStart=70;
		sLedScanBreath[0].BreathDutyStop=0;
		sLedScanBreath[0].BreathTimeMs=1000;
	}
	else 
	{
		sLedScanBreath[0].BreathDutyStart=0;
		sLedScanBreath[0].BreathDutyStop=0;
		sLedScanBreath[0].BreathTimeMs=1000;
	}
	
	if(++Ticks>=120)
		Ticks=0;
}

void LedScanBreathHandle()
{
	
//	sLedScanBreath[6].BreathDutyStart=30;
//	sLedScanBreath[6].BreathDutyStop=3;
//	sLedScanBreath[6].BreathTimeMs=1000;
	
	UpdateLedScanBreathPra(&sLedScanBreath[0],&LedScanDuty[0],FACTOR_BLUE_LED);
	UpdateLedScanBreathPra(&sLedScanBreath[1],&LedScanDuty[1],FACTOR_BLUE_LED);
	UpdateLedScanBreathPra(&sLedScanBreath[2],&LedScanDuty[2],FACTOR_BLUE_LED);
	UpdateLedScanBreathPra(&sLedScanBreath[3],&LedScanDuty[3],FACTOR_BLUE_LED);
	UpdateLedScanBreathPra(&sLedScanBreath[4],&LedScanDuty[4],FACTOR_BLUE_LED);
	UpdateLedScanBreathPra(&sLedScanBreath[5],&LedScanDuty[5],FACTOR_BLUE_LED);
	UpdateLedScanBreathPra(&sLedScanBreath[6],&LedScanDuty[6],FACTOR_BLUE_LED);
	UpdateLedScanBreathPra(&sLedScanBreath[7],&LedScanDuty[7],FACTOR_BLUE_LED);
	
	UpdateLedScanBreathPra(&sLedScanBreath[8],&LedScanDuty[8],FACTOR_WHITE_LED);
	
	UpdateLedScanBreathPra(&sLedScanBreath[9],&LedScanDuty[9],FACTOR_WHITE_LED);
	UpdateLedScanBreathPra(&sLedScanBreath[10],&LedScanDuty[10],FACTOR_WHITE_LED);
	UpdateLedScanBreathPra(&sLedScanBreath[11],&LedScanDuty[11],FACTOR_WHITE_LED);
	UpdateLedScanBreathPra(&sLedScanBreath[12],&LedScanDuty[12],FACTOR_WHITE_LED);
	
	UpdateLedScanBreathPra(&sLedScanBreath[13],&LedScanDuty[13],FACTOR_BLUE_LED);
}

void LedScanHandle()
{
	if(LedScanPeriod<LedScanDuty[0])
		LED1_ON;
	else
		LED1_OFF;
	
	if(LedScanPeriod<LedScanDuty[1])
		LED2_ON;
	else
		LED2_OFF;
	
	if(LedScanPeriod<LedScanDuty[2])
		LED3_ON;
	else
		LED3_OFF;
	
	if(LedScanPeriod<LedScanDuty[3])
		LED4_ON;
	else
		LED4_OFF;
	
	if(LedScanPeriod<LedScanDuty[4])
		LED5_ON;
	else
		LED5_OFF;
	
	if(LedScanPeriod<LedScanDuty[5])
		LED6_ON;
	else
		LED6_OFF;
	
	if(LedScanPeriod<LedScanDuty[6])
		LED7_ON;
	else
		LED7_OFF;
	
	if(LedScanPeriod<LedScanDuty[7])
		LED8_ON;
	else
		LED8_OFF;
		
	if(bAckLifecycleConnectToAlexa && !UgsLedStatus && !FactoryResetLedStatus)
	{
		if(LedScanPeriod<LedScanDuty[13])
			LED14_ON;
		else
			LED14_OFF;
		
		LED9_OFF;
	}
	else
	{
		if(LedScanPeriod<LedScanDuty[8])
			LED9_ON;
		else
			LED9_OFF;
		
		LED14_OFF;
	}
	
//	if(LedScanPeriod<LedScanDuty[8])
//		LED14_ON;
//	else
//		LED14_OFF;
	
	if(LedScanPeriod<LedScanDuty[9])
		LED10_ON;
	else
		LED10_OFF;
	
	if(LedScanPeriod<LedScanDuty[10])
		LED11_ON;
	else
		LED11_OFF;
	
	if(LedScanPeriod<LedScanDuty[11])
		LED12_ON;
	else
		LED12_OFF;
	
	if(LedScanPeriod<LedScanDuty[12])
		LED13_ON;
	else
		LED13_OFF;
	
	if(++LedScanPeriod>=LED_SCAN_DUTY)
		LedScanPeriod=0;
}



















