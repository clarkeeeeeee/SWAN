#ifndef _METRICS_H_
#define _METRICS_H_

#include <stdint.h>
#include "numicro_hal.h"
#include <stdbool.h>


#define METRICS_KETTLE_CYCLE_COUNT_MAX		14000

extern bool gbMetrics__kettle_start_time;
extern uint16_t KettleCycleCount;
extern uint16_t KettleCycleCountBkp;
extern uint16_t Metrics__PreSetBkp;
extern bool gbMetrics__kettle_target_temp;
extern uint16_t Metrics__TempSet;
extern uint32_t Metrics__Kettle_heater_life;
extern uint32_t Metrics__kettle_relay_cycle;
extern uint32_t Metrics__K70_change_report;



typedef struct
{
	int16_t hh;
	int16_t mm;
	int16_t ss;
	bool valid;
}sMetricsRtc_t;

typedef enum
{
	eMetrics_KettleStartMethod_manual,
	eMetrics_KettleStartMethod_remote,
}eMetrics_KettleStartMethod_t;

typedef enum
{
	eMetrics_kettleEndMethod_manual,
	eMetrics_kettleEndMethod_ASO,
	eMetrics_kettleEndMethod_KettleRemoved,
	eMetrics_kettleEndMethod_remote,
	eMetrics_kettleEndMethod_LowWater,
}eMetrics_kettleEndMethod_t;


extern bool gbMetrics__kettle_start_method;
extern eMetrics_KettleStartMethod_t Metrics__kettle_start_method;

extern sMetricsRtc_t sMetricsRtc;

void MetricsHandle();
void Metrics_KettleCycleCountAdd();
void MetricsHandleForTmrInt();
void Metrics_SetkettleEndMethod(eMetrics_kettleEndMethod_t method);
void Metrics_SetKettleLocation_BP(uint16_t temperature);
void Metrics_ReloadMetricsBusy();


#endif



