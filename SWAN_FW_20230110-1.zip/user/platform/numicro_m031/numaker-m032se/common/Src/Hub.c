#include "Hub.h"

#include "Touch.h"
#include "LedScan.h"
#include "Angel.h"
#include "Fan.h"

#include "board.h"
#include "top.h"

u16 HubAngelLedStartSmPos=0;
u16 HubAngelLedStopSmPos=0;

void HubUpdateHubAngelLedSmPos()
{
	AngelUpdateHubAngelLedSmPos();
}


#define BLINK_UNIT		200

#define ANGEL_LED_NORMAL_LIGHTNESS_TICKS		15000

u8 gBlink=0;

bool gPower=false;
u8 gFan=0;
u8 FanSave=0xff;
u16 gOscAngel=0;
u16 gOscAngelBkp=0;
u8 gWindDirection=DEFAULT_WIND_DIRECTION;


u8 gRotateBkp=0;
u8 gRotate=0;

u8 gRotateSwitch=0;

HubRotateEnum eHubRotate=HubRotateNull;
bool bHubRotate_OneCircle=false;

bool bHubWindDirection180_SmDirClockwise=false;

bool bAckLifecycleConnectToAlexa=false;

void PowerOnRestoreFan()
{
	gFan = FanSave;
}
void PowerOnRestoreOSC()
{
	gOscAngel=gOscAngelBkp;
	gRotate=gRotateBkp;
	
	PowerDispTicks=POWER_DISP_TICKS;
	FanSetTicks=SET_TICKS_ADJUSTABLE;
	
	if(gRotate>1 || gOscAngel)
		gRotateSwitch=1;
}
void PowerOnRestoreOther()
{
	gWindDirection=DEFAULT_WIND_DIRECTION;
}

void HubSetRotateSwitch(bool on)
{
	if(on)
	{
		gRotateSwitch=1;
		
		gRotate=gRotateBkp;
		gOscAngel=gOscAngelBkp;
	}
	else
	{
		gRotateSwitch=0;
		bHubRotate_OneCircle=0;
		
		gRotateBkp=gRotate;
		gRotate=1;
		
		gOscAngelBkp=gOscAngel;
		gOscAngel=0;
	}
}

void HubResetAppPra()
{
	gOscAngelBkp=gOscAngel;
	gRotateBkp=gRotate;
	
	gPower=false;
	gFan=0;
	gOscAngel=0;
	gWindDirection=0;
	gRotate=0;
	gRotateSwitch=0;
}

bool bHubUpdateTouchAngelKeyMskFromApp=false;


extern void Alexa_SendChangeReportDueToLocalControl(void);

u16 HubAlexaAutoSendChangeReportDueToLocalControlDelay=0;
bool bHubAlexaAutoSendChangeReportDueToLocalControl=false;

void HubAlexaAutoSendChangeReportDueToLocalControlDelayHandle()
{
	if(HubAlexaAutoSendChangeReportDueToLocalControlDelay)
	{
		HubAlexaAutoSendChangeReportDueToLocalControlDelay--;
		if(!HubAlexaAutoSendChangeReportDueToLocalControlDelay)
			bHubAlexaAutoSendChangeReportDueToLocalControl=true;
	}
}
void HubAlexaAutoSendChangeReportDueToLocalControl(bool bUpdate)
{
	static bool power=false;
	static u16 osc_angel=0xffff;
	static u8 fan=0xff;
	static u8 wind_direction=0xff;
	static u8 rotate=0xff;
	static u8 rotate_switch=0xff;
	
	if(!bAckLifecycleConnectToAlexa)
		return;
	
	if(bUpdate)
	{
		power=gPower;
		fan=gFan;
		osc_angel=gOscAngel;
		wind_direction=gWindDirection;
		rotate=gRotate;
		rotate_switch=gRotateSwitch;
		
		HubAlexaAutoSendChangeReportDueToLocalControlDelay=0;
		return;
	}
	
	if(power!=gPower || fan!=gFan || osc_angel!=gOscAngel || wind_direction!=gWindDirection || rotate!=gRotate || rotate_switch!=gRotateSwitch)
	{
		power=gPower;
		fan=gFan;
		osc_angel=gOscAngel;
		wind_direction=gWindDirection;
		rotate=gRotate;
		rotate_switch=gRotateSwitch;
		
		HubAlexaAutoSendChangeReportDueToLocalControlDelay=1000;
	}
	
	if(bHubAlexaAutoSendChangeReportDueToLocalControl)
	{
		bHubAlexaAutoSendChangeReportDueToLocalControl=false;
//		Alexa_SendChangeReportDueToLocalControl();
	}
}






extern bool UART2_SendCmd_Set_EEPROM(void);
void FanSaveHandle()
{
	if(FanSave==0xff)
		return;
	if(!gFan)
		return;
	
	if(FanSave!=gFan)
	{
		FanSave=gFan;
		UART2_SendCmd_Set_EEPROM();
	}
}

void ProcessEepromMessage(u8 *buf)
{
	u8 sum=0;

	sum=*(buf+2)+*(buf+3);
	sum^=0xff;
	
	if(sum==*(buf+4))
	{
		if((*(buf+3))>=1 && (*(buf+3))<=4)
		{
			FanSave=(*(buf+3));
		}
		else
		{
//			FanSave=0;
		}
	}
}


HubKeyEnum eHubKey=HubKeyNULL;

u16 SmArriveStopPosLedTicks=0;		//电机到达定点位置之后led闪烁提示
u16 AngelLedNormalLightnessTicks=0;		//正常亮度显示
u16 AngelLed_AngelComfirmedTicks=0;

u8 HubInitLed=1;
#ifdef FAST_HUB_INIT_LED
#define HUB_INIT_LED_TIME_UNIT		50
#else
#define HUB_INIT_LED_TIME_UNIT		250
#endif


extern void Alexa_InitiateFactoryReset(void);
extern void Alexa_InitiateUserGuidedSetup(void);
	


void HubInitLedHandle()		//系统初始化灯效
{
	static u16 Ticks=0;
	static u16 Step=0;
	u8 i=0;
	u8 max=AngleGetAngleKeyNum();
	u16 msk=0;
	
	if(!HubInitLed)
		return;
	
	if(++Ticks>=HUB_INIT_LED_TIME_UNIT)
		Ticks=0;
	else
		return;
	
	Step++;
	
	switch(Step)
	{
		case 1:case 31:
			msk=0x01;
		break;
		case 2:case 30:
			msk=0x03;
		break;
		case 3:case 29:
			msk=0x07;
		break;		
		case 4:case 28:
			msk=0x0f;
		break;
		case 5:case 27:
			msk=0x1f;
		break;
		case 6:case 26:
			msk=0x3f;
		break;
		case 7:case 25:
			msk=0x7f;
		break;
		case 8:
			msk=0xff;
		break;
		
		case 16:
			msk=0;
		break;
		
		case 15:case 17:
			msk=0x80;
		break;
		case 14:case 18:
			msk=0xc0;
		break;
		case 13:case 19:
			msk=0xe0;
		break;
		case 12:case 20:
			msk=0xf0;
		break;
		case 11:case 21:
			msk=0xf8;
		break;
		case 10:case 22:
			msk=0xfc;
		break;
		case 9:case 23:
			msk=0xfe;
		break;
		case 24:
			msk=0xff;
		break;
		
		case 32:
			msk=0;
			HubInitLed=0;
			sLedScanBreath[8].BreathDutyStart=100;
			sLedScanBreath[8].BreathDutyStop=HALF_WHITE_LED;
			sLedScanBreath[8].BreathTimeMs=1000;
			sLedScanBreath[13].BreathDutyStart=100;
			sLedScanBreath[13].BreathDutyStop=HALF_BLUE_LED;
			sLedScanBreath[13].BreathTimeMs=1000;
		break;
		
		default:
			break;
	}
	
	if(Step!=32)
	{
		sLedScanBreath[8].BreathDutyStart=100;
		sLedScanBreath[8].BreathDutyStop=100;
		sLedScanBreath[13].BreathDutyStart=100;
		sLedScanBreath[13].BreathDutyStop=100;
	}
	
	for(i=0;i<max;i++)
	{
		if(msk&(1<<i))
		{
			sLedScanBreath[i].BreathDutyStart=100;
			sLedScanBreath[i].BreathDutyStop=100;
		}
		else
		{
			sLedScanBreath[i].BreathDutyStart=0;
			sLedScanBreath[i].BreathDutyStop=0;
		}
	}
}

#if(1)		//FACTORY RESET 

#define FACTORY_RESET_LED_TICKS		1200
bool FactoryResetLedStatus=false;
u16 FactoryResetLedTicks=0;
bool bHubResetFactory=false;

void HubSet_bHubResetFactory(bool b)
{
	if(b)
	{
		bHubResetFactory=true;
		FactoryResetLedTicks=FACTORY_RESET_LED_TICKS;
	}
	else
	{
		bHubResetFactory=false;
	}
}

void FanLedSameDuty(u8 duty)
{
	sLedScanBreath[9].BreathDutyStart=duty;
	sLedScanBreath[9].BreathDutyStop=duty;
	sLedScanBreath[10].BreathDutyStart=duty;
	sLedScanBreath[10].BreathDutyStop=duty;
	sLedScanBreath[11].BreathDutyStart=duty;
	sLedScanBreath[11].BreathDutyStop=duty;
	sLedScanBreath[12].BreathDutyStart=duty;
	sLedScanBreath[12].BreathDutyStop=duty;
}
void PowerLedSetDuty(u8 duty)
{
	sLedScanBreath[8].BreathDutyStart=duty;
	sLedScanBreath[8].BreathDutyStop=duty;
	sLedScanBreath[13].BreathDutyStart=duty;
	sLedScanBreath[13].BreathDutyStop=duty;
}
void FactoryResetLed()
{
	if(FactoryResetLedTicks)
		FactoryResetLedStatus=true;
	else if(FactoryResetLedStatus)
	{
		FactoryResetLedStatus=false;
		FanLedSameDuty(0);
		PowerLedSetDuty(0);
		Alexa_InitiateFactoryReset();
		return;
	}

	if(FactoryResetLedStatus)
	{
		if(FactoryResetLedTicks<150 || (FactoryResetLedTicks>=300 && FactoryResetLedTicks<450) || (FactoryResetLedTicks>=600 && FactoryResetLedTicks<750)\
			 || (FactoryResetLedTicks>=900 && FactoryResetLedTicks<1050))
		{
			FanLedSameDuty(100);
			PowerLedSetDuty(100);
		}
		else
		{
			FanLedSameDuty(0);
			PowerLedSetDuty(0);
		}
	}
}

#endif

#if(1)		//UGS 

#define UGS_LED_TICKS	900
bool UgsLedStatus=false;
u16 UgsLedTicks=0;
bool bHubUgs=false;

void HubSet_bHubUgs(bool b)
{
	if(b)
	{
		bHubUgs=true;
		UgsLedTicks=UGS_LED_TICKS;
	}
	else
	{
		bHubUgs=false;
	}
}


void UgsLed()
{
	if(UgsLedTicks)
		UgsLedStatus=true;
	else if(UgsLedStatus)
	{
		UgsLedStatus=false;
		FanLedSameDuty(0);
		PowerLedSetDuty(0);
		Alexa_InitiateUserGuidedSetup();
		return;
	}

	if(UgsLedStatus)
	{
		if(UgsLedTicks<150 || (UgsLedTicks>=300 && UgsLedTicks<450) || (UgsLedTicks>=600 && UgsLedTicks<750))
		{
			FanLedSameDuty(100);
			PowerLedSetDuty(100);
		}
		else
		{
			FanLedSameDuty(0);
			PowerLedSetDuty(0);
		}
	}
}

#endif


u8 HubUpdateTouchAngelKeyMskEn()
{
	return AngleSmInitDone();
}

void HubUpdate_gBlink()
{
	static u16 Ticks=0;
	
	if(Ticks<BLINK_UNIT)
		gBlink=0;
	else
		gBlink=1;
	
	if(++Ticks>=BLINK_UNIT*2)
		Ticks=0;
}
u8 HubGet_gBlink()
{
	return gBlink;
}

HubKeyEnum HubGetKey()
{
	return HubKeyNULL;
}

u8 HubGetAngleKeyNum()
{
	return AngleGetAngleKeyNum();
}


u8 HubGetLastAngelSetKeyIdx()
{
	return TouchRetLastAngelSetKeyIdx();
}
u8 HubGetSecondLastAngelSetKeyIdx()
{
	return TouchRetSecondLastAngelSetKeyIdx();
}
u8 HubGetFirstValidAngelSetKeyIdx()
{
	return TouchRetFirstValidAngelSetKeyIdx();
}

#define ANGEL_LED_0		0
#define ANGEL_LED_1		HALF_BLUE_LED
#define ANGEL_LED_2		100



u16 LedInPos;
u16 LedOutPos;

extern uint8_t	SmInitDone;

#define LED_IN_OUT_UNIT			(AngelGetSmFullSteps()/8)

extern u16 LedScanDuty[];

void CalcLedInOutSmPos()
{
	if(SmStepPosObjStart==SmStepPosObjStop)
	{
		
		if(SmClockwise)
		{
			LedInPos=SmStepPosObjStart;
			if(LedInPos>=LED_IN_OUT_UNIT)
				LedInPos-=LED_IN_OUT_UNIT;
			else
				LedInPos=AngelGetSmFullSteps()+LedInPos-LED_IN_OUT_UNIT;
			LedOutPos=SmStepPosObjStop;
		}
		else
		{
			LedOutPos=SmStepPosObjStop;
			LedOutPos+=LED_IN_OUT_UNIT;
			if(LedOutPos>=AngelGetSmFullSteps())
				LedOutPos-=AngelGetSmFullSteps();
			LedInPos=SmStepPosObjStart;
		}
		
		
		return;
	}
	
	
	
	if(SmClockwise)
	{
		LedInPos=SmStepPosObjStart;
//		if(LedInPos>=LED_IN_OUT_UNIT)
//			LedInPos-=LED_IN_OUT_UNIT;
//		else
//			LedInPos=AngelGetSmFullSteps()+LedInPos-LED_IN_OUT_UNIT;
		LedOutPos=SmStepPosObjStop;
	}
	else
	{
		LedOutPos=SmStepPosObjStop;
//		LedOutPos+=LED_IN_OUT_UNIT;
//		if(LedOutPos>=AngelGetSmFullSteps())
//			LedOutPos-=AngelGetSmFullSteps();
		LedInPos=SmStepPosObjStart;
	}
}


static void AngleLedClr()
{
	u8 i=0;
	
	for(i=0;i<8;i++)
	{
		sLedScanBreath[i].BreathDutyStart=0;
		sLedScanBreath[i].BreathDutyStop=0;
	}
}

void AngleLed()
{
	static u16 angel_key_msk=0;
	static SetStatusEnum set_status=NULL;
	u8 i=0;
	
	static u16 angel_key_msk2=0;
	u8 angel_key_msk_change=0;
	
	static u8 AngelLedNormalLightnessFlag=0;
	
	if(HubInitLed)
		return;
	
	if(!SmInitDone)
		return;
	
	if(!gPower)
	{
		AngleLedClr();
		angel_key_msk=0;
		set_status=NULL;
		angel_key_msk2=0;
		AngelLedNormalLightnessFlag=0;
		return;
	}
	
	if(FanSetTicks)
	{
		AngleLedClr();
		return;
	}
//	for(i=0;i<8;i++)
//	{
//		sLedScanBreath[i].BreathDutyStart=100;
//		sLedScanBreath[i].BreathDutyStop=100;
//	}
//	
//	return;
	
	if(angel_key_msk2!=TouchAngelKeyMsk)
	{
		angel_key_msk2=TouchAngelKeyMsk;
		angel_key_msk_change=1;
	}
	
	if(eAngleSet==Adjustable)
	{
		SmArriveStopPosLedTicks=0;
		AngelLedNormalLightnessTicks=ANGEL_LED_NORMAL_LIGHTNESS_TICKS;
		
		if(set_status!=Adjustable)
		{
			set_status=Adjustable;
			angel_key_msk=0;
			
			for(i=0;i<8;i++)
			{
				sLedScanBreath[i].BreathDutyStart=ANGEL_LED_1;
				sLedScanBreath[i].BreathDutyStop=ANGEL_LED_1;
			}
		}
		
		if(angel_key_msk!=TouchAngelKeyMsk)
		{
			for(i=0;i<8;i++)
			{
				if((angel_key_msk&(1<<i)) && (!(TouchAngelKeyMsk&(1<<i))))
				{
//					if(angel_key_msk_change)
						sLedScanBreath[i].BreathDutyStart=sLedScanBreath[i].BreathDutyNow;
//					else
//						sLedScanBreath[i].BreathDutyStart=100;
					sLedScanBreath[i].BreathDutyStop=ANGEL_LED_1;
					sLedScanBreath[i].BreathTimeMs=500;
					
					angel_key_msk&=~(1<<i);
				}
				else
				{
					if(TouchAngelKeyMsk&(1<<i))
					{
						sLedScanBreath[i].BreathDutyStart=100;
						sLedScanBreath[i].BreathDutyStop=100;
						angel_key_msk|=(1<<i);
					}
					else
					{
						sLedScanBreath[i].BreathDutyStart=ANGEL_LED_1;
						sLedScanBreath[i].BreathDutyStop=ANGEL_LED_1;
						angel_key_msk&=~(1<<i);
					}
				}
			}
		}
	}
	else if(eAngleSet==Comfirmed)
	{
		SmArriveStopPosLedTicks=0;
		
		if(set_status!=Comfirmed)
		{
			set_status=Comfirmed;
			angel_key_msk=0;
			
//			AngelLed_AngelComfirmedTicks=600;
		}
		
		for(i=0;i<8;i++)
		{
			if(TouchAngelKeyMsk&(1<<i))
			{
			}
			else
			{
				sLedScanBreath[i].BreathTimeMs=800;
				sLedScanBreath[i].BreathDutyStop=0;
			}
		}
		
		if((AngleSetTicks>=500 && AngleSetTicks<750) || (AngleSetTicks && AngleSetTicks<250))
		{
			for(i=0;i<8;i++)
			{
				if(TouchAngelKeyMsk&(1<<i))
				{
					sLedScanBreath[i].BreathDutyStart=0;
					sLedScanBreath[i].BreathDutyStop=0;
					sLedScanBreath[i].BreathDutyNow=0;
//					LedScanDuty[i]=0;
				}
			}
		}
		else
		{
			for(i=0;i<8;i++)
			{
				if(TouchAngelKeyMsk&(1<<i))
				{
					sLedScanBreath[i].BreathDutyStart=100;
					sLedScanBreath[i].BreathDutyStop=100;
					sLedScanBreath[i].BreathDutyNow=100;
//					LedScanDuty[i]=100;
				}
			}
		}
	}
	else
	{
		if(set_status!=NONE)
		{
			if(set_status==Comfirmed)
			{
				if(!bHubUpdateTouchAngelKeyMskFromApp)
					CalcSmStepPosObj(TouchAngelKeyMsk);
				
				for(i=0;i<8;i++)
				{
//					if(TouchAngelKeyMsk&(1<<i))
//					{
//						sLedScanBreath[i].BreathDutyStart=100;
//						sLedScanBreath[i].BreathDutyStop=100;
//					}
//					else
//					{
//						sLedScanBreath[i].BreathDutyNow=sLedScanBreath[i].BreathDutyStart=100;
//						sLedScanBreath[i].BreathDutyStop=0;
//						sLedScanBreath[i].BreathTimeMs=1000;
//					}
				}
			}
			
			set_status=NONE;
		}
		
		if(AngelGetSmOn())
		{
			if(AngelGetIf_SmStepPosObjStart_Equal_SmStepPosObjStop())
				SmArriveStopPosLedTicks=BLINK_UNIT*4;
			
			if(gRotate>1)
			{
				if(!bHubRotate_OneCircle)
				{
					for(i=0;i<8;i++)
					{
						sLedScanBreath[i].BreathDutyStart=sLedScanBreath[i].BreathDutyStop=100;
					}
				}
				else
				{
					for(i=0;i<8;i++)
					{
						sLedScanBreath[i].BreathDutyStop=0;
						sLedScanBreath[i].BreathTimeMs=2000;
					}
				}
				
				return;
			}
			
//			if(AngelLedNormalLightnessTicks)
			if(!bHubRotate_OneCircle)
			{
				AngelLedNormalLightnessFlag=1;
				
				CalcLedInOutSmPos();
				
				if(LedInPos<=LedOutPos)
				{
					for(i=0;i<8;i++)
					{
						if(AngelLedPosTab[i]>=LedInPos && AngelLedPosTab[i]<LedOutPos)
						{
							sLedScanBreath[i].BreathDutyStart=0;
							sLedScanBreath[i].BreathDutyStop=100;
							sLedScanBreath[i].BreathTimeMs=2000;
						}
						else
						{
							sLedScanBreath[i].BreathDutyStart=100;
							sLedScanBreath[i].BreathDutyStop=0;
							sLedScanBreath[i].BreathTimeMs=2000;
						}
					}
				}
				else
				{
					for(i=0;i<8;i++)
					{
						if(AngelLedPosTab[i]>=LedInPos || AngelLedPosTab[i]<LedOutPos)
						{
							sLedScanBreath[i].BreathDutyStart=0;
							sLedScanBreath[i].BreathDutyStop=100;
							sLedScanBreath[i].BreathTimeMs=2000;
						}
						else
						{
							sLedScanBreath[i].BreathDutyStart=100;
							sLedScanBreath[i].BreathDutyStop=0;
							sLedScanBreath[i].BreathTimeMs=2000;
						}
					}
				}

			}
			else
			{
				CalcLedInOutSmPos();
				
				if(LedInPos<=LedOutPos)
				{
					for(i=0;i<8;i++)
					{
						if(AngelLedPosTab[i]>=LedInPos && AngelLedPosTab[i]<LedOutPos)
						{
							if(AngelLedNormalLightnessFlag)
								sLedScanBreath[i].BreathDutyStart=sLedScanBreath[i].BreathDutyNow;
							else if(sLedScanBreath[i].BreathDutyNow==sLedScanBreath[i].BreathDutyStop)
								sLedScanBreath[i].BreathDutyStart=0;
							sLedScanBreath[i].BreathDutyStop=ANGEL_LED_1;
							sLedScanBreath[i].BreathTimeMs=2000;
						}
						else
						{
							if(AngelLedNormalLightnessFlag)
								sLedScanBreath[i].BreathDutyStart=sLedScanBreath[i].BreathDutyNow;
							else if(sLedScanBreath[i].BreathDutyNow==sLedScanBreath[i].BreathDutyStop)
								sLedScanBreath[i].BreathDutyStart=ANGEL_LED_1;
							sLedScanBreath[i].BreathDutyStop=0;
							sLedScanBreath[i].BreathTimeMs=2000;
						}
					}
				}
				else
				{
					for(i=0;i<8;i++)
					{
						if(AngelLedPosTab[i]>=LedInPos || AngelLedPosTab[i]<LedOutPos)
						{
							if(AngelLedNormalLightnessFlag)
								sLedScanBreath[i].BreathDutyStart=sLedScanBreath[i].BreathDutyNow;
							else if(sLedScanBreath[i].BreathDutyNow==sLedScanBreath[i].BreathDutyStop)
								sLedScanBreath[i].BreathDutyStart=0;
							sLedScanBreath[i].BreathDutyStop=ANGEL_LED_1;
							sLedScanBreath[i].BreathTimeMs=2000;
						}
						else
						{
							if(AngelLedNormalLightnessFlag)
								sLedScanBreath[i].BreathDutyStart=sLedScanBreath[i].BreathDutyNow;
							else if(sLedScanBreath[i].BreathDutyNow==sLedScanBreath[i].BreathDutyStop)
								sLedScanBreath[i].BreathDutyStart=ANGEL_LED_1;
							sLedScanBreath[i].BreathDutyStop=0;
							sLedScanBreath[i].BreathTimeMs=2000;
						}
					}
				}
				 AngelLedNormalLightnessFlag=0;
			}
		}
		else
		{
			if((SmArriveStopPosLedTicks && SmArriveStopPosLedTicks<BLINK_UNIT) || (SmArriveStopPosLedTicks>=BLINK_UNIT*2 && SmArriveStopPosLedTicks<BLINK_UNIT*3))
			{
				sLedScanBreath[0].BreathDutyStart=100;
				sLedScanBreath[0].BreathDutyStop=100;
				
				for(i=1;i<8;i++)
				{
					if(TouchAngelKeyMsk&(1<<i))
					{
						sLedScanBreath[i].BreathDutyStart=100;
						sLedScanBreath[i].BreathDutyStop=100;
					}
					else
					{
						sLedScanBreath[i].BreathDutyStart=0;
						sLedScanBreath[i].BreathDutyStop=0;
					}
				}
			}
			else
			{
				for(i=0;i<8;i++)
				{
					sLedScanBreath[i].BreathDutyStart=0;
					sLedScanBreath[i].BreathDutyStop=0;
				}
			}
		}
	}
}


void FanLedHandle(u8 fan)
{
	switch(fan)
	{
		case 1:
			sLedScanBreath[9].BreathDutyStart=100;
			sLedScanBreath[9].BreathDutyStop=100;
			sLedScanBreath[10].BreathDutyStart=0;
			sLedScanBreath[10].BreathDutyStop=0;
			sLedScanBreath[11].BreathDutyStart=0;
			sLedScanBreath[11].BreathDutyStop=0;
			sLedScanBreath[12].BreathDutyStart=0;
			sLedScanBreath[12].BreathDutyStop=0;
		break;
		
		case 2:
			sLedScanBreath[9].BreathDutyStart=100;
			sLedScanBreath[9].BreathDutyStop=100;
			sLedScanBreath[10].BreathDutyStart=100;
			sLedScanBreath[10].BreathDutyStop=100;
			sLedScanBreath[11].BreathDutyStart=0;
			sLedScanBreath[11].BreathDutyStop=0;
			sLedScanBreath[12].BreathDutyStart=0;
			sLedScanBreath[12].BreathDutyStop=0;
		break;
		
		case 3:
			sLedScanBreath[9].BreathDutyStart=100;
			sLedScanBreath[9].BreathDutyStop=100;
			sLedScanBreath[10].BreathDutyStart=100;
			sLedScanBreath[10].BreathDutyStop=100;
			sLedScanBreath[11].BreathDutyStart=100;
			sLedScanBreath[11].BreathDutyStop=100;
			sLedScanBreath[12].BreathDutyStart=0;
			sLedScanBreath[12].BreathDutyStop=0;
		break;
		
		case 4:
			sLedScanBreath[9].BreathDutyStart=100;
			sLedScanBreath[9].BreathDutyStop=100;
			sLedScanBreath[10].BreathDutyStart=100;
			sLedScanBreath[10].BreathDutyStop=100;
			sLedScanBreath[11].BreathDutyStart=100;
			sLedScanBreath[11].BreathDutyStop=100;
			sLedScanBreath[12].BreathDutyStart=100;
			sLedScanBreath[12].BreathDutyStop=100;
		break;
		
		default:
			sLedScanBreath[9].BreathDutyStart=0;
			sLedScanBreath[9].BreathDutyStop=0;
			sLedScanBreath[10].BreathDutyStart=0;
			sLedScanBreath[10].BreathDutyStop=0;
			sLedScanBreath[11].BreathDutyStart=0;
			sLedScanBreath[11].BreathDutyStop=0;
			sLedScanBreath[12].BreathDutyStart=0;
			sLedScanBreath[12].BreathDutyStop=0;
			break;
	}
}
void FanLedHandleFadeDown(u8 fan)
{
	switch(fan)
	{
		case 1:
			sLedScanBreath[9].BreathDutyStart=100;
			sLedScanBreath[9].BreathDutyStop=0;
			sLedScanBreath[9].BreathTimeMs=1000;
			sLedScanBreath[10].BreathDutyStart=0;
			sLedScanBreath[10].BreathDutyStop=0;
			sLedScanBreath[11].BreathDutyStart=0;
			sLedScanBreath[11].BreathDutyStop=0;
			sLedScanBreath[12].BreathDutyStart=0;
			sLedScanBreath[12].BreathDutyStop=0;
		break;
		
		case 2:
			sLedScanBreath[9].BreathDutyStart=100;
			sLedScanBreath[9].BreathDutyStop=0;
			sLedScanBreath[9].BreathTimeMs=1000;
			sLedScanBreath[10].BreathDutyStart=100;
			sLedScanBreath[10].BreathDutyStop=0;
			sLedScanBreath[10].BreathTimeMs=1000;
			sLedScanBreath[11].BreathDutyStart=0;
			sLedScanBreath[11].BreathDutyStop=0;
			sLedScanBreath[12].BreathDutyStart=0;
			sLedScanBreath[12].BreathDutyStop=0;
		break;
		
		case 3:
			sLedScanBreath[9].BreathDutyStart=100;
			sLedScanBreath[9].BreathDutyStop=0;
			sLedScanBreath[9].BreathTimeMs=1000;
			sLedScanBreath[10].BreathDutyStart=100;
			sLedScanBreath[10].BreathDutyStop=0;
			sLedScanBreath[10].BreathTimeMs=1000;
			sLedScanBreath[11].BreathDutyStart=100;
			sLedScanBreath[11].BreathDutyStop=0;
			sLedScanBreath[11].BreathTimeMs=1000;
			sLedScanBreath[12].BreathDutyStart=0;
			sLedScanBreath[12].BreathDutyStop=0;
		break;
		
		case 4:
			sLedScanBreath[9].BreathDutyStart=100;
			sLedScanBreath[9].BreathDutyStop=0;
			sLedScanBreath[9].BreathTimeMs=1000;
			sLedScanBreath[10].BreathDutyStart=100;
			sLedScanBreath[10].BreathDutyStop=0;
			sLedScanBreath[10].BreathTimeMs=1000;
			sLedScanBreath[11].BreathDutyStart=100;
			sLedScanBreath[11].BreathDutyStop=0;
			sLedScanBreath[11].BreathTimeMs=1000;
			sLedScanBreath[12].BreathDutyStart=100;
			sLedScanBreath[12].BreathDutyStop=0;
			sLedScanBreath[12].BreathTimeMs=1000;
		break;
		
		default:
			sLedScanBreath[9].BreathDutyStart=0;
			sLedScanBreath[9].BreathDutyStop=0;
			sLedScanBreath[10].BreathDutyStart=0;
			sLedScanBreath[10].BreathDutyStop=0;
			sLedScanBreath[11].BreathDutyStart=0;
			sLedScanBreath[11].BreathDutyStop=0;
			sLedScanBreath[12].BreathDutyStart=0;
			sLedScanBreath[12].BreathDutyStop=0;
			break;
	}
}

void FanLed()
{
	static SetStatusEnum set_status=NULL;
	
//	if(HubInitLed)
//		return;
	if(UgsLedStatus)
		return;
	if(FactoryResetLedStatus)
		return;
	
	if(eFanSet==Adjustable)
	{
		FanLedHandle(gFan);
	}
	else if(eFanSet==Comfirmed)
	{
		if(set_status!=Comfirmed)
		{
			set_status=Comfirmed;
		}
		
		
		if((FanSetTicks>=600 && FanSetTicks<800) || (FanSetTicks>=200 && FanSetTicks<400))
			FanLedHandle(gFan);
		else if(FanSetTicks<200)
			FanLedHandleFadeDown(gFan);
		else
			FanLedHandle(0);
//		if(gBlink)
//		{
//			FanLedHandle(gFan);
//		}
//		else
//		{
//			FanLedHandle(0);
//		}
	}
	else
	{
		if(set_status!=NONE)
		{
			if(set_status==Comfirmed)
			{
			}
			
			set_status=NONE;
		}
		FanLedHandleFadeDown(gFan);
		//FanLedHandle(0);
	}
}

void PowerLed()
{
	static u8 hub_init=0;
	
	if(HubInitLed)
	{
		hub_init=1;
//		return;
	}
	if(UgsLedStatus)
		return;
	if(FactoryResetLedStatus)
		return;
	
	if(PowerDispTicks || HubInitLed || AngleSetTicks || FanSetTicks)
	{
		hub_init=0;
		
		sLedScanBreath[8].BreathDutyStart=100;
		sLedScanBreath[8].BreathDutyStop=100;
		
		sLedScanBreath[13].BreathDutyStart=100;
		sLedScanBreath[13].BreathDutyStop=100;
	}
	else if(gPower)
	{
		hub_init=0;
		
		sLedScanBreath[8].BreathDutyStart=100;
		sLedScanBreath[8].BreathDutyStop=HALF_WHITE_LED;
		sLedScanBreath[8].BreathTimeMs=500;
		
		sLedScanBreath[13].BreathDutyStart=100;
		sLedScanBreath[13].BreathDutyStop=POWER_ON_HALF_BLUE_LED;
		sLedScanBreath[13].BreathTimeMs=500;
	}
	else 
	{
		if(hub_init)
		{
			sLedScanBreath[8].BreathDutyStart=100;
			sLedScanBreath[8].BreathDutyStop=POWER_OFF_WHITE_LED_PER;
			sLedScanBreath[8].BreathTimeMs=500;
			
			sLedScanBreath[13].BreathDutyStart=100;
			sLedScanBreath[13].BreathDutyStop=POWER_OFF_BLUE_LED_PER;
			sLedScanBreath[13].BreathTimeMs=500;
			
			if(sLedScanBreath[8].BreathDutyStart==sLedScanBreath[8].BreathDutyNow)
				hub_init=0;
		}
		else
		{
//			sLedScanBreath[8].BreathDutyStart=HALF_WHITE_LED;
			sLedScanBreath[8].BreathDutyStop=POWER_OFF_WHITE_LED_PER;
//			sLedScanBreath[13].BreathDutyStart=HALF_BLUE_LED;
			sLedScanBreath[13].BreathDutyStop=POWER_OFF_BLUE_LED_PER;
		}
	}
	
	
}

u8 IfValidVal(u16 ctx,u16 start,u16 stop)
{
	if(start>stop)
	{
		if((ctx>=start) || (ctx<=stop))
			return 1;
		return 0;
	}
	if(start<stop)
	{
		if((ctx>=start) && (ctx<=stop))
			return 1;
		return 0;
	}
	
	return 0;
}
u8 IfValidVal_StartBiggerThanStop(u16 ctx,u16 start,u16 stop)
{
	if((ctx>=start) || (ctx<stop))
		return 1;
	return 0;
}
u8 IfValidVal_StartSmallerThanStop(u16 ctx,u16 start,u16 stop)
{
	if((ctx>=start) && (ctx<stop))
		return 1;
	return 0;
}









void HubPowerOnActRestoreOsc()
{
	AngleSetTicks=SET_TICKS_COMFIRMED;
	
}


void HubCalcSmStepPosObj_BaseRodateValue(u8 rotate)
{
	bHubUpdateTouchAngelKeyMskFromApp=true;
	
	AngleSetTicks=SET_TICKS_ADJUSTABLE;
	FanSetTicks=0;
	PowerDispTicks=POWER_DISP_TICKS;
	SmEnable=0;
	gOscAngel=0;
	
	gRotate=rotate;
	if(gRotate>1)
	{
		TouchAngelKeyMsk=0xff;
	}
	else
	{
		TouchAngelKeyMsk=0;
	}
	
	CalcSmStepPosObj_BaseRodateValue(gRotate);
	
	if(!gPower)
	{
		gPower=1;
		gFan = FanSave;
	}
}

void HubUpdateTouchAngelKeyMskFromApp(u16 ctx)
{
	u32 msk=0;
	
	bHubUpdateTouchAngelKeyMskFromApp=true;
	
	AngleSetTicks=SET_TICKS_ADJUSTABLE;
	FanSetTicks=0;
	PowerDispTicks=POWER_DISP_TICKS;
	SmEnable=0;
	gOscAngel=0;
	gRotateSwitch=0;
	gRotate=1;
	
	if(ctx<=6)
		bHubWindDirection180_SmDirClockwise=true;
	else
		bHubWindDirection180_SmDirClockwise=false;
	
	switch(ctx)
	{
		case 1:
			msk=(1<<16);TouchAngelKeyMsk=(1<<4);
		break;
		
		case 2:
			msk=(1<<12);TouchAngelKeyMsk=(1<<3);
		break;
		
		case 3:
			msk=(1<<8);TouchAngelKeyMsk=(1<<2);
		break;
		
		case 4:
			msk=(1<<4);TouchAngelKeyMsk=(1<<1);
		break;
		
		case 5:
			msk=(1<<2);TouchAngelKeyMsk=(1<<1);
		break;
		
		case 6:
			msk=1;TouchAngelKeyMsk=(1<<0);
		break;
		
		case 11:
			msk=(1<<16);TouchAngelKeyMsk=(1<<4);
		break;
		
		case 10:
			msk=(1<<20);TouchAngelKeyMsk=(1<<5);
		break;
		
		case 9:
			msk=(1<<24);TouchAngelKeyMsk=(1<<6);
		break;
		
		case 8:
			msk=(1<<28);TouchAngelKeyMsk=(1<<7);
		break;
		
		case 7:
			msk=(1<<30);TouchAngelKeyMsk=(1<<7);
		break;
		
		default:
			break;
	}
	
	
	CalcSmStepPosObjFromApp(msk);
	
//	TouchAngelKeyMsk=(1<<tmp);
	
	
	
	if(!gPower)
	{
		gPower=1;
		gFan = FanSave;
	}
}

void HubUpdateTouchAngelKeyMskFromAppRange(u16 ctx)
{
	u32 msk=0;
	
	bHubUpdateTouchAngelKeyMskFromApp=true;
	
	AngleSetTicks=SET_TICKS_ADJUSTABLE;
	FanSetTicks=0;
	PowerDispTicks=POWER_DISP_TICKS;
	SmEnable=0;
	gWindDirection=DEFAULT_WIND_DIRECTION;
	gRotate=1;
	
	TouchAngelKeyMsk=0;
	
	if(!ctx)
		;
	else if(ctx<90)
	{
		TouchAngelKeyMsk|=1;
	}
	else if(ctx<180)
	{
		TouchAngelKeyMsk|=(1<<0);
		TouchAngelKeyMsk|=(1<<7);
		TouchAngelKeyMsk|=(1<<1);
	}
	else if(ctx<270)
	{
		TouchAngelKeyMsk|=(1<<6);
		TouchAngelKeyMsk|=(1<<7);
		TouchAngelKeyMsk|=(1<<0);
		TouchAngelKeyMsk|=(1<<1);
		TouchAngelKeyMsk|=(1<<2);
	}
	else if(ctx<360)
	{
		TouchAngelKeyMsk|=(1<<5);
		TouchAngelKeyMsk|=(1<<6);
		TouchAngelKeyMsk|=(1<<7);
		TouchAngelKeyMsk|=(1<<0);
		TouchAngelKeyMsk|=(1<<1);
		TouchAngelKeyMsk|=(1<<2);
		TouchAngelKeyMsk|=(1<<3);
	}
	else
	{
		TouchAngelKeyMsk=0xff;
	}
	
	CalcSmStepPosObjBaseOnExactAngel(ctx);
	
//	if(!gPower)
//	{
//		gPower=1;
//		gFan = FanSave;
//	}
	
	if(TouchAngelKeyMsk)
		gRotateSwitch=1;
	else 
		gRotateSwitch=0;
}

void HubUpdateTouchAngelKeyMsk()
{
	u8 i=0;
	u16 start_idx=0;
	u16 stop_idx=0;
	u8 num=0;
	
	if(eAngleSet!=NONE)
		return;
	
	if(!TouchAngelKeyMsk)
		return;
	
	start_idx=HubAngelLedStartSmPos;
	stop_idx=HubAngelLedStopSmPos;
	num=AngleGetAngleKeyNum();
	
	if(AngleGetSmStepPosObjStart()==AngleGetSmStepPosObjStop())		//�϶�������
	{
//		if(AngleGetSmStepPosObjStart()!=AngleGetSmStepPosObjStop())
//		{
//			for(i=0;i<num;i++)
//			{
//				TouchAngelKeyMsk|=(1<<i);
//			}
//			return;
//		}
		
		for(i=0;i<num;i++)
		{
			if(IfValidVal(AngelLedPosTab[i],start_idx,stop_idx))
				TouchAngelKeyMsk|=(1<<i);
			else
				TouchAngelKeyMsk&=~(1<<i);
		}
	}
	else if(start_idx>stop_idx)
	{
		for(i=0;i<num;i++)
		{
			if(IfValidVal_StartBiggerThanStop(AngelLedPosTab[i],start_idx,stop_idx))
				TouchAngelKeyMsk|=(1<<i);
			else
				TouchAngelKeyMsk&=~(1<<i);
		}
	}
	else if(start_idx<stop_idx)
	{
		for(i=0;i<num;i++)
		{
			if(IfValidVal_StartSmallerThanStop(AngelLedPosTab[i],start_idx,stop_idx))
				TouchAngelKeyMsk|=(1<<i);
			else
				TouchAngelKeyMsk&=~(1<<i);
		}
	}
	else
	{
		for(i=0;i<num;i++)
		{
			TouchAngelKeyMsk|=(1<<i);
		}
	}
}

void HubResetSmPra()
{
	SmResetPra();
}


void HubFanSetDuty()
{
	if(gPower==false)
	{
		FanSetDuty(0);
		return;
	}
	
	switch(gFan)
	{
		case 1:
			FanSetDuty(25);
		break;
		
		case 2:
			FanSetDuty(50);
		break;
		
		case 3:
			FanSetDuty(75);
		break;
		
		case 4:
			FanSetDuty(100);
		break;
		
		default:
			FanSetDuty(0);
		break;
	}
}



u16 GetFanSaveDelay=100;

void HubGetFanSave()
{
	if(FanSave!=0xff)
		return;
	
//	if(GetFanSaveDelay)
	{
		if(!GetFanSaveDelay)
		{
			UART2_SendCmd_Get_EEPROM();
			GetFanSaveDelay=100;
			return;
		}
	}
	
//	if(!GetFanSaveDelay)
		
}


void HubMainHandle()
{
//	if(!HubInitLed)
	{
		TouchLongKeyHandle();
		TouchHandle(eHubKey);
	}
	eHubKey=HubKeyNULL;
	
	AngleLed();
	PowerLed();
	FanLed();
	FactoryResetLed();
	UgsLed();
	
	HubFanSetDuty();
	
	HubUpdateTouchAngelKeyMsk();
	
	if(gPower && eAngleSet==NONE && !AngleSetTicks && !eFanSet && TouchKeyNull)
	{
//		if(gOscAngel || gRotate>1 || (!AngelGetIf_SmStepPosObjStart_Equal_SmStepPosObjStop))
		if(!AngelGetIf_SmStepPosObjStart_Equal_SmStepPosObjStop())
		{
			if(gRotateSwitch)
				SmEnable=1;
			else
				SmEnable=0;
		}
		else
			SmEnable=1;
	}
	else
		SmEnable=0;
	
	HubAlexaAutoSendChangeReportDueToLocalControl(false);
	FanSaveHandle();
	
	HubGetFanSave();
}

u8 HubGetAngleSetTicks()
{
	return AngleSetTicks;
}

void HubIntLoopSlow()
{
	if(AngleSetTicks && !FanSetTicks)
		AngleSetTicks--;
	if(FanSetTicks)
		FanSetTicks--;
	if(PowerDispTicks)
		PowerDispTicks--;
	if(SmArriveStopPosLedTicks)
		SmArriveStopPosLedTicks--;
	if(AngelLedNormalLightnessTicks)
		AngelLedNormalLightnessTicks--;
	if(UgsLedTicks)
		(UgsLedTicks)--;
	if(FactoryResetLedTicks)
		FactoryResetLedTicks--;
	if(GetFanSaveDelay)
		GetFanSaveDelay--;	
	
	TouchLongKeyTicksAdd();
	HubAlexaAutoSendChangeReportDueToLocalControlDelayHandle();
	
	HubUpdate_gBlink();
	LedScanBreathHandle();
	SmRunHandle();
	HubInitLedHandle();
}

void HubIntLoopFast()
{
	LedScanHandle();
	FanHandle();
}



void HubPowerSwitch(bool onoff)
{
    gPower=onoff;
	TouchPowerSwitch(gPower);
}



u8 HubSetFan(u8 fan)
{
	return TouchSetFan(fan);
}




//extern void Alexa_SendChangeReportDueToLocalControl(void);

void HubAlexa_SendChangeReportDueToLocalControl()
{
//	Alexa_SendChangeReportDueToLocalControl();
}






