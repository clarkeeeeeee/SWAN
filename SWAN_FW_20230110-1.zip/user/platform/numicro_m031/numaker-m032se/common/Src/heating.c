#include "heating.h"

#include "off_base.h"
#include "low_water.h"
#include "remote_counter.h"
#include "dev.h"
#include "keep_warm.h"
#include "metrics.h"
#include "board.h"


bool gbHeating=false;
uint32_t HeatingTicks=0;
bool gbHeatRelay=false;
bool bHeatingDone=false;
bool gbTemp100HeatDone=false;

uint16_t HighAltitudeTestTicks=0;
bool bHighAltitudeTest=false;
uint32_t ReadyStatusRemain=0;
bool gbReadyStatus=false;

uint16_t HeatingCondition_TempNowOld;

typedef enum
{
	eHeatingCondition__TheResultOf_TempSetMinusTempNow_BiggerThan5,
	eHeatingCondition__TheResultOf_TempNowMinusTempSet_EqualOrBiggerThan0,
	eHeatingCondition__TempSetEqualOrSmallerThan98,
	eHeatingCondition__TempSetBiggerThan98_AndTempNowSmallerThan98,
	eHeatingCondition__TempSetBiggerThan98_AndTempNowEqualOrBiggerThan98,
	eHeatingCondition__TheResultOf_TempSetMinusTempNow_BiggerThan10,
	eHeatingCondition__Other,
}eHeatingCondition_t;
eHeatingCondition_t eHeatingCondition;

void HeatingReheat()
{
	bHeatingDone=false;
	gbReadyStatus=false;
	KeepWarmStop();
	gbHeating=true;
}
bool HeatintRetStatus()
{
	return gbHeating;
}
bool HeatintRetHeatingDone()
{
	return bHeatingDone;
}

static void HighAltitudeTest()
{
	static uint16_t TempNow_Celsius_Bkp;
	
	if(gbHeating)
	{
		if(!bHighAltitudeTest)
		{
			if(TempNow_Celsius>=85)
				bHighAltitudeTest=true;
			HighAltitudeTestTicks=0;
		}
		else
		{
			if(TempNow_Celsius<85)
			{
				HighAltitudeTestTicks=0;
				bHighAltitudeTest=false;
				return;
			}
			
			if((HighAltitudeTestTicks%100)==0)
			{
				if(HighAltitudeTestTicks && TempNow_Celsius>TempNow_Celsius_Bkp)
					HighAltitudeTestTicks=0;
				TempNow_Celsius_Bkp=TempNow_Celsius;
			}
			
			if(++HighAltitudeTestTicks>=HIGH_ALTITUDE_TEST_TICKS)
			{
				HighAltitudeTestTicks=0;
				gbHeatRelay=false;
				gbHeating=false;
//				KeepWarmStart();
				HeatingTicks=0;
				if(!bHeatingDone)
				{
					bHeatingDone=true;
					Metrics_SetKettleLocation_BP(TempNow_Celsius);
				}
			}
		}
	}
	else
	{
		HighAltitudeTestTicks=0;
		bHighAltitudeTest=false;
	}
}

#define TEMPRATURE_HIGH		97

static bool UpdateHeatingCondition()
{
	bool ret=false;
	
	if(TempNow_Celsius==0xff)
		return false;
	
	#if !RELAY_CTRL_WITH_ALGORITHM
	if(TempNow_Celsius>=TempSet_Celsius)
	{
		if(eHeatingCondition!=eHeatingCondition__TheResultOf_TempNowMinusTempSet_EqualOrBiggerThan0)
		{
			HeatingTicks=0;
			ret=true;
		}
		eHeatingCondition=eHeatingCondition__TheResultOf_TempNowMinusTempSet_EqualOrBiggerThan0;
	}
	else
	{
		if(eHeatingCondition!=eHeatingCondition__TheResultOf_TempSetMinusTempNow_BiggerThan10)
		{
			HeatingTicks=0;
			ret=true;
		}
		eHeatingCondition=eHeatingCondition__TheResultOf_TempSetMinusTempNow_BiggerThan10;
	}
	
	return ret;
	#else
	
	if((TempSet_Celsius>=TEMPRATURE_HIGH && TempNow_Celsius<TempSet_Celsius && (TempSet_Celsius-TempNow_Celsius)>5)\
		|| (TempNow_Celsius<TempSet_Celsius && (TempSet_Celsius-TempNow_Celsius)>10)\
		|| (TempSet_Celsius==100 && TempNow_Celsius<TEMPRATURE_HIGH))
	{
		if(eHeatingCondition!=eHeatingCondition__TheResultOf_TempSetMinusTempNow_BiggerThan10)
		{
			HeatingTicks=0;
			ret=true;
		}
		eHeatingCondition=eHeatingCondition__TheResultOf_TempSetMinusTempNow_BiggerThan10;
	}
	else if(TempNow_Celsius<TempSet_Celsius && (TempSet_Celsius-TempNow_Celsius)>5)
	{
		if(eHeatingCondition!=eHeatingCondition__TheResultOf_TempSetMinusTempNow_BiggerThan5)
		{
			HeatingTicks=0;
			ret=true;
		}
		eHeatingCondition=eHeatingCondition__TheResultOf_TempSetMinusTempNow_BiggerThan5;
	}
	else if(TempNow_Celsius>=TempSet_Celsius)
	{
		if(eHeatingCondition!=eHeatingCondition__TheResultOf_TempNowMinusTempSet_EqualOrBiggerThan0)
		{
			HeatingTicks=0;
			ret=true;
		}
		eHeatingCondition=eHeatingCondition__TheResultOf_TempNowMinusTempSet_EqualOrBiggerThan0;
	}
	else if(TempSet_Celsius<TEMPRATURE_HIGH)
	{
		if(eHeatingCondition!=eHeatingCondition__TempSetEqualOrSmallerThan98)
		{
			HeatingTicks=0;
			ret=true;
		}
		eHeatingCondition=eHeatingCondition__TempSetEqualOrSmallerThan98;
	}
	else if(TempSet_Celsius>=TEMPRATURE_HIGH && TempNow_Celsius<TEMPRATURE_HIGH)
	{
		if(eHeatingCondition!=eHeatingCondition__TempSetBiggerThan98_AndTempNowSmallerThan98)
		{
			HeatingTicks=0;
			ret=true;
		}
		eHeatingCondition=eHeatingCondition__TempSetBiggerThan98_AndTempNowSmallerThan98;
	}
	else if(TempSet_Celsius>=TEMPRATURE_HIGH && TempNow_Celsius>=TEMPRATURE_HIGH)
	{
		if(eHeatingCondition!=eHeatingCondition__TempSetBiggerThan98_AndTempNowEqualOrBiggerThan98)
		{
			HeatingTicks=0;
			ret=true;
		}
		eHeatingCondition=eHeatingCondition__TempSetBiggerThan98_AndTempNowEqualOrBiggerThan98;
	}
	else
	{
		eHeatingCondition=eHeatingCondition__Other;
		HeatingTicks=0;
	}
	
	return ret;
	#endif
}

#define HEAT_DIFF		1

void UpdateKeepWarmMinutesFromReadyStatusRemain()
{
	if((ReadyStatusRemain%KEEP_WARM_MINUTES__TOTAL_MS)==0)
		KeepWarmMinutes=ReadyStatusRemain/KEEP_WARM_MINUTES__TOTAL_MS;
	else
		KeepWarmMinutes=ReadyStatusRemain/KEEP_WARM_MINUTES__TOTAL_MS+1;
}

void HeatingHandle()
{
	bool bHeatingConditionX=false;
	static bool bHeatingCondition_TempNowOld_Used=false;
	static bool bHeatingCondition_RelayOn5s=false;
	
	static uint8_t FinallyIntermittentHeating=0;
	
	if(!gbPower || gbLowWater)
	{
		gbHeating=false;
		gbHeatRelay=false;
		bHeatingDone=false;
		if(!gbPower)
			gbReadyStatus=false;
		bHeatingCondition_RelayOn5s=false;
		eHeatingCondition=eHeatingCondition__Other;
		FinallyIntermittentHeating=0;
		if(gbReadyStatus)
			goto HeatingHandle_gbReadyStatus;
		return;
	}
//	if(gbOffBase)
//	{
//		gbHeatRelay=false;
//		bHeatingDone=false;
//		bHeatingCondition_RelayOn5s=false;
//		eHeatingCondition=eHeatingCondition__Other;
//		return;
//	}
	if(bHeatingDone)
	{
		gbHeatRelay=false;
		bHeatingCondition_RelayOn5s=false;
//		if(!KeepWarmMinutesBkp)
//		{
//			UpdateKeepWarmMinutesFromReadyStatusRemain();
//		}
//		if(HeatingTicks>=10000)
		{
			bHeatingDone=false;
			
			#ifdef NEW_APP_API
			if(gBoilCounts>0)
				gBoilCounts--;
			#endif
			
			if(KeepWarmMinutesBkp && gbKeepWarmSwitch)
				KeepWarmStart();
			else
			{
				DevPowerOff();
				
				#if PCB_US
				if(PreSet>10)
				#else
				if(PreSet==6)
				#endif
					gbTemp100HeatDone=true;
			}
			BuzzerTimeUnit=100;
			BuzzerTime=BuzzerTimeUnit*3;
		}
		gbReadyStatus=false;
		ReadyStatusRemain=0;
//		gbReadyStatus=true;
//		ReadyStatusRemain=READY_STATUS_REMAIN;
		return;
	}
	
	HeatingHandle_gbReadyStatus:
	if(gbReadyStatus)
	{
		gbHeatRelay=false;
		
		bHeatingCondition_RelayOn5s=false;
		
		if(!KeepWarmMinutesBkp && gbPower)
		{
			UpdateKeepWarmMinutesFromReadyStatusRemain();
		}
		
		if(!ReadyStatusRemain)
		{
			if(gbPower)
				KeepWarmStart();
			else
			{
				KeepWarmResetKeepWarmMinutes();
				KeepWarmReloadKeepWarmTime();
			}
			gbReadyStatus=false;
		}
		return;
	}
	
	if(KeepWarmRetStatus())
	{
		gbHeating=false;
		gbHeatRelay=false;
		return;
	}
	
	if(DevGetTempSetStatus())
	{
		bHeatingCondition_RelayOn5s=false;
		gbHeatRelay=false;
		return;
	}
	
	bHeatingConditionX=UpdateHeatingCondition();
	
	switch(eHeatingCondition)
	{
		case eHeatingCondition__TheResultOf_TempSetMinusTempNow_BiggerThan10:
			gbHeatRelay=true;
			gbHeating=true;
		break;
		
		case eHeatingCondition__TheResultOf_TempSetMinusTempNow_BiggerThan5:
//			gbHeatRelay=true;
			if(bHeatingConditionX)
			{
				HeatingCondition_TempNowOld=TempNow_Celsius;
				bHeatingCondition_TempNowOld_Used=false;
				HeatingTicks=0;
				bHeatingCondition_RelayOn5s=false;
			}
			
			if(HeatingTicks<HEAT_HOLD_TIME)
			{
				gbHeatRelay=true;
				if(TempNow_Celsius>(HeatingCondition_TempNowOld+HEAT_DIFF))
				{
					bHeatingCondition_RelayOn5s=false;
					HeatingTicks=HEAT_HOLD_TIME;
//					HeatingCondition_TempNowOld=TempNow_Celsius;
				}
			}
			else
			{
				if(bHeatingCondition_RelayOn5s)
				{
					if(TempNow_Celsius>(HeatingCondition_TempNowOld+HEAT_DIFF))
					{
						bHeatingCondition_RelayOn5s=false;
						HeatingTicks=HEAT_HOLD_TIME;
//						HeatingCondition_TempNowOld=TempNow_Celsius;
					}
					else if(HeatingTicks>=700)
					{
						HeatingTicks=0;
						HeatingCondition_TempNowOld=TempNow_Celsius;
					}
				}
				else 
				{
					gbHeatRelay=false;
					if(HeatingTicks>=1200)
					{
						if(TempNow_Celsius<=(HeatingCondition_TempNowOld+HEAT_DIFF))
						{
							//bHeatingCondition_RelayOn5s=true;
							HeatingTicks=0;
						}
						else
						{
							bHeatingCondition_RelayOn5s=false;
							HeatingTicks=0;
						}
						
						HeatingCondition_TempNowOld=TempNow_Celsius;
					}
				}
			}
			gbHeating=true;
		break;
		case eHeatingCondition__TheResultOf_TempNowMinusTempSet_EqualOrBiggerThan0:
			gbHeatRelay=false;
			gbHeating=false;
//			KeepWarmStart();
			if(!bHeatingDone)
			{
				bHeatingDone=true;
				HeatingTicks=0;
//				Metrics_SetKettleLocation_BP(TempNow_Celsius);
			}
		break;
		
		case eHeatingCondition__TempSetEqualOrSmallerThan98:
//		case eHeatingCondition__TempSetBiggerThan98_AndTempNowSmallerThan98:
			if(bHeatingConditionX)
			{
				HeatingCondition_TempNowOld=TempNow_Celsius;
				bHeatingCondition_TempNowOld_Used=false;
				bHeatingCondition_RelayOn5s=false;
				HeatingTicks=0;
			}
			
			if(HeatingTicks<HEAT_HOLD_TIME)
			{
				gbHeatRelay=true;
				if(TempNow_Celsius>(HeatingCondition_TempNowOld+HEAT_DIFF))
				{
					bHeatingCondition_RelayOn5s=false;
					HeatingTicks=HEAT_HOLD_TIME;
//					HeatingCondition_TempNowOld=TempNow_Celsius;
				}
			}
			else
			{
				if(bHeatingCondition_RelayOn5s)
				{
					if(TempNow_Celsius>(HeatingCondition_TempNowOld+HEAT_DIFF))
					{
						bHeatingCondition_RelayOn5s=false;
						HeatingTicks=HEAT_HOLD_TIME;
//						HeatingCondition_TempNowOld=TempNow_Celsius;
					}
					else if(HeatingTicks>=1200)
					{
						HeatingTicks=0;
						HeatingCondition_TempNowOld=TempNow_Celsius;
					}
					else if(HeatingTicks>=450)
					{
						gbHeatRelay=false;
					}
				}
				else 
				{
					gbHeatRelay=false;
					if(HeatingTicks>=(1200))
					{
						if(TempNow_Celsius<=(HeatingCondition_TempNowOld+HEAT_DIFF))
						{
							bHeatingCondition_RelayOn5s=true;
							HeatingTicks=0;
						}
						else
						{
							bHeatingCondition_RelayOn5s=false;
							HeatingTicks=0;
						}
						
						HeatingCondition_TempNowOld=TempNow_Celsius;
					}
				}
			}
			
			gbHeating=true;
		break;
			
		case eHeatingCondition__TempSetBiggerThan98_AndTempNowSmallerThan98:
			if(bHeatingConditionX)
			{
				HeatingTicks=0;
			}
			
			if(HeatingTicks<500)
			{
				gbHeatRelay=true;
			}
			else
			{
				gbHeatRelay=false;
				if(HeatingTicks>=(1000))
					HeatingTicks=0;
			}
			gbHeating=true;
		break;
			
		case eHeatingCondition__TempSetBiggerThan98_AndTempNowEqualOrBiggerThan98:
			#if 0
			if(HeatingTicks<1200)
			{
				gbHeatRelay=true;
				gbHeating=true;
			}
			else
			{
				gbHeatRelay=false;
				gbHeating=false;
//				KeepWarmStart();
				if(!bHeatingDone)
				{
					bHeatingDone=true;
					HeatingTicks=0;
					Metrics_SetKettleLocation_BP(TempNow_Celsius);
				}
			}
			#else
		
		
			#define HEAT_TICKS_20221108		140
			#define WAIT_TICKS_20221108		550
			
			if(HeatingTicks<WAIT_TICKS_20221108)
			{
				gbHeatRelay=false;
				gbHeating=false;
			}
			else
			{
				gbHeatRelay=true;
				gbHeating=true;
				if(HeatingTicks>=(WAIT_TICKS_20221108+HEAT_TICKS_20221108))
				{
					HeatingTicks=0;
					if(++FinallyIntermittentHeating>=3)
					{
						FinallyIntermittentHeating=0;
						if(!bHeatingDone)
						{
							bHeatingDone=true;
							gbHeatRelay=false;
							gbHeating=false;
							Metrics_SetKettleLocation_BP(TempNow_Celsius);
						}
					}
				}
			}
			#endif
		break;
		
		default:
			break;
	}
}

void HeatingHandleForTmrInt()
{
	HeatingTicks++;
	HighAltitudeTest();
	if(ReadyStatusRemain)
		ReadyStatusRemain--;
}










