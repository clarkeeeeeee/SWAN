#include "Touch.h"



SetStatusEnum eAngleSet;
SetStatusEnum eFanSet;

u16 AngleSetTicks=0;
u16 FanSetTicks=0;

u16 PowerDispTicks=0;

u16 TouchAngelKeyMsk=0;

u8 LastAngelSetKeyIdx=0;
u8 SecondLastAngelSetKeyIdx=0;
u8 FirstValidAngelSetKeyIdx=0;

bool TouchKeyNull=true;


u8 TouchRetFirstValidAngelSetKeyIdx()
{
	return FirstValidAngelSetKeyIdx;
}
u8 TouchRetLastAngelSetKeyIdx()
{
	return LastAngelSetKeyIdx;
}
u8 TouchRetSecondLastAngelSetKeyIdx()
{
	return SecondLastAngelSetKeyIdx;
}

void AngleSetStatusX()
{
	if(!AngleSetTicks)
	{
		eAngleSet=NONE;
		return;
	}
	
	if(AngleSetTicks>SET_TICKS_COMFIRMED)
		eAngleSet=Adjustable;
	else
		eAngleSet=Comfirmed;
}
void FanSetStatusX()
{
	if(!FanSetTicks)
	{
		eFanSet=NONE;
		return;
	}
	
	if(FanSetTicks>SET_TICKS_COMFIRMED)
		eFanSet=Adjustable;
	else
		eFanSet=Comfirmed;
}

u8 IfAny1Near(u16 *pMsk,u8 idx)
{
	u8 idx_left;
	u8 idx_right;
	u8 max_num=HubGetAngleKeyNum();
	
	if(!max_num)
		return 0;
	
	if(idx==0)
	{
		idx_left=1;
		idx_right=max_num-1;
	}
	else if(idx==(max_num-1))
	{
		idx_left=0;
		idx_right=idx-1;
	}
	else
	{
		idx_left=idx+1;
		idx_right=idx-1;
	}
	
	if((*pMsk) & (1<<idx_left))
		return 1;
	if((*pMsk) & (1<<idx_right))
		return 1;
	return 0;
}


u8 IfAreNeighbour(u8 idx,u8 ref)
{
	if(idx==ref)
		return 1;
	
	if(idx>ref && ((idx-ref)==1))
		return 1;
	if(idx<ref && ((ref-idx)==1))
		return 1;
		
	if(idx==0)
	{
		if(ref==(HubGetAngleKeyNum()-1))
			return 1;
	}
	else if(idx==(HubGetAngleKeyNum()-1))
	{
		if(ref==0)
			return 1;
	}
	
	return 0;
}
void UpdateTouchAngelKeyMsk(u8 idx)
{
	if(idx>15)
		return;
	
	if(!IfAreNeighbour(idx,LastAngelSetKeyIdx))
		TouchAngelKeyMsk=0;
	
	if(idx!=LastAngelSetKeyIdx)
		SecondLastAngelSetKeyIdx=LastAngelSetKeyIdx;
	LastAngelSetKeyIdx=idx;
	
	if(IfAny1Near(&TouchAngelKeyMsk,idx))
	{
		TouchAngelKeyMsk|=(1<<idx);
		return;
	}
	TouchAngelKeyMsk=0;
	TouchAngelKeyMsk|=(1<<idx);
	FirstValidAngelSetKeyIdx=idx;
}

extern bool UART2_SendCmd_Get_EEPROM(void);



void TouchPowerSwitch(bool on)
{
    if(on)
    {
		PowerOnRestoreFan();
		PowerOnRestoreOther();
		PowerOnRestoreOSC();
    }
    else
    {
		HubResetAppPra();
		//HubResetSmPra();
		PowerDispTicks=0;
		AngleSetTicks=0;
		FanSetTicks=0;
//		TouchAngelKeyMsk=0;
    }
}

u8 TouchSetFan(u8 fan)
{
	FanSetTicks=SET_TICKS_ADJUSTABLE;
	PowerDispTicks=POWER_DISP_TICKS;

	if(gFan!=fan)
	{
		gFan=fan;
		return 1;
	}
	
	return 0;
}


extern void Alexa_InitiateFactoryReset(void);
extern void Alexa_InitiateUserGuidedSetup(void);

void TouchHandle(HubKeyEnum eKey)
{
	static u8 ClrTouchAngelKeyMsk=0;
	
	AngleSetStatusX();
	FanSetStatusX();
	
	if(eKey==HubKeyNULL)
		return;
	
	bHubUpdateTouchAngelKeyMskFromApp=false;
	
	if(HubInitLed)
		return;
	
	if(eKey==HubKeyPower)
	{
		if(gPower)
		{
			gPower=false;
			TouchPowerSwitch(gPower);
		}
		else
		{
			gPower=true;
			TouchPowerSwitch(gPower);
			
//			HubUpdateTouchAngelKeyMskFromApp(1);
		}
//		HubAlexa_SendChangeReportDueToLocalControl();
		return;
	}

	if(eKey==HubKeyUgs)
	{
		HubSet_bHubUgs(true);
		//Alexa_InitiateUserGuidedSetup();
		return;
	}
	if(eKey==HubKeyResetFactory)
	{
		HubSet_bHubResetFactory(true);
//		Alexa_InitiateFactoryReset();
		return;
	}
	if(eKey==HubKeyLog)
	{
		
		return;
	}
	
	if(gPower==false)
	{
		return;
	}
	
	if(eKey==HubKeyAdd)
	{
		if(!FanSetTicks)
		{
			FanSetTicks=SET_TICKS_ADJUSTABLE;
		}
		else
		{
			FanSetTicks=SET_TICKS_ADJUSTABLE;
			if(gFan<FAN_MAX)
				gFan++;
			else
				gFan=1;
		}
		return;
	}
	if(eKey==HubKeySub)
	{
		if(!FanSetTicks)
		{
			FanSetTicks=SET_TICKS_ADJUSTABLE;
		}
		else
		{
			FanSetTicks=SET_TICKS_ADJUSTABLE;
			if(gFan>FAN_MIN)
				gFan--;
		}
		return;
	}
	
	if(HubInitLed)
		return;
	
	if(!HubUpdateTouchAngelKeyMskEn())
	{
		return;
	}
	
	FanSetTicks=0;
	
	if(!AngleSetTicks)
	{
		AngleSetTicks=SET_TICKS_ADJUSTABLE;
		ClrTouchAngelKeyMsk=1;		
		return;
	}
	
	if(ClrTouchAngelKeyMsk)		//首次设置角度需要清楚原先设置
	{
		ClrTouchAngelKeyMsk=0;
		TouchAngelKeyMsk=0;
	}
	
	AngleSetTicks=SET_TICKS_ADJUSTABLE;
	
		
	switch(eKey)
	{
		case HubKeyAg1:
			UpdateTouchAngelKeyMsk(0);
		break;
		
		case HubKeyAg2:
			UpdateTouchAngelKeyMsk(1);
		break;
		
		case HubKeyAg3:
			UpdateTouchAngelKeyMsk(2);
		break;
		
		case HubKeyAg4:
			UpdateTouchAngelKeyMsk(3);
		break;
		
		case HubKeyAg5:
			UpdateTouchAngelKeyMsk(4);
		break;
		
		case HubKeyAg6:
			UpdateTouchAngelKeyMsk(5);
		break;
		
		case HubKeyAg7:
			UpdateTouchAngelKeyMsk(6);
		break;
		
		case HubKeyAg8:
			UpdateTouchAngelKeyMsk(7);
		break;
		
		default:
			break;
	}
}




#define ANGEL_KEY_RELEASE

#ifdef ANGEL_KEY_RELEASE
#define TOUCH_LONG_KEY_KINDS	11
#else
#define TOUCH_LONG_KEY_KINDS	3
#endif
#define TOUCH_LONG_KEY_TICKS		6000
#define TOUCH_LONG_KEY_TICKS_2S		2000

bool bTouchKeyLock=false;
bool bTouchLongKey[TOUCH_LONG_KEY_KINDS]={false};
u16 TouchLongKeyTicks[TOUCH_LONG_KEY_KINDS]={0};
HubKeyEnum eKey=HubKeyNULL;

void TouchLongKeyHandle()
{
	u8 i=0;

	for(i=0;i<TOUCH_LONG_KEY_KINDS;i++)
	{
		#ifdef ANGEL_KEY_RELEASE
		if(i<3)
			goto TouchLongKey0_3;
		
		if(TouchLongKeyTicks[i]>=TOUCH_LONG_KEY_TICKS_2S)
		{
			bTouchKeyLock=true;
			HubResetSmPra();
			TouchAngelKeyMsk=0;
			gOscAngel=0;
		}
		continue;
		#endif
TouchLongKey0_3:		
		if(TouchLongKeyTicks[i]>=TOUCH_LONG_KEY_TICKS)
		{
			switch(i)
			{
				case 0:
					if(bTouchKeyLock)
						break;
					eHubKey=HubKeyUgs;
					bTouchKeyLock=true;
				break;

				case 1:
					if(eKey==HubKeyResetFactory)
					{
						eHubKey=HubKeyResetFactory;
						eKey=HubKeyNULL;
					}
					bTouchKeyLock=true;
				break;

				case 2:
					if(eKey==HubKeyLog)
					{
						eHubKey=HubKeyLog;
						eKey=HubKeyNULL;
					}
					bTouchKeyLock=true;
				break;
					
				default:
					bTouchKeyLock=true;
				break;
			}
		}
	}
}

void TouchLongKeyTicksAdd()
{
	u8 i=0;

	for(i=0;i<TOUCH_LONG_KEY_KINDS;i++)
	{
		if(bTouchLongKey[i])
			TouchLongKeyTicks[i]++;
	}
}

void ResetTouchLongKey()
{
	u8 i=0;

	for(i=0;i<TOUCH_LONG_KEY_KINDS;i++)
	{
		TouchLongKeyTicks[i]=0;
		bTouchLongKey[i]=false;
	}
}




void ProcessMessage(u8 *buf)
{
	u8 sum=0;
	u16 key_msk;
	static u16 key_msk_pre;

//	if(HubInitLed)
//		return;
	
	
	sum=*(buf+2)+*(buf+3);
	sum^=0xff;
	
	if(sum==*(buf+4))
	{
		key_msk=*(buf+2);
		key_msk<<=8;
		key_msk+=*(buf+3);

		if(key_msk)
			TouchKeyNull=false;
		else
			TouchKeyNull=true;

		if(key_msk_pre!=key_msk)
		{
			key_msk_pre=key_msk;
			ResetTouchLongKey();
		}
		
		switch(key_msk)
		{
			case 0:
				if(!bTouchKeyLock)
				{
					if(eKey==HubKeyPower)
					{
						eHubKey=eKey;
					}
					else if(eKey==HubKeyAdd)
					{
						eHubKey=eKey;
					}
					else if(eKey==HubKeySub)
					{
						eHubKey=eKey;
					}
					#ifdef ANGEL_KEY_RELEASE
					else if(eKey==HubKeyAg1 || eKey==HubKeyAg2 || eKey==HubKeyAg3 || eKey==HubKeyAg4 || eKey==HubKeyAg5 || eKey==HubKeyAg6 || eKey==HubKeyAg7 || eKey==HubKeyAg8)
					{
						eHubKey=eKey;
					}
					#endif
				}
				bTouchKeyLock=false;
				eKey=HubKeyNULL;
			break;

			case ((1<<10)|(1<<11)):
				if(bTouchKeyLock)
					break;
				eKey=HubKeyResetFactory;
				bTouchKeyLock=true;
				bTouchLongKey[1]=true;
			break;

			case ((1<<11)|(1<<13)):
				if(bTouchKeyLock)
					break;
				eKey=HubKeyLog;
				bTouchKeyLock=true;
				bTouchLongKey[2]=true;
			break;

			case (1<<11):
				if(bTouchKeyLock)
					break;
				eKey=HubKeyPower;
				bTouchLongKey[0]=true;
			break;
				
			case (1<<10):
				if(bTouchKeyLock)
					break;
				eKey=HubKeyAdd;
			break;
			case (1<<13):
				if(bTouchKeyLock)
					break;
				eKey=HubKeySub;
			break;

	#ifndef ANGEL_KEY_RELEASE
			case (1<<7):
				if(bTouchKeyLock)
					break;
				eKey=eHubKey=HubKeyAg1;
				bTouchKeyLock=true;
			break;

			case (1<<8):
				if(bTouchKeyLock)
					break;
				eKey=eHubKey=HubKeyAg2;
				bTouchKeyLock=true;
			break;

			case (1<<9):
				if(bTouchKeyLock)
					break;
				eKey=eHubKey=HubKeyAg3;
				bTouchKeyLock=true;
			break;

			case (1<<0):
				if(bTouchKeyLock)
					break;
				eKey=eHubKey=HubKeyAg4;
				bTouchKeyLock=true;
			break;

			case (1<<1):
				if(bTouchKeyLock)
					break;
				eKey=eHubKey=HubKeyAg5;
				bTouchKeyLock=true;
			break;

			case (1<<2):
				if(bTouchKeyLock)
					break;
				eKey=eHubKey=HubKeyAg6;
				bTouchKeyLock=true;
			break;

			case (1<<3):
				if(bTouchKeyLock)
					break;
				eKey=eHubKey=HubKeyAg7;
				bTouchKeyLock=true;
			break;

			case (1<<6):
				if(bTouchKeyLock)
					break;
				eKey=eHubKey=HubKeyAg8;
				bTouchKeyLock=true;
			break;
	#else
			case (1<<7):
				eKey=HubKeyAg1;
				bTouchLongKey[3]=true;
			break;
			case (1<<8):
				eKey=HubKeyAg2;
				bTouchLongKey[4]=true;
			break;
			case (1<<9):
				eKey=HubKeyAg3;
				bTouchLongKey[5]=true;
			break;
			case (1<<0):
				eKey=HubKeyAg4;
				bTouchLongKey[6]=true;
			break;
			case (1<<1):
				eKey=HubKeyAg5;
				bTouchLongKey[7]=true;
			break;
			case (1<<2):
				eKey=HubKeyAg6;
				bTouchLongKey[8]=true;
			break;
			case (1<<3):
				eKey=HubKeyAg7;
				bTouchLongKey[9]=true;
			break;
			case (1<<6):
				eKey=HubKeyAg8;
				bTouchLongKey[10]=true;
			break;
	#endif

			default:
				eKey=HubKeyNULL;
				bTouchKeyLock=true;
			break;
			
		}
	}
}

















