#include "remote_counter.h"


uint16_t gRemoteCounter=0;

bool gbRemoteComand=true;
bool gbRemotePowerOn=false;
uint32_t RemoteCounterTicks=0;

void RemoteCounterClear()
{
	gRemoteCounter=0;
	gbRemotePowerOn=false;
	gbRemoteComand=true;
	RemoteCounterTicks=0;
}

void RemoteCounterHandle()
{
//	if((RemoteCounterTicks>=(24*60*60*1000) && gRemoteCounter>=4) || (RemoteCounterTicks>=(48*60*60*1000) && gRemoteCounter>=2))
//	{
//		gbRemoteComand=false;
//	}
	
	if(RemoteCounterTicks>=(30*60*1000))
	{
		if(gRemoteCounter>=2)
			gbRemoteComand=false;
	}
	else
	{
		if(gRemoteCounter>=4)
			gbRemoteComand=false;
	}
}

void RemoteCounterHandleForTmrInt()
{
	if(gbRemotePowerOn)
		RemoteCounterTicks++;
	else
		RemoteCounterTicks=0;
}



