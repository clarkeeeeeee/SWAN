#ifndef _CY_IIC_H_
#define _CY_IIC_H_

#include "numicro_hal.h"
#include "ack_logging.h"
#include <inttypes.h>
#include <stdint.h>

#define u8 unsigned char

void iic_write_bytes(u8 *bytes,u8 cnts);
void iic_init();

#endif