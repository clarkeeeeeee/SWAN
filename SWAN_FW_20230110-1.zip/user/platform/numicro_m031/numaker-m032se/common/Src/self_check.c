#include "self_check.h"
#include "smg.h"
#include "dev.h"
#include "led.h"

bool gbSelfCheckKeysEn=false;
bool gbSelfCheckRelayOn=false;


bool bSelfCheckStatus=false;
static uint32_t SelfCheckTicks=0;
static uint16_t SelfCheckSteps=0;

void SelfCheckStart()
{
	if(!bSelfCheckStatus)
	{
		bSelfCheckStatus=true;
		SelfCheckTicks=0;
		SelfCheckSteps=0;
	}
}
void SelfCheckStop()
{
	if(bSelfCheckStatus)
	{
		bSelfCheckStatus=false;
		SelfCheckTicks=0;
	}
}
bool SelfCheckRetStatus()
{
	return bSelfCheckStatus;
}
uint8_t SelfCheckRetSteps()
{
	return SelfCheckSteps;
}
void SelfCheckStepsPlus()
{
	if(SelfCheckSteps==8)
		SelfCheckSteps++;
}
void SelfCheckHandleForTmrInt()
{
	SelfCheckTicks++;
}

void SelfCheckHandle()
{
	if(!bSelfCheckStatus)
	{
		gbSelfCheckRelayOn=false;
		return;
	}
	
	switch(SelfCheckSteps)
	{
		case 0:
			if(SelfCheckTicks>=1000)
			{
				SelfCheckTicks=0;
				SelfCheckSteps++;
			}
		break;
			
		case 1:
			gbSelfCheckRelayOn=(true);
			if(SelfCheckTicks>=1000)
			{
				SelfCheckTicks=0;
				SelfCheckSteps++;
			}
		break;
			
		case 2:
			gbSelfCheckRelayOn=(true);
			if(SelfCheckTicks>=1000)
			{
				SelfCheckTicks=0;
				SelfCheckSteps++;
			}
		break;
			
		case 3:
			gbSelfCheckRelayOn=(true);
			if(SelfCheckTicks>=1000)
			{
				SelfCheckTicks=0;
				SelfCheckSteps++;
			}
		break;
			
		case 4:
			gbSelfCheckRelayOn=(false);
			if(SelfCheckTicks>=1000)
			{
				SelfCheckTicks=0;
				SelfCheckSteps++;
			}
		break;
			
		case 5:
			if(SelfCheckTicks>=1000)
			{
				SelfCheckTicks=0;
				SelfCheckSteps++;
			}
		break;
			
		case 6:
			if(SelfCheckTicks>=1000)
			{
				SelfCheckTicks=0;
				SelfCheckSteps++;
			}
		break;
			
		case 7:
			if(SelfCheckTicks>=1000)
			{
				SelfCheckTicks=0;
				SelfCheckSteps++;
			}
		break;
			
		case 8:
			if(geKey!=eKey_Null)
				SelfCheckTicks=0;
			if(SelfCheckTicks>=20000)
			{
				SelfCheckTicks=0;
				bSelfCheckStatus=false;
			}
		break;
		case 9:
			if(geKey!=eKey_Null)
			{
				SelfCheckTicks=0;
				SelfCheckSteps++;
			}
			if(SelfCheckTicks>=20000)
			{
				SelfCheckTicks=0;
				SelfCheckSteps++;
			}
		break;
			
		default:
			bSelfCheckStatus=false;
		break;
	}
}



