#ifndef _TOP_H_
#define _TOP_H_

#define ALEXA

#define PCB_US		0


#define UGS_NEED_BCS_FIRST			1

#define NEW_APP_API
#ifdef NEW_APP_API

//#define TEST_DART_FUNC	
#ifdef TEST_DART_FUNC
#define DEFAULT_BOIL_100_DEGREE_COUNTS		20
#else
#define DEFAULT_BOIL_100_DEGREE_COUNTS		500
#endif

#endif


#define POWER_KEY_SET_TEMP_100		1	//20221103 开关机键设置温度为100

#define HW_VER 	4

#define EE_TEST				0

#if PCB_US
#define FIRMWARE_VERSION	"01"
#else
#define FIRMWARE_VERSION	"08"
#endif
//#define KEY_UPDATE_TEMP_EN
//#define LED_IS_RELAY_STATUS

/*
note:all time defines is base 10ms
*/

#define SWAN_SYNC_PRESET	0

#define RELAY_CTRL_WITH_ALGORITHM	1
#define APP_DISPLAY_REAL_TEMP		0

#define TEMP_COMP_TIME			(1*30*100)
#define TEMP_COMP_PERCENT		(0)
#define HIGH_ALTITUDE_TEST_TICKS	(20*100)
#define HIGH_ALTITUDE_TEST_TEMP		(80)

#define TEMPRATURE_FACTOR0			(102)
#define TEMPRATURE_FACTOR1			(103)
#define TEMPRATURE_FACTOR2			(104)

#define TEMP_SET_TICKS					(60*1000)
#define TEMP_SET_TICKS_POWER_ON			(4*1000)


#define ACK_LIFECYCLE_IN_SETUP_MODE_OT_TIME		(5*60*100)	//5分钟
#define DEFAULT_TEMP_CELSIUS_SET		100
#define DEFAULT_TEMP_FAHRENHEIT_SET		212

#define TEMP_CELSIUS_SET_MAX			100
#define TEMP_CELSIUS_SET_MIN			25



#define CLEAR_HOT_TEMP_FAHRENHEIT		158


#define DEFAULT_KEEP_WARM_MINUTES		(120)		//unit minute
#define KEEP_WARM_MINUTES__TOTAL_MS		(60*100)


#define LOW_WATER_SHOW					(10*60*100)
#define READY_STATUS_REMAIN				(5*60*1000)

#define HEAT_HOLD_TIME					(200)

#define BUZZER_TIME		20

#if PCB_US
#define PRE_SET_MAX		12
#else
#define PRE_SET_MAX		6
#endif
#define PRE_SET_MIN		1
#define MANUAL			0

#if PCB_US
#define DEFAULT_PRE_SET		(PRE_SET_MAX-1)
#else
#define DEFAULT_PRE_SET		PRE_SET_MAX
#endif

#define PRESET_CHANGED_TICKS		400

#define TURN_OFF_DISP_DELAY_TICKS	(10*60*100)//(10*60*100)		//ABSE 10MS

//#define NTC_10K

#define KEEP_WARM_REMAIN_UNIT		(5*60*100)

#endif



