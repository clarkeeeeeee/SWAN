#include "key.h"
#include "dev.h"
#include "smg.h"
#include "self_check.h"
#include "low_water.h"
#include "remote_counter.h"
#include "top.h"
#include "connect.h"
#include "led.h"
#include "metrics.h"
#include "off_base.h"
#include "heating.h"
#include "ack.h"
#include "adc_ex.h"


sKey_t sKey;
bool KeyLongFlag=0;
eKey_t geKey;

#if PCB_US
#define SW2_DOWN	(PC2==1)
#define SW1_DOWN	(PC3==1)
#else
#define SW2_DOWN	(PA6==1)
#define SW1_DOWN	(PA7==1)
#endif
#define SW3_DOWN	(KeyAdcRes>5000 && KeyAdcRes<6000)
#define SW4_DOWN	(KeyAdcRes>5000 && KeyAdcRes<6000)
#define SELF_CHECK_KEY_DOWN		(KeyAdcRes>5000 && KeyAdcRes<6000)


#define LONG_TRIG		45
#define KEY_LONG_TH		266
#define KEY_DEBOUNCE	3

uint8_t SetTicks=0;
extern uint8_t SmgTest;

bool gbKeyUgsEn=false;
bool gbKeyFrsEn=false;
bool gbFrsKeySts=false;
bool gbKeyFrsDown=false;

#if PCB_US
#define KEY_CODE_IO			1
#define KEY_CODE_NONE		3
#define KEY_CODE_PRESET		2
#else
#define KEY_CODE_IO			1
#define KEY_CODE_NONE		0
#define KEY_CODE_PRESET		2
#endif
#define KEY_CODE_PLUS		10
#define KEY_CODE_MINUS		11
#define KEY_CODE_WIFI		12

void KeyInit()
{
//	GPIO_SetMode(PB, BIT7|BIT12|BIT13|BIT15, GPIO_MODE_QUASI);
//	PB12=1;
//	PB7=1;
//	PB13=1;
//	PB15=1;
	
	if(SELF_CHECK_KEY_DOWN)
		gbSelfCheckKeysEn=true;
}
static void key_scan()
{
	uint8_t tmp=0;
	
	if(SW1_DOWN)
		tmp+=1;
	if(SW2_DOWN)
		tmp+=2;
//	else if(SW3_DOWN)
//		tmp=4;
//	else if(SW4_DOWN)
//		tmp=8;
	
	if(tmp!=KEY_CODE_NONE)
	{
		sKey.key_now=tmp;
		
		if(sKey.key_now!=sKey.key_pre)
		{
			sKey.key_cnts=0;
			sKey.key_pre=sKey.key_now;
		}
		else
		{
			sKey.key_cnts++;
		}
	}
	else
	{
		sKey.key_now=KEY_CODE_NONE;
	}
	
	if(sKey.key_cnts>=KEY_DEBOUNCE)
	{
		switch(sKey.key_now)
		{
			case KEY_CODE_IO:
				geKey=eKey_IO;
			break;
			case KEY_CODE_PRESET:
				geKey=eKey_PRESET;
			break;
			
			case KEY_CODE_PLUS:
				geKey=eKey_P;
			break;
			case KEY_CODE_WIFI:
				geKey=eKey_WIFI;
			break;
			case KEY_CODE_MINUS:
				geKey=eKey_M;
			break;
			default:
				geKey=eKey_Null;
			break;
		}
	}
}

bool gbDisplayTempSetSolid=false;
#if UGS_NEED_BCS_FIRST
bool gbUgsWaitBcs=false;
#endif
void KeyHandle()
{
	u8 tmp;
	
	key_scan();
	
	if(PowerUpDispAll)
	{
		if(sKey.key_now!=KEY_CODE_NONE)
			sKey.key_lock=1;
		return;
	}
//reset TurnOffDispDelayTicks
	if(gbDisplay && sKey.key_now!=KEY_CODE_NONE)
		TurnOffDispDelayTicks=TURN_OFF_DISP_DELAY_TICKS;
	
	if(gbSelfCheckKeysEn)
		goto Key_SelfCheck;

Key_SelfCheck:	
	if(sKey.key_now!=(KEY_CODE_PLUS+KEY_CODE_MINUS))
		gbSelfCheckKeysEn=false;
	#if(0)
	if(SelfCheckRetStatus())
	{
		switch(sKey.key_now)
		{
			case KEY_CODE_NONE:
				if(!sKey.key_lock)
				{
					
				}
				sKey.key_cnts=0;
				sKey.key_lock=0;
				sKey.key_pre=0;
			break;
				
			
			default:
				sKey.key_lock=1;
			break;
		}
		return;
	}
	#endif
Key_LowWater:	
//	if(gbLowWater)
//	{
//		if(sKey.key_now && sKey.key_now!=KEY_CODE_WIFI && sKey.key_cnts>=KEY_DEBOUNCE)
//		{
//			LowWaterRemainTicksReload();
//			sKey.key_lock=1;
//			return;
//		}
//		
//	}

Key_Handle:	
	switch(sKey.key_now)
	{
		case KEY_CODE_NONE:
			if(!sKey.key_lock && sKey.key_cnts>=KEY_DEBOUNCE)
			{
				if(sKey.key_pre==KEY_CODE_IO)	//power key
				{
					if(PreSetChangedTicks)
					{
						PreSetChangedTicks=0;
						gbDisplayTempSetSolid=false;
						BuzzerTime=BuzzerTimeUnit=BUZZER_TIME;
//						PreSet=6;
//						#if(SWAN_SYNC_PRESET)
//						gbSwan=true;
//						#endif
					}
					else if(!gbDisplay)
					{
						gbDisplay=true;
						BuzzerTime=BuzzerTimeUnit=BUZZER_TIME;
					}
					else
					{
						if(gbPower)
						{
							DevPowerOff();
//							Smg_ReloadOffBaseDispTicks(false);
						}
						else
						{
							#if POWER_KEY_SET_TEMP_100
							
							#if PCB_US
							UpdateTempSet_CausePreSet(gTempratureUnit==eTempratureUnit_Fahrenheit?12:11);		//这个函数内部会更新preset=tmp
							#else
							UpdateTempSet_CausePreSet(6);
							#endif
							UpdateTempSet();
							gbKeepWarmSwitch=false;
							#if(SWAN_SYNC_PRESET)
							gbSwan=true;
							#endif
							#endif
							
							DevPowerOn();
							ReloadPreSetChangedTicks();
						}
						BuzzerTime=BuzzerTimeUnit=BUZZER_TIME;
					}
				}
				else if(sKey.key_pre==KEY_CODE_PRESET)
				{
					if(!gbDisplay)
					{
						goto NoAnyKey;
					}
					BuzzerTime=BuzzerTimeUnit=BUZZER_TIME;
					tmp=PreSet;
					if(!PreSetChangedTicks)
					{
						if(gbPower)
							gbDisplayTempSetSolid=true;
						ReloadPreSetChangedTicks();
						
//						if(tmp==6)
//							tmp=5;
					}
					else if(gbDisplayTempSetSolid)
					{
						ReloadPreSetChangedTicks();
						gbDisplayTempSetSolid=false;
					}
					else
					{
						ReloadPreSetChangedTicks();
						
						#if PCB_US
						if(tmp==0)
							tmp=gTempratureUnit==eTempratureUnit_Fahrenheit?2:1;
						else 
						{
							if(tmp>2)
								tmp-=2;
							else
								tmp=tmp+PRE_SET_MAX-2;
						}
						#else
						if(tmp==0)
							tmp=1;
						else 
							tmp=PreSet-1;
						if(tmp<PRE_SET_MIN)
							tmp=PRE_SET_MAX;
						#endif
					}
					UpdateTempSet_CausePreSet(tmp);		//这个函数内部会更新preset=tmp
					UpdateTempSet();
					
					#if PCB_US
					if(PreSet<11)
					#else
					if(PreSet!=6)
					#endif
					{
						gbKeepWarmSwitch=true;
						#if(SWAN_SYNC_PRESET)
						gbSwan=false;
						#endif
					}
					else
					{
						gbKeepWarmSwitch=false;
						#if(SWAN_SYNC_PRESET)
						gbSwan=true;
						#endif
					}
				}
			}
			
NoAnyKey:
			sKey.key_cnts=0;
			sKey.key_lock=0;
			sKey.key_pre=0;
		break;
			
		case KEY_CODE_IO:
			if(!sKey.key_lock)
			{
//				if(sKey.key_cnts>=KEY_DEBOUNCE)
//				{
//					if(sKey.key_cnts>=2000)
//					{
//						SmgFirmwareVersionDispTicksReload();
//						sKey.key_lock=1;
//					}
//				}
				if(sKey.key_cnts>=KEY_DEBOUNCE)
				{
					if(gbDisplay && sKey.key_cnts>=200)
					{
						gbDisplay=false;
						ClearPreSetConfirm();
						if(gbPower)
						{
							DevPowerOff();
							Smg_ReloadOffBaseDispTicks(false);
						}
						sKey.key_lock=1;
						BuzzerTime=BuzzerTimeUnit=BUZZER_TIME;
					}
				}
			}
			else
			{
				if(sKey.key_cnts>=KEY_DEBOUNCE)
				{
					if(sKey.key_cnts==500)
					{
						gFmVerDisplay=200;
						BuzzerTime=BuzzerTimeUnit=BUZZER_TIME;
						break;
					}
					
					if(sKey.key_cnts==1000)
					{
						if(gbCustomerTest)
						{
							gbCustomerTest=false;
							BuzzerTime=BuzzerTimeUnit=BUZZER_TIME;
							break;
						}
						gbCustomerTest=gbDisplay=true;
						ClearPreSetConfirm();
						DevPowerOn();
						ReloadPreSetChangedTicks();
						BuzzerTime=BuzzerTimeUnit=BUZZER_TIME;
						
						#if PCB_US
						UpdateTempSet_CausePreSet(PreSet=(gTempratureUnit==eTempratureUnit_Fahrenheit?12:11));
						#else
						UpdateTempSet_CausePreSet(PreSet=6);		//这个函数内部会更新preset=tmp
						#endif
						UpdateTempSet();
						gbKeepWarmSwitch=false;
					}
				}
			}
		break;
		
		#if !PCB_US
		case KEY_CODE_PRESET+KEY_CODE_IO:
			if(!sKey.key_lock)
			{
				if(sKey.key_cnts>=KEY_DEBOUNCE)
				{
					if(!gbDisplay)
					{
						sKey.key_lock=1;
						break;
					}
					
					if(sKey.key_cnts>=300)
					{
						Conn_StartFrs();
						gbKeyFrsEn=true;
						sKey.key_lock=1;
						gbSelfCheckKeysEn=false;
						LedResetWifiSearchTicks();
						BuzzerTimeUnit=BUZZER_TIME;
						BuzzerTime=BuzzerTimeUnit*9;
						WifiCfgDispAll=500;
					}
				}
			}
		break;
		#endif
		
		#if PCB_US
		case 0:	//gTempratureUnit
			if(!sKey.key_lock)
			{
				if(sKey.key_cnts>=KEY_DEBOUNCE)
				{
					if(!gbDisplay)
					{
						sKey.key_lock=1;
						break;
					}
					
					if(sKey.key_cnts>=KEY_DEBOUNCE)
					{
						gTempratureUnit=(gTempratureUnit==eTempratureUnit_Celsius)?eTempratureUnit_Fahrenheit:eTempratureUnit_Celsius;
						DevTempUnitX();
						sKey.key_lock=1;
						BuzzerTimeUnit=BUZZER_TIME;
						BuzzerTime=BuzzerTimeUnit*1;
						gbDisplay=true;
					}
				}
			}
		break;
		#endif
		
		case KEY_CODE_PRESET:
			if(!sKey.key_lock)
			{
				if(sKey.key_cnts>=KEY_DEBOUNCE)
				{
					if(!gbDisplay)
					{
						sKey.key_lock=1;
						break;
					}
					
					if(sKey.key_cnts>=300)
					{
						#if UGS_NEED_BCS_FIRST
						gbUgsWaitBcs=true;
						extern void Alexa_InitiateFactoryReset(void);
						Alexa_InitiateFactoryReset();
						#else
						Alexa_InitiateUserGuidedSetup();
						#endif
//						Conn_StartUgs();
						gbKeyUgsEn=true;
						sKey.key_lock=1;
						gbSelfCheckKeysEn=false;
						LedResetWifiSearchTicks();
						BuzzerTimeUnit=BUZZER_TIME;
						BuzzerTime=BuzzerTimeUnit*5;
						WifiCfgDispAll=300;
						gbDisplay=true;
					}
				}
			}
		break;
			
		case KEY_CODE_WIFI:
			if(!sKey.key_lock)
			{
				if(sKey.key_cnts>=KEY_DEBOUNCE)
				{
					if(ACK_LifecycleState==ACK_LIFECYCLE_NOT_CONNECTED_TO_ALEXA || ACK_LifecycleState==ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
					{
						if(sKey.key_cnts>=1000)
							goto key_trig_ugs;
						break;
					}
					else
					{
						if(sKey.key_cnts>=200)
							goto key_trig_ugs;
						break;
					}
					
					key_trig_ugs:
					{
						Conn_StartUgs();
						gbKeyUgsEn=true;
						sKey.key_lock=1;
						gbSelfCheckKeysEn=false;
						LedResetWifiSearchTicks();
					}
				}
			}
		break;

		
		default:
			if(sKey.key_now!=KEY_CODE_NONE)
				sKey.key_lock=1;
		break;
	}
}



