#ifndef _DEV_H_
#define _DEV_H_

#include <stdint.h>
#include "numicro_hal.h"
#include <stdbool.h>
#include "key.h"
#include "top.h"

extern bool gbPower;
extern uint16_t TempSet_Celsius;
extern uint16_t TempNow_Celsius;
extern uint16_t TempNowWithDot_Celsius;
extern bool gbAckDsnRecived;
extern bool gbRelay;
extern uint16_t PreSet;
extern uint16_t TempSet;
extern bool gbPresetWithBoil;
extern bool gbPresetWithoutBoil;
extern uint16_t PreSetChangedTicks;
extern bool gbPreSetConfirm;	
extern bool gbDisplay;
extern uint16_t PowerOnDispTempSetTicks;
extern uint16_t TurnOffDispDelayTicks;
extern bool gbKeepWarmSwitch;
extern bool gbSwan;
extern uint16_t TempNow_CelsiusApp;
extern uint16_t TempCompPercent;
#ifdef NEW_APP_API
extern uint16_t gBoilCounts;
extern bool gbBoilTo100Degree_CountsReset;
void BoilCountsResetFlagClear();
#ifdef TEST_DART_FUNC
void Inc_gBoilCounts();
#endif
#endif
extern bool gbCustomerTest;
extern bool gbPreSetChanged;
extern uint16_t gFmVerDisplay;
extern float gfTempNowFahrenheit;
extern uint16_t TempSet_Fahrenheit;
extern uint16_t gTempNowFahrenheit;
float C2F(float temp);
float F2C(float temp);



typedef enum
{
	eTempratureUnit_none,
	eTempratureUnit_Celsius,
	eTempratureUnit_Fahrenheit,
}eTempratureUnit_t;
extern eTempratureUnit_t gTempratureUnit;
void DevTempUnitX();


void ReloadPreSetChangedTicks();
void AppChangeTempSet();
void ClearPreSetConfirm();
void DevInit();
void DevTempSet_FahrenheitPlus(eKeyStatus_t eKeyStatus);
void DevTempSet_FahrenheitMinus(eKeyStatus_t eKeyStatus);
void DevTempSet_CelsiusPlus(eKeyStatus_t eKeyStatus);
void DevTempSet_CelsiusMinus(eKeyStatus_t eKeyStatus);
bool DevReloadTempSetTicks();
bool DevGetTempSetFlashShow();
bool DevGetTempSetShow();
bool DevReloadTempSetTicks();
void DevHandleForTmrInt();
void DevClrTempSetTicks();
void DevHeaterRelay(bool);
bool DevGetTempSetStatus();
void DevHandle();
void UpdateTempSet_CelsiusFromTempSet();
void UpdateTempSet_FahrenheitFromTempSet();
void UpdateTempSet();
void UpdateTempSet_CausePreSet(uint16_t pre_set);
bool DevPowerOff();
void DevPowerOn();
void UpdateTempSet1();
void UpdateTempCompPercent();


#endif



