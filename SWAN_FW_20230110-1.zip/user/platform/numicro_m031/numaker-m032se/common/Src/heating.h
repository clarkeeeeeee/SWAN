#ifndef _HEATING_H_
#define _HEATING_H_

#include <stdint.h>
#include "numicro_hal.h"
#include <stdbool.h>

extern bool gbHeating;
extern bool gbHeatRelay;
extern bool gbReadyStatus;
extern bool gbTemp100HeatDone;

void HeatingHandle();
void HeatingHandleForTmrInt();
bool HeatintRetStatus();
bool HeatintRetHeatingDone();
void HeatingReheat();


#endif



