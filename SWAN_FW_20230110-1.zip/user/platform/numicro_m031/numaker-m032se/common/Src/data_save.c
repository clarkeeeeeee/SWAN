#include "data_save.h"
#include "data_flash.h"
#include "dev.h"
#include "keep_warm.h"
#include "connect.h"
#include "fmc.h"
#include "ack_m031_ota.h"
#include "metrics.h"

#define DATA_SAVE_HEAD		20221202
#define DATA_SAVE_DELAY		150

#define EEPROM_LEN				8
#define EEPROM_LEN_BYTE			(EEPROM_LEN*4)
#define EEPROM_ADDR				ACK_NUMICRO_EEPROM_START

uint32_t Save[EEPROM_LEN]={DATA_SAVE_HEAD};
uint32_t Read[EEPROM_LEN]={};
uint32_t Read2[EEPROM_LEN]={};
	
uint32_t DataSaveDelay=0;
	
	
uint32_t EepromAddr=EEPROM_ADDR;	

static void UpdateData(uint32_t *src)
{
	uint32_t tmp;
	uint32_t tmp2=gbKeepWarm;
	
	tmp=*src;
	TempSet_Celsius=((tmp>>0)&0xff);
	gbKeepWarmStatusPreviousPowerCircle=((tmp>>8)&0xff);
	PreSet=((tmp>>24)&0xff);
	
	tmp=*(src+1);
//	KeepWarmMinutes=KeepWarmMinutesBkp=((tmp>>0)&0xff);
	gTempratureUnit=((tmp>>8)&0xff);
	
	KettleCycleCountBkp=KettleCycleCount=*(src+2);
	Metrics__Kettle_heater_life=KettleCycleCount=*(src+3);
	Metrics__kettle_relay_cycle=KettleCycleCount=*(src+4);
	
	KeepWarmTimeRemaine_ForSave=*(src+5);
	
	UpdateTempSet();
	
	#if PCB_US
	if(PreSet>10)
	#else
	if(PreSet!=6)
	#endif
	{
		gbKeepWarmSwitch=true;
		#if(SWAN_SYNC_PRESET)
		gbSwan=false;
		#endif
	}
	else
	{
		gbKeepWarmSwitch=false;
		#if(SWAN_SYNC_PRESET)
		gbSwan=true;
		#endif
	}
	
	#ifdef NEW_APP_API
	tmp=*(src+6);
	tmp&=0x7fff;
	gBoilCounts=tmp<=DEFAULT_BOIL_100_DEGREE_COUNTS?(tmp):gBoilCounts;
	#endif
	
	tmp=*(src+6);
	tmp&=0x8000;
	if(tmp)
		gbDisplay=true;
	else
		gbDisplay=false;
	if(gbDisplay)
		TurnOffDispDelayTicks=TURN_OFF_DISP_DELAY_TICKS;
	else
		TurnOffDispDelayTicks=0;
}
static void UpdateSave(uint32_t *save)
{
	uint32_t tmp;
	uint32_t tmp2=gbKeepWarm;
	
	tmp=(TempSet_Celsius&0xff)+((tmp2<<8)&0xff00)+((0<<16)&0xff0000)+((PreSet<<24)&0xff000000);
	*save=tmp;
	
	tmp=(KeepWarmMinutesBkp&0xff)+(((uint16_t)gTempratureUnit<<8)&0xff00);
	*(save+1)=tmp;
	
	*(save+2)=KettleCycleCount;
	*(save+3)=Metrics__Kettle_heater_life;
	*(save+4)=Metrics__kettle_relay_cycle;
	
	*(save+5)=KeepWarmTimeRemaine_ForSave;
	
	#ifdef NEW_APP_API
	*(save+6)=gBoilCounts;
	#endif
	
	if(gbDisplay)
		*(save+6)|=0x8000;
}




uint32_t read_test[16];

void DataSave_Read()
{
	uint32_t i=0;
	uint32_t tab_idx=0;
	
//	DataFlash_Read(EEPROM_ADDR,read_test,16);
	
	for(i=0;i<ACK_NUMICRO_EEPROM_SIZE;i+=EEPROM_LEN_BYTE)
	{
		DataFlash_Read(EEPROM_ADDR+i,Read,EEPROM_LEN);	
		
		if(Read[0]==DATA_SAVE_HEAD)
		{
			for(tab_idx=0;tab_idx<EEPROM_LEN;tab_idx++)
				Read2[tab_idx]=Read[tab_idx];
			if(i==(ACK_NUMICRO_EEPROM_SIZE-EEPROM_LEN_BYTE))
				goto ReadSucc;
		}
		else
		{
			if(i==0)
				return;
			EepromAddr+=(i);
			goto ReadSucc;
		}
	}
	
	ReadSucc:
	if(Read2[0]==DATA_SAVE_HEAD)
	{
		UpdateData(&Read2[1]);
		DataSave_Scan(true);
	}
	
	
}


int32_t Write_Eeprom()
{
	int32_t ret;
	
	ret=DataFlash_Save(EepromAddr,Save,EEPROM_LEN);
	EepromAddr+=EEPROM_LEN_BYTE;
	if(EepromAddr>=(EEPROM_ADDR+ACK_NUMICRO_EEPROM_SIZE))
		EepromAddr=EEPROM_ADDR;
	printf("\nNext EepromAddr is [0x%x]!\n", EepromAddr);
	return ret;
}

void DataSave_Scan(bool update)
{
	static uint8_t tmp[6];
	static bool save=false;
	static uint16_t kettle_cycle_count;
	static uint32_t Kettle_heater_life;
	static uint32_t kettle_relay_cycle;
	static uint32_t keep_warm_time_remaine;
	
	#ifdef NEW_APP_API
	static uint16_t boil_counts;
	#endif
	
	static bool display=false;
	
	if(update)
	{
		tmp[0]=TempSet_Celsius;
		tmp[1]=gbKeepWarm;
		tmp[3]=PreSet;
		tmp[4]=KeepWarmMinutesBkp;
		tmp[5]=CanUseApp;
		
		
		kettle_cycle_count=KettleCycleCount;
		Kettle_heater_life=Metrics__Kettle_heater_life;
		kettle_relay_cycle=Metrics__kettle_relay_cycle;
		
		keep_warm_time_remaine=KeepWarmTimeRemaine_ForSave;
		#ifdef NEW_APP_API
		boil_counts=gBoilCounts;
		#endif
		display=gbDisplay;
		return;
	}
	
	#ifdef NEW_APP_API
	if(boil_counts!=gBoilCounts)
		goto update_static;
	#endif
	
	if(tmp[0]!=TempSet_Celsius\
		|| tmp[1]!=gbKeepWarm\
		|| tmp[3]!=PreSet\
		|| tmp[4]!=KeepWarmMinutesBkp\
		|| tmp[5]!=CanUseApp\
		|| kettle_cycle_count!=KettleCycleCount\
		|| Kettle_heater_life!=Metrics__Kettle_heater_life\
		|| kettle_relay_cycle!=Metrics__kettle_relay_cycle\
		|| (gbKeepWarm && keep_warm_time_remaine!=KeepWarmTimeRemaine_ForSave)\
		|| (display!=gbDisplay)\
		)
	update_static:
	{
		tmp[0]=TempSet_Celsius;
		tmp[1]=gbKeepWarm;
		tmp[3]=PreSet;
		tmp[4]=KeepWarmMinutesBkp;
		tmp[5]=CanUseApp;
		kettle_cycle_count=KettleCycleCount;
		Kettle_heater_life=Metrics__Kettle_heater_life;
		kettle_relay_cycle=Metrics__kettle_relay_cycle;
		keep_warm_time_remaine=KeepWarmTimeRemaine_ForSave;
		#ifdef NEW_APP_API
		boil_counts=gBoilCounts;
		#endif
		display=gbDisplay;
		save=true;
		DataSaveDelay=DATA_SAVE_DELAY;
	}
	
	if(save && !DataSaveDelay)
	{
		UpdateSave(&Save[1]);
		
		if(Write_Eeprom()==-1)
		{
			DataSaveDelay=DATA_SAVE_DELAY;
			return;
		}
		
		save=false;
	}
}

void DataSave_HandleForTmrInt()
{
	if(DataSaveDelay)
		DataSaveDelay--;
}










