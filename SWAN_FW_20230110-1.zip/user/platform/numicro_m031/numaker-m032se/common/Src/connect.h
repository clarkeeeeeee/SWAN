#ifndef _CONNECT_H_
#define _CONNECT_H_

#include <stdint.h>
#include "numicro_hal.h"
#include <stdbool.h>
#include "key.h"

typedef enum
{
	eDevStatus_None,
	eDevStatus_Off,
	eDevStatus_Heating,
	eDevStatus_KeepWarm,
	eDevStatus_LowWater,
	eDevStatus_WaterReady,
	eDevStatus_OffBase,
}eDevStatus_t;

extern eDevStatus_t eDevStatus;
extern bool gbModuleInSetupMode;
extern uint8_t CanUseApp;
extern uint32_t Status;
extern uint32_t CurrentTemperature;
extern bool gbforceReport;

void Conn_ForTmrInt();
bool Conn_ModuleRegistered();
void Conn_StartUgs();
void Conn_StartFrs();
void Conn_Handle();
bool ConnRetReadyStatusRemain();


#endif



