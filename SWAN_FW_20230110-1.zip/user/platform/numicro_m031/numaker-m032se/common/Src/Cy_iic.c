#include "Cy_iic.h"

#define IIC_CLK1		PC1=1	
#define IIC_CLK0		PC1=0
#define IIC_DAT1		PC0=1
#define IIC_DAT0		PC0=0
#define IIC_CLK_INIT	//{GPIO_SetMode(PB, BIT4, GPIO_MODE_QUASI);}
#define IIC_DAT_OUT1	IIC_DAT1//{GPIO_SetMode(PC, BIT0, GPIO_MODE_OPEN_DRAIN);IIC_DAT1;}//{GPIO_SetMode(PB, BIT4, GPIO_MODE_QUASI);GPIO_12_SET;}
#define IIC_DAT_OUT0	IIC_DAT0//{GPIO_SetMode(PC, BIT0, GPIO_MODE_OPEN_DRAIN);IIC_DAT0;}//{GPIO_SetMode(PB, BIT4, GPIO_MODE_QUASI);GPIO_12_CLR;}
#define IIC_DAT_IN		//{GPIO_SetMode(PC, BIT0, GPIO_MODE_INPUT);}//GPIO_12_IN
#define IIC_DAT_HIGH	PC0//GPIO_12_TEST

static volatile uint16_t iic_delay_counts;

static void iic_delay()
{
	iic_delay_counts=1;
	
	while(iic_delay_counts)
	{
		iic_delay_counts--;
	}
//	GPIO_SetMode(PC, BIT0, GPIO_MODE_QUASI);
//	iic_delay_counts*=5;
//	if(iic_delay_counts)
//		iic_delay_counts=iic_delay_counts;
}

void iic_init()
{
}

static void iic_start()
{
	IIC_CLK1;
	IIC_DAT_OUT1;
	iic_delay();
	IIC_DAT0;
}

static void iic_stop()
{
	IIC_CLK0;
	IIC_DAT_OUT0;
	iic_delay();
	IIC_CLK1;
	iic_delay();
	IIC_DAT1;
	iic_delay();
}

static void iic_write(u8 dat)
{
	u8 idx=0;
	
	IIC_CLK0;
	iic_delay();
	IIC_DAT_OUT1;
	for(idx=0;idx<8;idx++)
	{
		IIC_CLK0;
		if(dat&0x80)
			IIC_DAT1;
		else
			IIC_DAT0;
		iic_delay();
		IIC_CLK1;
		dat<<=1;
		iic_delay();
	}
}

static void delay2(uint16_t xx)
{
	uint16_t delay=0;
	
	for(;delay<xx;delay++)
	;
}
static void iic_skip_ack()
{
	IIC_CLK0;
	IIC_DAT_IN;
	iic_delay();
	IIC_CLK1;
	iic_delay();
	IIC_CLK0;
	IIC_DAT_OUT1;
}

static u8 iic_read()
{
	u8 idx=0;
	u8 dat=0;
	
	IIC_CLK0;
	IIC_DAT_IN;
	for(idx=0;idx<8;idx++)
	{
		IIC_CLK0;
		iic_delay();
		IIC_CLK1;
		if(IIC_DAT_HIGH)
			dat|=(0X80>>idx);
		iic_delay();
	}
	return dat;
}

static void iic_ack()
{
	IIC_CLK0;
	IIC_DAT_OUT0;
	iic_delay();
	IIC_CLK1;
	iic_delay();
}

static void iic_noack()
{
	IIC_CLK0;
	IIC_DAT_OUT1;
	iic_delay();
	IIC_CLK1;
	iic_delay();
}


void iic_write_bytes(u8 *bytes,u8 cnts)
{
	u8 i=0;
	
	iic_start();
	for(i=0;i<cnts;i++,bytes++)
	{
		iic_write(*bytes);
		iic_skip_ack();
	}
	iic_stop();
}

