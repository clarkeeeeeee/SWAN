/**************************************************************************//**
 * @brief    ACK HMCU platform porting.
 *
 * @note
 * SPDX-License-Identifier: Apache-2.0
 * Copyright (C) 2020 Nuvoton Technology Corp. All rights reserved.
 ******************************************************************************/
 
#include "main.h"
#include "top.h"
#include "ack.h"
#include "dev.h"
#include "led.h"


/**
  * @brief  The application entry point.
  * @retval int
  */
void setup(void);
void loop(void);
void mcu_init(void);

uint16_t AckDelay=100;

bool TestUgs=false;

extern void Alexa_InitiateUserGuidedSetup(void);

int main(void)
{
	
	static bool b_ack_initialized=false;
//    GPIO_SetMode(PF, BIT2, GPIO_MODE_QUASI);
//	PF2=1;
//	while(1);
	
	mcu_init();


	
	
	
    while (1)
    {
        WDT_RESET_COUNTER();
		
		#ifdef ALEXA
		if(!gbDisplay && !GetWifiSearchTicks() && ACK_LifecycleState<ACK_LIFECYCLE_NOT_CONNECTED_TO_ALEXA)
		{
			PB15=0;
			b_ack_initialized=false;
		}
		else if(!b_ack_initialized)
		{
			setup();
			b_ack_initialized=true;
		}
		if(b_ack_initialized)
			loop();
		#endif
		

		UserEventLoop();
    }
}

void RTC_IRQHandler()
{
	
}