#ifndef _OFF_BASE_H_
#define _OFF_BASE_H_

#include <stdint.h>
#include "numicro_hal.h"
#include <stdbool.h>

extern bool gbOffBase_TempCompareInKw;
extern bool gbOffBase;
extern bool gbOffBaseClear_SolidDispTemp;
extern uint16_t OffBase_TempNowBkp;

void OffBaseHandle();
void OffBaseHandleForTmrInt();
void OffBaseTicksClear();

#endif



