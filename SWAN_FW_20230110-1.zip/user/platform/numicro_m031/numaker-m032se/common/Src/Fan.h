#ifndef _FAN_H_
#define _FAN_H_

#include "Hub.h"

void FanSetDuty(u8 per);
void FanHandle();


#endif /* __MAIN_H */
