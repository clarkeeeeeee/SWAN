#include "smg.h"
#include "key.h"
#include "dev.h"
#include "self_check.h"
#include "off_base.h"
#include "low_water.h"
#include "heating.h"
#include "keep_warm.h"
#include "top.h"
#include "remote_counter.h"
#include "led_driver.h"
#include "ack.h"
#include "led.h"

uint16_t SmgOffBaseDispTicks=0;

/*
	0 D E C G B F A
0	0 1 1 1 0 1 1 1		
1	0 0 0 1 0 1 0 0
2	0 1 1 0 1 1 0 1
3	0 1 0 1 1 1 0 1
4	0 0 0 1 1 1 1 0
5	0 1 0 1 1 0 1 1
6	0 1 1 1 1 0 1 1
7	0 0 0 1 0 1 0 1
8	0 1 1 1 1 1 1 1
9	0 1 0 1 1 1 1 1
*/
#if HW_VER>=4
#define WORD_H			0X76
#define WORD_E			0X79
#define WORD_L			0X38
#define WORD_O			0X3f
#define WORD_I			0X06
#define WORD_o			0X5c
#define WORD_t			0X78
#define WORD_LINE		0X40
#define WORD_F			0X71
#define WORD_P			0X73
#define WORD_r			0X50
#define WORD_S			0X6d
#define WORD_n			0X54
#define WORD_2			0X5b
#define WORD_U			0X3e
#define WORD_C			0X39
const 	uint8_t SMG_TAB[10]={0X3f,0X06,0X5b,0X4f,0X66,0X6d,0X7d,0X07,0X7F,0X6f};
#else
#define WORD_H			0X3e
#define WORD_E			0X6b
#define WORD_L			0X62
#define WORD_O			0X77
#define WORD_I			0X14
#define WORD_o			0X78
#define WORD_t			0X6a
#define WORD_LINE		0X08
#define WORD_F			0X2b
#define WORD_P			0X2f
#define WORD_r			0X28
#define WORD_S			0X5b
#define WORD_n			0X38
#define WORD_2			0X6d
#define WORD_U			0X76
#define WORD_C			0X63
const 	uint8_t SMG_TAB[10]={0X77,0X14,0X6d,0X5d,0X1e,0X5b,0X7b,0X15,0X7F,0X5f};
#endif

static 	uint8_t SmgRamBuf[5]={0};
static 	uint8_t SmgRam[5]={0};
static 	uint8_t DutyObj=35;
static 	uint8_t DutyNow=0;
static 	uint16_t LedFadeDownDelay=0;
static 	uint16_t FadeDownTimeUnit=0;
static 	uint16_t SmgUpdateCtxDelay=100;

uint16_t SmgFirmwareVersionDispTicks=0;
uint16_t SmgTempSetSolidDispTicks=0;
uint16_t SmgPreSetWordDispTicks=0;
static uint8_t FirmwareVersion[]=FIRMWARE_VERSION;

static bool bHelloAnimation=false;

void Smg_ReloadOffBaseDispTicks(bool reload)
{
	if(reload)
		SmgOffBaseDispTicks=30000;
	else
		SmgOffBaseDispTicks=0;
}

void SmgFirmwareVersionDispTicksReload()
{
	SmgFirmwareVersionDispTicks=2000;
}
void SmgTempSetSolidDispTicksReload()
{
	SmgTempSetSolidDispTicks=2000;
}
void SmgTempSetSolidDispTicksReload_CauseApp()
{
	SmgTempSetSolidDispTicks=4000;
}

bool SmgGetHelloAnimation()
{
	return bHelloAnimation;
}
void SmgClrHelloAnimation()
{
	bHelloAnimation=false;
}

#define LED_FADE_DOWN
#define FADE_DOWN_DELAY			20
#define FADE_DOWN_TIME			4
#define LED_MAX_DUTY			100
#define LED_MIN_DUTY			20




static void LoadSmgRamBuf(uint8_t idx,uint8_t ctx)
{
	if(idx>2)
		return;
	
	switch(ctx)
	{
		case '0':
		case '1':
		case '2':
		case '3':
		case '4':
		case '5':
		case '6':
		case '7':
		case '8':
		case '9':
			LedDriverRamBuf[idx]=SMG_TAB[ctx-0x30];
		break;
		
		case 'E':
			LedDriverRamBuf[idx]=WORD_E;
		break;
		
		case 'U':
			LedDriverRamBuf[idx]=WORD_U;
		break;
		
		default:
			LedDriverRamBuf[idx]=0;
			break;
	}
}
static void SmgDispStr(uint8_t* str)
{
	LoadSmgRamBuf(1,*str);
	LoadSmgRamBuf(2,*(str+1));
}



#define LED_SEG_D		PA3
#define LED_SEG_E		PA4
#define LED_SEG_F		PA5
#define LED_SEG_A		PA0
#define LED_SEG_B		PA1
#define LED_SEG_C		PA2
#define LED_SEG_G		PA6

#define LED_COM4		PC3
#define LED_COM3		PC4
#define LED_COM2		PC5
#define LED_COM1		PC2
#define LED_COM5		PC1

#define DEF_RIGHT_L_DOT_ON	SmgRamBuf[4]|=1
#define DEF_RIGHT_M_DOT_ON	SmgRamBuf[4]|=2
#define DEF_RIGHT_H_DOT_ON	SmgRamBuf[4]|=8
#define DEF_LEFT_L_DOT_ON	SmgRamBuf[4]|=16
#define DEF_LEFT_M_DOT_ON	SmgRamBuf[4]|=32
#define DEF_LEFT_H_DOT_ON	SmgRamBuf[0]|=128

#define DEF_MIDDLE_DOT1_ON	SmgRamBuf[1]|=128
#define DEF_MIDDLE_DOT2_ON	SmgRamBuf[3]|=128
#define DEF_COLON_ON		SmgRamBuf[2]|=128


#define DUTY_REF		40

static void Clr()
{
	LED_SEG_A=0;
	LED_SEG_B=0;
	LED_SEG_C=0;
	LED_SEG_D=0;
	LED_SEG_E=0;
	LED_SEG_F=0;
	LED_SEG_G=0;
	
	LED_COM1=0;
	LED_COM2=0;
	LED_COM3=0;
	LED_COM4=0;
	LED_COM5=0;
}

void SmgInit()
{
	
}

static uint8_t CalcDuty(uint8_t percent)
{
	uint16_t tmp;
	
	tmp=DUTY_REF;
	tmp*=percent;
	tmp/=100;
	
	return tmp;
}
void LedReloadFadeDownDelay()
{
	LedFadeDownDelay=FADE_DOWN_DELAY*1000;
	DutyObj=DutyNow=CalcDuty(LED_MAX_DUTY);
}
static uint16_t CalcFadeDownTimeUnit()
{
	uint16_t tmp;
	
	if(DutyObj>=DutyNow)
		return 0;
	tmp=FADE_DOWN_TIME;
	tmp*=1000;
	tmp/=(DutyNow-DutyObj);
	
	return tmp;
}
static void UpdateDutyObj()
{
	if(LedFadeDownDelay)
	{
		LedFadeDownDelay--;
		if(!LedFadeDownDelay)
		{
			DutyObj=CalcDuty(LED_MIN_DUTY);
			FadeDownTimeUnit=CalcFadeDownTimeUnit();
		}
	}
}
static void UpdateDutyNow()
{
	static uint16_t Ticks=0;
	
	if(DutyObj>=DutyNow)
	{
		Ticks=0;
		return;
	}
	if(!FadeDownTimeUnit)
	{
		Ticks=0;
		return;
	}
	
	if(++Ticks>=FadeDownTimeUnit)
	{
		Ticks=0;
		DutyNow--;
	}
}
void SmgHandleForTmrInt()
{
	if(SmgUpdateCtxDelay)
		SmgUpdateCtxDelay--;
	UpdateDutyNow();
	if(SmgFirmwareVersionDispTicks)
		SmgFirmwareVersionDispTicks--;
	if(SmgTempSetSolidDispTicks)
		SmgTempSetSolidDispTicks--;
	if(SmgOffBaseDispTicks)
		SmgOffBaseDispTicks--;
	if(SmgPreSetWordDispTicks)
		SmgPreSetWordDispTicks--;
}
static void SmgNbr(uint8_t ctx,uint8_t idx)
{
	if(idx>2)
		return;
	if(ctx>9)
	{
		LedDriverRamBuf[idx]=0;
		return;
	}
	
	#if PCB_US
	LedDriverRamBuf[idx]|=SMG_TAB[ctx];
	#else
	#if HW_VER>=4
	if(idx==0)
	{
		LedDriverRamBuf[1]|=0x80;
		LedDriverRamBuf[2]|=0x80;
	}
	#else
	if(idx==0)
		LedDriverRamBuf[0]|=2;
	#endif
	else
		LedDriverRamBuf[idx]|=SMG_TAB[ctx];
	#endif
}
static void SmgWord(uint8_t ctx,uint8_t idx)
{
	if(idx>2)
		return;
	LedDriverRamBuf[idx]|=ctx;
}

static void SmgPresetBoilWord()
{
	SmgRamBuf[0]|=1;
}
static void SmgPresetBoilTemp()
{
	SmgRamBuf[3]|=1;
}

static void SmgPresetGreenWord()
{
	SmgRamBuf[0]|=2;
}
static void SmgPresetGreenTemp()
{
	SmgRamBuf[3]|=2;
}

static void SmgPresetBlackWord()
{
	SmgRamBuf[0]|=64;
}
static void SmgPresetBlackTemp()
{
	SmgRamBuf[3]|=64;
}
static void SmgPresetHoneyWord()
{
	SmgRamBuf[0]|=4;
}
static void SmgPresetHoneyTemp()
{
	SmgRamBuf[3]|=4;
}

static void SmgPresetMilkWord()
{
	SmgRamBuf[0]|=8;
}
static void SmgPresetMilkTemp()
{
	SmgRamBuf[3]|=8;
}

static void SmgNbr_u16(uint16_t nbr)
{
	if(nbr>999)
		return;
	#if PCB_US
	if(nbr>99)
		SmgNbr(nbr%1000/100,1);
	if(nbr>9)
		SmgNbr(nbr%100/10,2);
	SmgNbr(nbr%10,0);
	#else
	if(nbr>99)
		SmgNbr(nbr%1000/100,0);
	if(nbr>9)
		SmgNbr(nbr%100/10,1);
	SmgNbr(nbr%10,2);
	#endif
}

bool bLedC=false;
bool bLedF=false;
static void DegC()
{
	#if HW_VER>=4
		#if PCB_US
		{
			if(gTempratureUnit==eTempratureUnit_Celsius)
			{
				bLedC=true;
				bLedF=!bLedC;
			}
			else
			{
				bLedF=true;
				bLedC=!bLedF;
			}
		}
		#else
		LedDriverRamBuf[0]|=3;
		#endif
	#else
	LedDriverRamBuf[0]|=1;
	#endif
}
static void PureWater()
{
	SmgRamBuf[4]|=12;
}

#if(0)
static void HelloAnimation()
{
	static uint16_t HelloAnimationTicks=0;
	
	if(HelloAnimationTicks<10)
	{
		SmgWord(WORD_H,2);
	}
	else if(HelloAnimationTicks<20)
	{
		SmgWord(WORD_H,1);
		SmgWord(WORD_E,2);
	}
	else if(HelloAnimationTicks<30)
	{
		SmgWord(WORD_E,1);
		SmgWord(WORD_L,2);
	}
	else if(HelloAnimationTicks<40)
	{
		SmgWord(WORD_L,1);
		SmgWord(WORD_L,2);
	}
	else if(HelloAnimationTicks<50)
	{
		SmgWord(WORD_L,1);
		SmgWord(WORD_O,2);
	}
	else if(HelloAnimationTicks<60)
	{
		SmgWord(WORD_O,1);
	}
	
	if(++HelloAnimationTicks>=60)
	{
		HelloAnimationTicks=0;
		bHelloAnimation=false;
	}
}
#else
static void HelloAnimation()
{
	static uint16_t HelloAnimationTicks=0;
	
//	HelloAnimationTicks=0;
	
	if(HelloAnimationTicks<4)
	{
		PureWater();
		SmgNbr_u16(188);
		DegC();
	}
	else if(HelloAnimationTicks<8)
	{
		PureWater();
		SmgNbr_u16(188);
		DegC();
		SmgPresetBoilWord();
		SmgPresetBoilTemp();
	}
	else if(HelloAnimationTicks<12)
	{
		PureWater();
		SmgNbr_u16(188);
		DegC();
		SmgPresetBoilWord();
		SmgPresetBoilTemp();
		SmgPresetGreenWord();
		SmgPresetGreenTemp();
	}
	else if(HelloAnimationTicks<16)
	{
		PureWater();
		SmgNbr_u16(188);
		DegC();
		SmgPresetBoilWord();
		SmgPresetBoilTemp();
		SmgPresetGreenWord();
		SmgPresetGreenTemp();
		SmgPresetBlackWord();
		SmgPresetBlackTemp();
	}
	else if(HelloAnimationTicks<20)
	{
		PureWater();
		SmgNbr_u16(188);
		DegC();
		SmgPresetBoilWord();
		SmgPresetBoilTemp();
		SmgPresetGreenWord();
		SmgPresetGreenTemp();
		SmgPresetBlackWord();
		SmgPresetBlackTemp();
		SmgPresetHoneyWord();
		SmgPresetHoneyTemp();
	}
	else if(HelloAnimationTicks<24)
	{
		PureWater();
		SmgNbr_u16(188);
		DegC();
		SmgPresetBoilWord();
		SmgPresetBoilTemp();
		SmgPresetGreenWord();
		SmgPresetGreenTemp();
		SmgPresetBlackWord();
		SmgPresetBlackTemp();
		SmgPresetHoneyWord();
		SmgPresetHoneyTemp();
		SmgPresetMilkWord();
		SmgPresetMilkTemp();
	}
	
	if(++HelloAnimationTicks>=24)
	{
		HelloAnimationTicks=0;
		bHelloAnimation=false;
	}
}
#endif

static void SmgNbr_u16_Under1000(uint16_t nbr)
{
	#if PCB_US
	if(nbr>99)
		SmgNbr(nbr%1000/100,1);
	if(nbr>9)
		SmgNbr(nbr%100/10,2);
	SmgNbr(nbr%10,0);
	#else
	if(nbr>199)
	{
		SmgWord(1,WORD_LINE);
		SmgWord(2,WORD_LINE);
		return;
	}
	if(nbr>99)
		SmgNbr(nbr%1000/100,0);
	if(nbr>9)
		SmgNbr(nbr%100/10,1);
	SmgNbr(nbr%10,2);
	#endif
}
static void ClrSmgRamBuf()
{
	uint8_t i;
	
	for(i=0;i<sizeof(LedDriverRamBuf);i++)
		LedDriverRamBuf[i]=0;
}
static void FillSmgRamBuf()
{
	uint8_t i;
	
	for(i=0;i<sizeof(LedDriverRamBuf);i++)
		LedDriverRamBuf[i]=0xff;
}
uint8_t SmgTest=0;


uint8_t HeatingShowTicks=0;
static void HeatingShow()
{
	static bool bSmgTempSetSolidDispTicks=false;
	
	if(SmgTempSetSolidDispTicks)
	{
		HeatingShowTicks=40;
		bSmgTempSetSolidDispTicks=true;
	}
	else if(bSmgTempSetSolidDispTicks)
	{
		bSmgTempSetSolidDispTicks=false;
		HeatingShowTicks=0;
	}
	
	if(HeatingShowTicks<30)
	{
		if(TempNow_Celsius<=100)
		{
			SmgNbr_u16_Under1000(TempNow_Celsius);
			DegC();
		}
	}
	else
	{
		SmgNbr_u16_Under1000(TempSet_Celsius);
		DegC();
	}
	
	if(++HeatingShowTicks>=30)
		HeatingShowTicks=0;
}

static void PresetShow()
{
	bool sta=true;
	
	if(HeatintRetStatus())
	{
		if(SmgPreSetWordDispTicks>300)
			sta=false;
		if(SmgPreSetWordDispTicks<=0)
			SmgPreSetWordDispTicks=600;
	}
	else
		SmgPreSetWordDispTicks=0;
	
	switch(PreSet)
	{
		case 1:
			if(sta)
				SmgPresetBoilWord();
			SmgPresetBoilTemp();
		break;
		case 2:
			if(sta)
				SmgPresetGreenWord();
			SmgPresetGreenTemp();
		break;
		case 3:
			if(sta)
				SmgPresetBlackWord();
			SmgPresetBlackTemp();
		break;
		case 4:
			if(sta)
				SmgPresetHoneyWord();
			SmgPresetHoneyTemp();
		break;
		case 5:
			if(sta)
				SmgPresetMilkWord();
			SmgPresetMilkTemp();
		break;
		
		default:
			break;
	}
}

uint8_t KeepWarmShowTicks=0;
static void KeepWarmShow()
{
	SmgNbr_u16_Under1000(TempNow_Celsius);
	DegC();
	PureWater();
}


static void HotShow()
{
	SmgWord(WORD_H,1);
	SmgWord(WORD_t,2);
}

static void NoKettleShow()
{
	SmgWord(WORD_LINE,1);
	SmgWord(WORD_LINE,2);
}


//FillH2O_Animation
static void FillH2O_Animation()
{
	SmgWord(WORD_L,1);
	SmgWord(WORD_o,2);
}

static void SmgSelfCheck()
{
	uint8_t str[2];
	
	switch(SelfCheckRetSteps())
	{
		case 0:
			str[0]=str[1]='8';
			SmgDispStr(str);
		break;
			
		case 1:
		break;
			
		case 2:
		break;
			
		case 3:
		break;
		
		case 8:
			switch(geKey)
			{
				case eKey_IO:
					str[0]=str[1]='1';
					SmgDispStr(str);
				break;
				case eKey_P:
					str[0]=str[1]='2';
					SmgDispStr(str);
				break;
				case eKey_M:
					str[0]=str[1]='3';
					SmgDispStr(str);
				break;
				case eKey_WIFI:
					str[0]=str[1]='4';
					SmgDispStr(str);
				break;
				
				default:
				break;
			}
		break;
		case 9:
			
			if(gbOffBase)
			{
				str[0]='E';
				str[1]='2';
				SmgDispStr(str);
			}
			else if(!gbAckDsnRecived)
			{
				str[0]='E';
				str[1]='1';
				SmgDispStr(str);
			}
			else
			{
				SmgDispStr(FirmwareVersion);
			}
		break;

			
		default:
		break;
	}
}
//

#if PCB_US
#define UNIT_LED_ON		LedDriverRamBuf[3]|=0X1C
#endif

#if HW_VER>=4
	#if PCB_US
	#define POWER_WHITE_LED_ON		LedDriverRamBuf[3]|=0Xe0
	#define PRESET_LED_ON			{LedDriverRamBuf[1]|=0X80;LedDriverRamBuf[3]|=0X3;}
	#else
	#define POWER_WHITE_LED_ON		LedDriverRamBuf[3]|=0Xf0
	#define PRESET_LED_ON			LedDriverRamBuf[3]|=0X0f
	#endif
#else
#define POWER_WHITE_LED_ON		LedDriverRamBuf[0]|=0X10
#define PRESET_LED_ON			LedDriverRamBuf[0]|=0X20
#endif

#if HW_VER>=4
	#if PCB_US
	#define KEEP_WARM_LED_ON		LedDriverRamBuf[0]|=0X80
	#define BOIL_LED_ON				LedDriverRamBuf[1]|=0X20
	#define POWER_BLUE_LED_ON		LedDriverRamBuf[2]|=0X80
	#else
	#define KEEP_WARM_LED_ON		LedDriverRamBuf[0]|=0X38
	#define BOIL_LED_ON				LedDriverRamBuf[0]|=0Xc0
	#define POWER_BLUE_LED_ON		LedDriverRamBuf[0]|=0X04
	#endif
#else
#define KEEP_WARM_LED_ON		LedDriverRamBuf[0]|=0X04
#define BOIL_LED_ON				LedDriverRamBuf[0]|=0X08
#define POWER_BLUE_LED_ON		LedDriverRamBuf[0]|=0X40
#endif


extern uint16_t AdcRes;
uint16_t PowerUpDispAll=300;
uint16_t WifiCfgDispAll=0;

#define TU_C_ON		PC4=1
#define TU_C_OFF	PC4=0
#define TU_F_ON		PC5=1
#define TU_F_OFF	PC5=0


bool gbFlash=false;
static void gbFlashUpdate()
{
	static uint8_t ticks=0;
	
	if(++ticks>=50)
	{
		ticks=0;
		gbFlash=!gbFlash;
	}
}

static bool GetDispFlag(uint16_t *ticks)
{
	if((*ticks)>350 || ((*ticks)>250 && (*ticks)<300) || ((*ticks)>150 && (*ticks)<200) || ((*ticks)>50 && (*ticks)<100))
		return true;
	return false;
}

static void WifiCfgLed()
{
	if(gbKeyFrsEn)
	{
		
	}
}



uint16_t SmgTempratureNow=0;

void SmgHandle()
{
	uint8_t str[]="1234";
	
	gbFlashUpdate();
//	if(bHelloAnimation || SelfCheckRetStatus() || gbSelfCheckKeysEn)
//		return;
	
	if(!SmgUpdateCtxDelay)
	{
		SmgUpdateCtxDelay=0;
		
		ClrSmgRamBuf();

//		SmgNbr_u16(sKey.key_now);
//		goto smg_refresh;
		
		if(!gbDisplay)
			PowerUpDispAll=0;
		if(PowerUpDispAll)
		{
			PowerUpDispAll--;
			FillSmgRamBuf();
			#if PCB_US
			TU_C_ON;
			TU_F_ON;
			#endif
			goto smg_refresh;
		}
		
		
		
		if(WifiCfgDispAll)
		{
			WifiCfgDispAll--;
			if(WifiCfgDispAll<50 \
				|| (WifiCfgDispAll<150 && WifiCfgDispAll>100)\
				|| (WifiCfgDispAll<250 && WifiCfgDispAll>200)\
				|| (WifiCfgDispAll<350 && WifiCfgDispAll>300)\
				|| (WifiCfgDispAll<450 && WifiCfgDispAll>400)\
			)
			{
				FillSmgRamBuf();
				#if PCB_US
				TU_C_ON;
				TU_F_ON;
				#endif
			}
			#if PCB_US
			else
			{
				TU_C_OFF;
				TU_F_OFF;
			}
			#endif
			goto smg_refresh;
		}
		
		if(gbWifiLedStatus)
			POWER_BLUE_LED_ON;
		
		
		#if(0)
		if(SmgFirmwareVersionDispTicks)
		{
			SmgDispStr(FirmwareVersion);
			goto smg_refresh;
		}
		
		if(DevGetTempSetShow())
		{
			if(DevGetTempSetFlashShow())
			{
				SmgNbr_u16_Under1000(TempSet_Celsius);
				DegC();
			}
			
			HeatingShowTicks=0;
			KeepWarmShowTicks=0;
			goto smg_refresh;
		}
		

OffBase_Routine:	
		if(gbOffBase && (gbPower || SmgOffBaseDispTicks || gbOffBaseClear_SolidDispTemp))
		{
			if(gbOffBaseClear_SolidDispTemp)
			{
				HeatingShowTicks=0;
				if(TempNow_Celsius<=100)
				{
					SmgNbr_u16_Under1000(TempNow_Celsius);
					DegC();
				}
				goto smg_refresh;
			}
			
			NoKettleShow();
			goto smg_refresh;
		}
		
Smg_LowWater:	
		if(LowWaterRetStatus())
		{
			FillH2O_Animation();
			goto smg_refresh;
		}
Smg_Heating:		
//		if(HeatintRetStatus())
//		{
//			HeatingShow();
//			PresetShow();
//			goto smg_refresh;
//		}
//		if(HeatintRetHeatingDone())
//		{
//			SmgNbr_u16_Under1000(TempSet_Celsius);
//			DegC();
//			goto smg_refresh;
//		}
Smg_KeepWarm:
//		if(gbPower && (KeepWarmRetStatus() || gbReadyStatus))
//		{
//			KeepWarmShow();
//			PresetShow();
//			goto smg_refresh;
//		}
		#endif
		
//		SmgNbr_u16_Under1000(ACK_LifecycleState);
//		goto smg_refresh;
		
		if(gFmVerDisplay)
		{
			gFmVerDisplay--;
			SmgDispStr(FirmwareVersion);
			#if PCB_US
			TU_C_OFF;
			TU_F_OFF;
			#endif
			goto smg_refresh;
		}
		
		if(gbDisplay)
		{
			#if PCB_US
			UNIT_LED_ON;
			#endif
			
			#if PCB_US
			if(bLedC)
				PC4=1;
			else
				PC4=0;
			if(bLedF)
				PC5=1;
			else
				PC5=0;
			#endif
			
			if(gbCustomerTest)
			{
				if(gbFlash)
				{
					PRESET_LED_ON;
				}
				else
					POWER_WHITE_LED_ON;
			}
			else
			{
				PRESET_LED_ON;
				POWER_WHITE_LED_ON;
			}
			
			
			if(PreSetChangedTicks)
			{
				if(GetDispFlag(&PreSetChangedTicks) || gbDisplayTempSetSolid)
				{
					SmgNbr_u16_Under1000(gTempratureUnit==eTempratureUnit_Fahrenheit?TempSet_Fahrenheit:TempSet_Celsius);
				}
				DegC();
				#if PCB_US
				if(PreSet<11)
				#else
				if(PreSet!=6)	//PreSet=1,100C,boil
				#endif
					KEEP_WARM_LED_ON;
				else
					BOIL_LED_ON;
				goto smg_refresh;
			}
			
			if(PowerOnDispTempSetTicks)
			{
				if(GetDispFlag(&PowerOnDispTempSetTicks))
				{
					SmgNbr_u16_Under1000(gTempratureUnit==eTempratureUnit_Fahrenheit?TempSet_Fahrenheit:TempSet_Celsius);
				}
				DegC();
				goto smg_refresh;
			}
			
			if(gbPower)
			{
				static bool b_display_temp_now=false;
				if(KeepWarmRetStatus() || gbReadyStatus)
				{
					if(TempNow_Celsius>TempSet_Celsius+5 || bReheat || TempNow_Celsius<TempSet_Celsius-5)
					{
						if(gbFlash)
							KEEP_WARM_LED_ON;
						
						if(TempNow_Celsius==TempSet_Celsius)
							b_display_temp_now=false;
						if(TempNow_Celsius>TempSet_Celsius+5 || b_display_temp_now || TempNow_Celsius<TempSet_Celsius-5)
						{
							SmgNbr_u16_Under1000(SmgTempratureNow=(gTempratureUnit==eTempratureUnit_Fahrenheit?gTempNowFahrenheit:TempNow_Celsius));
//							SmgNbr_u16_Under1000(TempNow_Celsius);
							b_display_temp_now=true;
						}
						else
							SmgNbr_u16_Under1000(SmgTempratureNow=(gTempratureUnit==eTempratureUnit_Fahrenheit?TempSet_Fahrenheit:TempSet_Celsius));
					}
					else
					{
						b_display_temp_now=false;
						KEEP_WARM_LED_ON;
						SmgNbr_u16_Under1000(SmgTempratureNow=(gTempratureUnit==eTempratureUnit_Fahrenheit?TempSet_Fahrenheit:TempSet_Celsius));
					}
					DegC();
					goto smg_refresh;
				}
				b_display_temp_now=false;
				
				#if PCB_US
				if(PreSet<11)
				#else
				if(PreSet!=6)	//PreSet=1,100C,boil
				#endif
				{
					if(gbFlash)
					{
						KEEP_WARM_LED_ON;
//						BOIL_LED_ON;
					}
				}
				else
				{
					if(gbFlash)BOIL_LED_ON;
				}
			}
			
			if(gbTemp100HeatDone)
				SmgNbr_u16_Under1000(SmgTempratureNow=(gTempratureUnit==eTempratureUnit_Fahrenheit?TempSet_Fahrenheit:TempSet_Celsius));
			else
				SmgNbr_u16_Under1000(SmgTempratureNow=(gTempratureUnit==eTempratureUnit_Fahrenheit?gTempNowFahrenheit:TempNow_Celsius));
			DegC();
			goto smg_refresh;
		}
		else
		{
			POWER_WHITE_LED_ON;
			#if PCB_US
			TU_C_OFF;
			TU_F_OFF;
			#endif
		}
smg_refresh:	
		
		
		
		DutyObj=DutyNow=LED_MAX_DUTY;
		
		
	}
}

void SmgHandle2()
{
	if(!bHelloAnimation && !SelfCheckRetStatus() && !gbSelfCheckKeysEn)
		return;
	
//	bHelloAnimation=false;
	
	if(!SmgUpdateCtxDelay)
	{
		SmgUpdateCtxDelay=100;
		
		ClrSmgRamBuf();

		if(SelfCheckRetStatus() || gbSelfCheckKeysEn)
		{
			if(SelfCheckRetStatus())
			{
				SmgSelfCheck();
			}
		}			
		else if(bHelloAnimation)
		{
			HelloAnimation();
		}
		
	}
}





