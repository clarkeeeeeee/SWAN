#include "keep_warm.h"
#include "heating.h"

#include "off_base.h"
#include "low_water.h"
#include "remote_counter.h"
#include "dev.h"
#include "metrics.h"

bool gbKeepWarm=false;
uint32_t KeepWarmTicks=0;
bool gbKeepWarmRelay=false;
bool bReheat=false;
static uint16_t KeepWarmTemp;

uint32_t KeepWarmMinutes=DEFAULT_KEEP_WARM_MINUTES;
uint32_t KeepWarmMinutesBkp=DEFAULT_KEEP_WARM_MINUTES;
uint32_t KeepWarmTime=0;
uint32_t KeepWarmTimeRemaine_ForSave=0;

bool gbKeepWarmStatusPreviousPowerCircle=false;

void UpdateKeepWarmMinutesFromKeepWarmTime()
{
//	if(!gbKeepWarm)
//	{
//		KeepWarmMinutes=13;
//		return;
//	}
	
	if((KeepWarmTime%KEEP_WARM_MINUTES__TOTAL_MS)==0)
		KeepWarmMinutes=KeepWarmTime/KEEP_WARM_MINUTES__TOTAL_MS;
	else
		KeepWarmMinutes=KeepWarmTime/KEEP_WARM_MINUTES__TOTAL_MS+1;
}



void KeepWarmReloadKeepWarmTime()
{
	KeepWarmTime=KeepWarmMinutesBkp*KEEP_WARM_MINUTES__TOTAL_MS;
	UpdateKeepWarmMinutesFromKeepWarmTime();
}


void KeepWarmStart()
{
	if(!KeepWarmMinutesBkp)
	{
		if(DevPowerOff())
			Metrics_SetkettleEndMethod(eMetrics_kettleEndMethod_ASO);
		if(gbRemotePowerOn)
			gRemoteCounter++;
		return;
	}
	
	if(!gbKeepWarm)
	{
		gbKeepWarm=true;
		KeepWarmReloadKeepWarmTime();
	}
}
void KeepWarmStop()
{
	if(gbKeepWarm)
	{
		gbKeepWarm=false;
		KeepWarmReloadKeepWarmTime();
	}
}
bool KeepWarmRetStatus()
{
	return gbKeepWarm;
}


static void UpdateKeepWarmTemp()
{
	if(TempSet_Celsius>=96)
		KeepWarmTemp=95;
	else
		KeepWarmTemp=TempSet_Celsius;
}


void KeepWarmHandle()
{
	static uint16_t temp_pre;
	static uint16_t temp_up=0;
	
	if(!gbPower || gbLowWater)
	{
		gbKeepWarm=false;
		gbKeepWarmRelay=false;
		bReheat=false;
		gbTempBkp_KeepWarmLowWaterHandleUpdated=false;
		return;
	}
	
//	if(gbOffBase)
//	{
//		gbKeepWarmRelay=false;
//		bReheat=false;
//		gbTempBkp_KeepWarmLowWaterHandleUpdated=false;
//		return;
//	}
	
	if(!gbKeepWarm)
	{
		gbKeepWarmRelay=false;
		bReheat=false;
		gbTempBkp_KeepWarmLowWaterHandleUpdated=false;
		return;
	}
	
	if(DevGetTempSetStatus())
	{
		gbKeepWarmRelay=false;
		bReheat=false;
		KeepWarmTicks=0;
		gbTempBkp_KeepWarmLowWaterHandleUpdated=false;
		return;
	}
	
	UpdateKeepWarmTemp();
	
	if(bReheat && !gbOffBase_TempCompareInKw)
	{
		if(TempNow_Celsius>=KeepWarmTemp)
		{
			bReheat=false;
			gbKeepWarmRelay=false;
			KeepWarmTicks=0;
			gbClear_bCompareTempBkp=false;
//			gbTempBkp_KeepWarmLowWaterHandleUpdated=false;
		}
		else
		{
			#if RELAY_CTRL_WITH_ALGORITHM
			if(TempNow_Celsius<KeepWarmTemp-10)
				gbKeepWarmRelay=true;
			else if(temp_up>=3)
			{
				gbKeepWarmRelay=false;
			}
			else if(temp_up)
			{
				if(KeepWarmTicks<=(500-temp_up*200))
					gbKeepWarmRelay=true;
				else
					gbKeepWarmRelay=false;
			}
			else
			{
				if(KeepWarmTicks<=500)
					gbKeepWarmRelay=true;
				else
					gbKeepWarmRelay=false;
			}
			#else
			gbKeepWarmRelay=true;
			#endif
		}
		#if RELAY_CTRL_WITH_ALGORITHM
		if(KeepWarmTicks>=1200)
		{
			KeepWarmTicks=0;
			if(TempNow_Celsius>temp_pre)
				temp_up=(TempNow_Celsius-temp_pre);
			else
				temp_up=0;
			temp_pre=TempNow_Celsius;
			gbTempBkp_KeepWarmLowWaterHandleUpdated=true;
			TempBkp_KeepWarmLowWaterHandle=TempNow_Celsius;
		}
		#endif
	}
	else
	{
		gbClear_bCompareTempBkp=false;
		temp_up=0;
		temp_pre=TempNow_Celsius;
		gbKeepWarmRelay=false;
		
		uint8_t diff;
		if(KeepWarmTemp<=60)
			diff=3;
		else
			diff=3;
		
		if(TempNow_Celsius<KeepWarmTemp && (KeepWarmTemp-TempNow_Celsius)>=diff)
		{
			bReheat=true;
			KeepWarmTicks=0;
			gbTempBkp_KeepWarmLowWaterHandleUpdated=true;
			KeepWarmLowWaterHandleValidTime=0;
			TempBkp_KeepWarmLowWaterHandle=TempNow_Celsius;
		}
	}
}

void KeepWarmHandleForTmrInt()
{
	KeepWarmLowWaterHandleValidTime++;
	KeepWarmTicks++;
	if(gbKeepWarm && KeepWarmTime && !HeatintRetHeatingDone())
	{
		KeepWarmTime--;
		UpdateKeepWarmMinutesFromKeepWarmTime();
		if(!KeepWarmTime)
		{
			if(DevPowerOff())
				Metrics_SetkettleEndMethod(eMetrics_kettleEndMethod_ASO);
			if(gbRemotePowerOn)
				gRemoteCounter++;
		}
		
		if(KeepWarmTime%KEEP_WARM_REMAIN_UNIT)
			KeepWarmTimeRemaine_ForSave=KeepWarmTime/KEEP_WARM_REMAIN_UNIT+1;
		else
			KeepWarmTimeRemaine_ForSave=KeepWarmTime/KEEP_WARM_REMAIN_UNIT;
	}
}













