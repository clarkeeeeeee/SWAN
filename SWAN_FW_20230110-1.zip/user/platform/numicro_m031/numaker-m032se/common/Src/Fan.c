#include "Fan.h"

#define	FAN_PWM			PA15
#define	FAN_CTRL		PA14
#define FAN_PERIOD		20

u8 FanDuty=0;

void FanSetDuty(u8 per)
{
	u16 tmp;
	
	tmp=FAN_PERIOD;
	tmp*=per;
	tmp/=100;
	
	FanDuty=tmp;
}

void FanHandle()
{
	static u8 Ticks=0;
	
//	FAN_PWM=0;
//	return;
	
	if(Ticks<FanDuty)
		FAN_PWM=1;
	else
		FAN_PWM=0;
	
	if(++Ticks>=FAN_PERIOD)
		Ticks=0;
	
	if(FanDuty)
		FAN_CTRL=1;
	else
		FAN_CTRL=0;
}