#ifndef _LED_H_
#define _LED_H_

#include <stdint.h>
#include "numicro_hal.h"
#include <stdbool.h>

extern bool gbWifiLost;

typedef enum
{
	eLedStatus_Off,
	eLedStatus_RedOn,
	eLedStatus_RedBlinkingAt1Hz,
	eLedStatus_RedBlinkingAt2Hz,
	eLedStatus_RedBreath,
	
	eLedStatus_BlueOn,
	eLedStatus_RedBlueBlinkingAt1Hz,
	eLedStatus_RedBlinkingAt0Hz5,
	eLedStatus_BlueBlinkingAt0Hz5,
	eLedStatus_BlueBlinkingAt0S2,
}eLedStatus_t;

extern bool gbWifiLedStatus;
extern eLedStatus_t eLedStatus;

void LedInit();
void LedHandle();
void LedHandleForTmrInt();
bool LedResetWifiSearchTicks();
bool GetWifiSearchTicks();


#endif








