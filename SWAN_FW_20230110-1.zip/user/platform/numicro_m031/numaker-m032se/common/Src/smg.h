#ifndef _SMG_H_
#define _SMG_H_

#include <stdint.h>
#include "numicro_hal.h"
#include <stdbool.h>

extern uint16_t PowerUpDispAll;
extern uint16_t WifiCfgDispAll;

void SmgInit();
void SmgHandle();
void SmgHandle2();
void SmgScan();
void SmgHandleForTmrInt();
void SmgReloadFadeDownDelay();
void SmgClrHelloAnimation();
bool SmgGetHelloAnimation();
void SmgFirmwareVersionDispTicksReload();
void SmgTempSetSolidDispTicksReload();
void SmgTempSetSolidDispTicksReload_CauseApp();
void Smg_ReloadOffBaseDispTicks(bool reload);

#endif



