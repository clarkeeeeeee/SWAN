#ifndef _DATA_FLASH_H_
#define _DATA_FLASH_H_

#include <stdint.h>
#include "numicro_hal.h"
#include <stdbool.h>


void DataFlash_Init(void);
int32_t DataFlash_Save(uint32_t addr,uint32_t *data,uint32_t data_len);
int32_t DataFlash_Read(uint32_t addr,uint32_t *data,uint32_t data_len);

#endif



