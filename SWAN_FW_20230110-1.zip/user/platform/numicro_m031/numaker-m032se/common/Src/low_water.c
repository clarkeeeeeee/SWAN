#include "low_water.h"
#include "dev.h"
#include "heating.h"
#include "keep_warm.h"
#include "off_base.h"
#include "top.h"
#include "metrics.h"
#include "board.h"

#define LOW_WATER_TEMP_NOW_BUF_LEN		10
#define LOW_WATER_TEMP_COMPARE_START_SEC	16
#define LOW_WATER_TEMP_COMPARE_STOP_SEC		46

bool gbLowWater=false;
uint32_t LowWaterTicks=0;
uint32_t LowWaterRemainTicks=0;

static uint16_t LowWater_TempNowBuf[LOW_WATER_TEMP_NOW_BUF_LEN];
static uint8_t LowWater_TempNowBufIdx=0;
static uint8_t LowWater_TempCompareIdx=0;
static bool LowWater_TempCompareRes=false;


static void LowWater_TempCompare()
{
	if(gbLowWater || LowWaterTicks>=LOW_WATER_TEMP_COMPARE_STOP_SEC*100)
		return;
	
	if(LowWaterTicks>=LOW_WATER_TEMP_COMPARE_START_SEC*100 && (LowWaterTicks%100)==0)
	{
		if(TempNow_Celsius>LowWater_TempNowBuf[LowWater_TempCompareIdx] && (TempNow_Celsius-LowWater_TempNowBuf[LowWater_TempCompareIdx])>=10)
			LowWater_TempCompareRes=true;
		
		if(++LowWater_TempCompareIdx>=LOW_WATER_TEMP_NOW_BUF_LEN)
			LowWater_TempCompareIdx=0;
	}
}
static void UpdateLowWater_TempNowBuf()
{
	if(gbLowWater || LowWaterTicks>=LOW_WATER_TEMP_COMPARE_STOP_SEC*100)
		return;
	
	if(LowWaterTicks>=((LOW_WATER_TEMP_COMPARE_START_SEC-LOW_WATER_TEMP_NOW_BUF_LEN)*100))
	{
		if((LowWaterTicks%100)==0)
		{
			LowWater_TempNowBuf[LowWater_TempNowBufIdx++]=TempNow_Celsius;
			if(LowWater_TempNowBufIdx>=LOW_WATER_TEMP_NOW_BUF_LEN)
				LowWater_TempNowBufIdx=0;
		}
	}
}

void LowWaterRemainTicksReload()
{
	LowWaterRemainTicks=LOW_WATER_SHOW;
}



bool gbRelayStatus_KeepWarmLowWaterHandle=false;

uint16_t TempBkp_KeepWarmLowWaterHandle;
bool gbTempBkp_KeepWarmLowWaterHandleUpdated=false;
uint32_t KeepWarmLowWaterHandleValidTime=0;


static bool bCompareTempBkp=false;
bool gbClear_bCompareTempBkp=false;
static bool KeepWarmLowWaterHandle()
{
	
	
	//return false;
	
//	if(gbKeepWarmRelay)
	
	if(TempNow_Celsius==0xff)
		return false;
	
	if(gbTempBkp_KeepWarmLowWaterHandleUpdated)
	{
		#if RELAY_CTRL_WITH_ALGORITHM
		if(TempNow_Celsius>TempBkp_KeepWarmLowWaterHandle && (TempNow_Celsius-TempBkp_KeepWarmLowWaterHandle)>=12)
		#else
		if(KeepWarmLowWaterHandleValidTime<3000 && TempNow_Celsius>TempBkp_KeepWarmLowWaterHandle && (TempNow_Celsius-TempBkp_KeepWarmLowWaterHandle)>=12)
		#endif
		{
			printf("KeepWarmLowWaterHandle -->> gbKeepWarmRelay return true\n");
			return true;
		}
	}
	
	return false;
	
	if(gbClear_bCompareTempBkp)
	{
		bCompareTempBkp=false;
		if(!gbRelayStatus_KeepWarmLowWaterHandle)
		{
			TempBkp_KeepWarmLowWaterHandle=TempNow_Celsius;
			gbRelayStatus_KeepWarmLowWaterHandle=true;
			printf("TempBkp_KeepWarmLowWaterHandle -->> %d",TempBkp_KeepWarmLowWaterHandle);
		}
		
		if(TempNow_Celsius>TempBkp_KeepWarmLowWaterHandle && (TempNow_Celsius-TempBkp_KeepWarmLowWaterHandle)>=8)
		{
			printf("KeepWarmLowWaterHandle -->> gbKeepWarmRelay return true\n");
			return true;
		}
	}
	else
	{
		if(gbRelayStatus_KeepWarmLowWaterHandle)
			bCompareTempBkp=true;
		gbRelayStatus_KeepWarmLowWaterHandle=false;
		
		if(bCompareTempBkp && (TempNow_Celsius>TempBkp_KeepWarmLowWaterHandle) && (TempNow_Celsius-TempBkp_KeepWarmLowWaterHandle)>=8)
		{
			bCompareTempBkp=false;
			printf("KeepWarmLowWaterHandle -->> !gbKeepWarmRelay return true\n");
			return true;
		}
	}
	
	return false;
}

static void ClearLowWater_TempComparePra()
{
	LowWater_TempCompareRes=false;
	LowWater_TempNowBufIdx=LowWater_TempCompareIdx=0;
}


bool LowWaterRetStatus()
{
	if(gbLowWater && LowWaterRemainTicks)
		return true;
	return false;
}
void LowWaterHandle()
{
	if(!gbKeepWarm)
	{
		gbRelayStatus_KeepWarmLowWaterHandle=false;
		bCompareTempBkp=false;
	}
	
//	if(gbOffBase_TempCompareInKw)
//	{
//		gbLowWater=false;
//		LowWaterTicks=0;
//		LowWaterRemainTicks=0;
//		ClearLowWater_TempComparePra();
//		gbRelayStatus_KeepWarmLowWaterHandle=false;
//		bCompareTempBkp=false;
//		return;
//	}
	
	if(gbLowWater)
	{
		ClearLowWater_TempComparePra();
		gbRelayStatus_KeepWarmLowWaterHandle=false;
		bCompareTempBkp=false;
		goto LowWaterTicksMonitor;
	}
	
//	if(TempNow_Celsius!=0xff && TempNow_Celsius>=103)
//	{
//		if(!gbLowWater)
//		{
//			gbLowWater=true;
//			BuzzerTimeUnit=100;
//			BuzzerTime=BuzzerTimeUnit*11;
//			DevPowerOff();
//		}
//		LowWaterRemainTicksReload();
//		goto LowWaterTicksMonitor;
//	}
	
	if(KeepWarmRetStatus())
	{
		ClearLowWater_TempComparePra();
		gbRelayStatus_KeepWarmLowWaterHandle=false;
		bCompareTempBkp=false;
		if(KeepWarmLowWaterHandle())
		{
			if(!gbLowWater)
			{
				gbLowWater=true;
				BuzzerTimeUnit=100;
				BuzzerTime=BuzzerTimeUnit*11;
				DevPowerOff();
			}
			LowWaterRemainTicksReload();
			goto LowWaterTicksMonitor;
		}			
		return;
	}
	else
	{
		bCompareTempBkp=false;
		gbRelayStatus_KeepWarmLowWaterHandle=false;
	}
	
//	if(!gbHeatRelay)
	if(!gbHeating)
	{
		ClearLowWater_TempComparePra();
		gbRelayStatus_KeepWarmLowWaterHandle=false;
		bCompareTempBkp=false;
		LowWaterTicks=0;
		return;
	}
	else
	{
		if(LowWater_TempCompareRes)
//		if(LowWater_TempCompareRes || TempUnit==1)
		{
			ClearLowWater_TempComparePra();
			gbRelayStatus_KeepWarmLowWaterHandle=false;
			bCompareTempBkp=false;
			if(!gbLowWater)
			{
				gbLowWater=true;
				BuzzerTimeUnit=100;
				BuzzerTime=BuzzerTimeUnit*11;
				DevPowerOff();
			}
			LowWaterRemainTicksReload();
			goto LowWaterTicksMonitor;
		}
	}

LowWaterTicksMonitor:	
	if(gbLowWater)
	{
		if(!LowWaterRemainTicks)
		{
			if(DevPowerOff())
				Metrics_SetkettleEndMethod(eMetrics_kettleEndMethod_LowWater);
		}
	}
}

void LowWaterHandleForTmrInt()
{
	if(gbHeating)
		LowWaterTicks++;
	
	if(LowWaterRemainTicks)
		LowWaterRemainTicks--;
	
	if(gbHeating)
	{
		LowWater_TempCompare();
		UpdateLowWater_TempNowBuf();
	}
}

