#include "t_deg.h"

uint16_t T_DegConvFromCToF2(uint16_t c_with_dot)
{
	uint32_t tmp;
	
	tmp=c_with_dot;
	tmp*=18;
	tmp+=3200;
	tmp/=10;
	
	if((tmp%10)>=5)
		return (tmp/10)+1;
	return (tmp/10);
}
uint16_t T_DegConvFromCToF(uint16_t c)
{
	uint16_t tmp;
	
	tmp=c;
	tmp*=18;
	tmp+=320;
	
	if((tmp%10)>=5)
		return (tmp/10)+1;
	return (tmp/10);
}
uint16_t T_DegConvFromFToC(uint16_t f)
{
	uint16_t tmp;
	
	tmp=f;
	if(tmp<=32)
		return 0;
	tmp*=10;
	tmp-=320;
	tmp*=10;
	tmp/=18;
	
	if((tmp%10)>=5)
		return (tmp/10)+1;
	return (tmp/10);
}


