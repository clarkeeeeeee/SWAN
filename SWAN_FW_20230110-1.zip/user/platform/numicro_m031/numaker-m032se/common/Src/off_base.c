#include "off_base.h"
#include "low_water.h"
#include "remote_counter.h"
#include "dev.h"
#include "metrics.h"
#include "smg.h"
#include "heating.h"

bool gbOffBase_TempCompareInKw=false;
uint32_t OffBaseTicks=0;
bool gbOffBase=false;
uint16_t OffBaseClear_SolidDispTemp=0;
bool gbOffBaseClear_SolidDispTemp=false;

uint16_t OffBase_TempNowBkp=0;

static bool NtcOpen()
{
	if(TempNow_Celsius==0xff)
		return true;
	return false;
}	
void OffBaseTicksClear()	//
{
	OffBaseTicks=0;
}

void OffBaseHandle()
{
	static bool b_off_base=false;
	static bool b_LowWaterIsTrue_BeforeOffBase=false;
	
	if(NtcOpen())
	{
		if(!b_off_base)
		{
			OffBaseTicks=0;
			gbOffBase_TempCompareInKw=true;
			gbOffBase=true;
			RemoteCounterClear();
			if(gbPower)
				Smg_ReloadOffBaseDispTicks(true);
			if(gbLowWater)
				b_LowWaterIsTrue_BeforeOffBase=true;
		}
		
		if(OffBaseTicks>30000)
		{
			b_LowWaterIsTrue_BeforeOffBase=false;
			if(DevPowerOff())
				Metrics_SetkettleEndMethod(eMetrics_kettleEndMethod_KettleRemoved);
		}
		
		b_off_base=true;
		gbOffBaseClear_SolidDispTemp=false;
	}
	else
	{
		if(b_LowWaterIsTrue_BeforeOffBase)
		{
			b_LowWaterIsTrue_BeforeOffBase=false;
			if(DevPowerOff())
				Metrics_SetkettleEndMethod(eMetrics_kettleEndMethod_LowWater);
		}
		
		if(b_off_base)
		{
			b_off_base=false;
			gbOffBaseClear_SolidDispTemp=true;
			OffBaseTicks=0;
		}
		
		if(gbOffBaseClear_SolidDispTemp && OffBaseTicks>=1000)
		{
			gbOffBaseClear_SolidDispTemp=false;
			gbOffBase=false;
			Smg_ReloadOffBaseDispTicks(false);
		}
		
		if(gbOffBase_TempCompareInKw && OffBaseTicks>=4000)
		{
			gbOffBase_TempCompareInKw=false;
			if(TempNow_Celsius<OffBase_TempNowBkp && (OffBase_TempNowBkp-TempNow_Celsius)>=5)
			{
				if(DevPowerOff())
					Metrics_SetkettleEndMethod(eMetrics_kettleEndMethod_KettleRemoved);
			}
		}
	}
}

void OffBaseHandleForTmrInt()
{
	OffBaseTicks++;
	if(OffBaseClear_SolidDispTemp)
		OffBaseClear_SolidDispTemp--;
}





