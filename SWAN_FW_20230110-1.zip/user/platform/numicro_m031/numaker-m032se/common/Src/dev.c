#include "dev.h"
#include "top.h"
#include "keep_warm.h"
#include "heating.h"
#include "self_check.h"
#include "off_base.h"
#include "low_water.h"
#include "smg.h"
#include "metrics.h"


float C2F(float temp)
{
	return 32+temp*1.8;
}
float F2C(float temp)
{
	return (temp-32)/1.8;
}


eTempratureUnit_t gTempratureUnit=eTempratureUnit_Celsius;

void DevTempUnitX()
{
	if(gTempratureUnit==eTempratureUnit_Celsius && !(PreSet&1))
		PreSet-=1;
	else if(gTempratureUnit==eTempratureUnit_Fahrenheit && (PreSet&1))
		PreSet+=1;
	else
	{
		printf("%s wrong handle \r\n",__func__);
		return;
	}
	UpdateTempSet_CausePreSet(PreSet);		//这个函数内部会更新preset=tmp
	UpdateTempSet();
}


#ifdef NEW_APP_API
uint16_t gBoilCounts=DEFAULT_BOIL_100_DEGREE_COUNTS;
bool gbBoilTo100Degree_CountsReset=false;
void BoilCountsResetFlagClear()
{
	static uint16_t ticks=0;
	
	if(gbBoilTo100Degree_CountsReset)
	{
		if(++ticks>=5*100)
		{
			ticks=0;
			gbBoilTo100Degree_CountsReset=false;
		}
	}
	else
		ticks=0;
}
#ifdef TEST_DART_FUNC
void Inc_gBoilCounts()
{
	static uint16_t ticks=0;
	
	if(++ticks>=(100*30))
	{
		ticks=0;
		if(gBoilCounts>=5)
			gBoilCounts-=5;
		else
			gBoilCounts=0;
	}
}
#endif
#endif

uint16_t TempCompPercent=100;

void UpdateTempCompPercent()
{
	static uint32_t p_ticks=0;
	static uint32_t n_ticks=0;
	
	if(gbRelay)
	{
		n_ticks=0;
		if(++p_ticks>=TEMP_COMP_TIME)
		{
			p_ticks=0;
			TempCompPercent+=TEMP_COMP_PERCENT;
			if(TempCompPercent>150)
				TempCompPercent=150;
		}
	}
	else
	{
		p_ticks=0;
		if(++n_ticks>=TEMP_COMP_TIME)
		{
			n_ticks=0;
			if(TempCompPercent>TEMP_COMP_PERCENT)
				TempCompPercent-=TEMP_COMP_PERCENT;
			if(TempCompPercent<100)
				TempCompPercent=100;
		}
	}
}


const uint8_t PRE_SET_TEMP_CELSIUS_SET_TAB[]=
{
//	100,90,85,60,40,
	40,60,80,85,90,100,
};

//20221021 for customer test
bool gbCustomerTest=false;

//20221115 for version display
uint16_t gFmVerDisplay=0;

bool gbPresetWithBoil=false;
bool gbPresetWithoutBoil=false;

bool gbDisplay=true;

bool gbAckDsnRecived=false;

bool gbPower=false;
uint16_t TempSet_Celsius=DEFAULT_TEMP_CELSIUS_SET;
uint16_t TempSet_Fahrenheit=DEFAULT_TEMP_FAHRENHEIT_SET;

uint16_t TempNow_Celsius=0;
uint16_t TempNow_CelsiusApp=0;
uint16_t TempNowWithDot_Celsius=0;
uint16_t TempSet=0;

float gfTempNowFahrenheit=-1;
uint16_t gTempNowFahrenheit=0;

#if DEFAULT_PRE_SET==6
bool gbKeepWarmSwitch=false;
#else
bool gbKeepWarmSwitch=true;

#endif
uint16_t TempSetTicks=0;
bool gbSwan=false;

bool gbRelay=false;

uint16_t PreSet=DEFAULT_PRE_SET;
uint16_t TempSet_CelsiusBkp=DEFAULT_TEMP_CELSIUS_SET;
uint16_t PowerOnDispTempSetTicks=0;
uint16_t TurnOffDispDelayTicks=TURN_OFF_DISP_DELAY_TICKS;

static void CustomerTestHandle()
{
	static uint16_t ticks=0;
	
	if(gbCustomerTest)
	{
		if(!gbPower && ++ticks>=(100*60*10))
		{
			ticks=0;
			DevPowerOn();
			ReloadPreSetChangedTicks();
		}
	}
	else
		ticks=0;
}

bool DevPowerOff()
{
	if(gbPower)
	{
		gbPower=false;
		gbReadyStatus=false;
		gbKeepWarm=false;
		#if(!SWAN_SYNC_PRESET)
		gbSwan=false;
		#endif
		KeepWarmReloadKeepWarmTime();
		DevClrTempSetTicks();
		return true;
	}
	return false;
}
void DevPowerOn()
{
	if(!gbPower)
	{
		gbPower=true;
		KeepWarmReloadKeepWarmTime();
		DevClrTempSetTicks();
		gbLowWater=false;
		gbTemp100HeatDone=false;
		#if(!SWAN_SYNC_PRESET)
		gbSwan=true;
		#endif
//		PowerOnDispTempSetTicks=400;
	}
}

uint16_t PreSetChangedTicks=0;
bool gbPreSetConfirm=false;		//preset设置之后延时确认，开机状态下自动开始加热

void ClearPreSetConfirm()
{
//	gbPreSetConfirm=false;
	PreSetChangedTicks=0;
	gbDisplayTempSetSolid=false;
}
void ReloadPreSetChangedTicks()
{
	PreSetChangedTicks=PRESET_CHANGED_TICKS;
//	gbPreSetConfirm=false;	
	if(gbDisplayTempSetSolid)
		return;
	if(gbPower)
	{
		if(DevPowerOff())
			Metrics_SetkettleEndMethod(eMetrics_kettleEndMethod_manual);
		Smg_ReloadOffBaseDispTicks(false);
	}
	else if(TempNow_Celsius==0xff)//(gbOffBase)
		Smg_ReloadOffBaseDispTicks(true);
}
void UpdateTempSet1()
{
	#if(MANUAL)
	if(PreSet!=pre_set)
	{
		if(pre_set==PRE_SET_MAX)
		{
			TempSet_Celsius=TempSet_CelsiusBkp;
			UpdateTempSet();
		}
		else 
		{
			if(PreSet==PRE_SET_MAX)
				TempSet_CelsiusBkp=TempSet_Celsius;
			TempSet_Celsius=PRE_SET_TEMP_CELSIUS_SET_TAB[pre_set-1];
			UpdateTempSet();
		}
		PreSet=pre_set;
	}
	#else
	{
		if(!PreSet)
			return;
		
		#if PCB_US
		TempSet_Celsius=PRE_SET_TEMP_CELSIUS_SET_TAB[(PreSet-1)>>1];
		#else
		TempSet_Celsius=PRE_SET_TEMP_CELSIUS_SET_TAB[PreSet-1];
		#endif
		UpdateTempSet();
	}
	#endif
}

bool gbPreSetChanged=false;
void UpdateTempSet_CausePreSet(uint16_t pre_set)
{
	#if(MANUAL)
	if(PreSet!=pre_set)
	{
		if(pre_set==PRE_SET_MAX)
		{
			TempSet_Celsius=TempSet_CelsiusBkp;
			UpdateTempSet();
		}
		else 
		{
			if(PreSet==PRE_SET_MAX)
				TempSet_CelsiusBkp=TempSet_Celsius;
			TempSet_Celsius=PRE_SET_TEMP_CELSIUS_SET_TAB[pre_set-1];
			UpdateTempSet();
		}
		PreSet=pre_set;
	}
	#else
	if(PreSet!=pre_set)
	{
		if(!pre_set)
			return;
		#if PCB_US
		TempSet_Celsius=PRE_SET_TEMP_CELSIUS_SET_TAB[(pre_set-1)>>1];
		#else
		TempSet_Celsius=PRE_SET_TEMP_CELSIUS_SET_TAB[pre_set-1];
		#endif
		UpdateTempSet();
		PreSet=pre_set;
		ReloadPreSetChangedTicks();
	}
	#endif
}

void AppChangeTempSet()
{
//	DevClrTempSetTicks();
//	if(!gbPower || gbOffBase)
//		DevReloadTempSetTicks();
//	else
//		SmgTempSetSolidDispTicksReload_CauseApp();
	KeepWarmReloadKeepWarmTime();
//	if(TempSet_Celsius>TempNow_Celsius)
//		HeatingReheat();
}

void UpdateTempSet()
{
	TempSet=TempSet_Celsius;
	TempSet_Fahrenheit=(uint16_t)C2F(TempSet_Celsius);
}

void UpdateTempSet_CelsiusFromTempSet()
{
	if(TempSet<TEMP_CELSIUS_SET_MIN)
		TempSet=TEMP_CELSIUS_SET_MIN;
	if(TempSet>TEMP_CELSIUS_SET_MAX)
		TempSet=TEMP_CELSIUS_SET_MAX;
	TempSet_Celsius=TempSet;
}

void DevClrTempSetTicks()
{
	TempSetTicks=0;
}
bool DevReloadTempSetTicks()
{
	if(gbPower)
	{
		if(!TempSetTicks)
		{
			TempSetTicks=TEMP_SET_TICKS_POWER_ON;
			return true;
		}
		TempSetTicks=TEMP_SET_TICKS_POWER_ON;
		return false;
	}
	
	if(!TempSetTicks)
	{
		TempSetTicks=TEMP_SET_TICKS;
		return true;
	}
	TempSetTicks=TEMP_SET_TICKS;
	return false;
}
bool DevGetTempSetStatus()
{
	if(TempSetTicks)
		return true;
	return false;
}
bool DevGetTempSetFlashShow()
{
//	if(gbPower)
//		return true;
	if((TempSetTicks%1000)>=500)
		return true;
	return false;
}
bool DevGetTempSetShow()
{
	if(TempSetTicks)
		return true;
	return false;
}

static bool HeatingReheatCauseLocalKey()
{
	if(!gbPower || gbOffBase || gbLowWater)
		return false;
	
	if(TempSet_Celsius>TempNow_Celsius)
	{
		HeatingReheat();
		return true;
	}
	return false;
}


void DevTempSet_CelsiusPlus(eKeyStatus_t eKeyStatus)
{
	static uint16_t Ticks=0;
	
	if(eKeyStatus==eKeyStatus_Down)
	{
		Ticks=0;
		if(TempSet_Celsius<TEMP_CELSIUS_SET_MAX)
			TempSet_Celsius++;
	}
	else if(eKeyStatus==eKeyStatus_Long)
	{
		if(!Ticks)
		{
			if((TempSet_Celsius%5)==0)
				TempSet_Celsius+=5;
			else if(TempSet_Celsius<TEMP_CELSIUS_SET_MAX)
				TempSet_Celsius++;
			if(TempSet_Celsius>TEMP_CELSIUS_SET_MAX)
				TempSet_Celsius=TEMP_CELSIUS_SET_MAX;
		}
		if((TempSet_Celsius%5)==0)
		{
			if(++Ticks>=500)
				Ticks=0;
		}
		else
		{
			if(++Ticks>=200)
				Ticks=0;
		}
	}
	
	UpdateTempSet();
	KeepWarmReloadKeepWarmTime();
	HeatingReheatCauseLocalKey();
}
void DevTempSet_CelsiusMinus(eKeyStatus_t eKeyStatus)
{
	static uint16_t Ticks=0;
	
	if(eKeyStatus==eKeyStatus_Down)
	{
		Ticks=0;
		if(TempSet_Celsius>TEMP_CELSIUS_SET_MIN)
			TempSet_Celsius--;
	}
	else if(eKeyStatus==eKeyStatus_Long)
	{
		if(!Ticks)
		{
			if((TempSet_Celsius%5)==0)
				TempSet_Celsius-=5;
			else if(TempSet_Celsius>TEMP_CELSIUS_SET_MIN)
				TempSet_Celsius--;
			if(TempSet_Celsius<TEMP_CELSIUS_SET_MIN)
				TempSet_Celsius=TEMP_CELSIUS_SET_MIN;
		}
		if((TempSet_Celsius%5)==0)
		{
			if(++Ticks>=500)
				Ticks=0;
		}
		else
		{
			if(++Ticks>=200)
				Ticks=0;
		}
	}
	
	UpdateTempSet();
	KeepWarmReloadKeepWarmTime();
	HeatingReheatCauseLocalKey();
}












void DevHandleForTmrInt()
{
	CustomerTestHandle();
	
	if(gbPower)
	{
		TurnOffDispDelayTicks=TURN_OFF_DISP_DELAY_TICKS;
	}
	else if(TurnOffDispDelayTicks && !gbCustomerTest)
	{
		TurnOffDispDelayTicks--;
		if(!TurnOffDispDelayTicks)
		{
			gbDisplay=false;
		}
	}
	
	if(TempSetTicks)
		TempSetTicks--;
	
	if(PowerOnDispTempSetTicks)
		PowerOnDispTempSetTicks--;
	
	if(PreSetChangedTicks)
	{
		PreSetChangedTicks--;
		if(!PreSetChangedTicks)
		{
//			gbPreSetConfirm=true;
			if(gbDisplayTempSetSolid)
			{
				gbDisplayTempSetSolid=false;
				return;
			}
			if(gbOffBase)
				Smg_ReloadOffBaseDispTicks(true);
			else
			{
				DevPowerOn();
//				gbMetrics__kettle_start_time=true;
//				Metrics_KettleCycleCountAdd();
//				gbMetrics__kettle_start_method=true;
//				Metrics__kettle_start_method=eMetrics_KettleStartMethod_manual;
//				gbMetrics__kettle_target_temp=true;
			}
		}
	}
}

void DevHeaterRelay(bool on)
{
	
}



#define RELAY_ON	PB7=1
#define RELAY_OFF	PB7=0

void DevHandle()
{
	if(gbHeatRelay || gbKeepWarmRelay || gbSelfCheckRelayOn)
		gbRelay=true;
	else
		gbRelay=false;
	
	if(gbRelay)
		RELAY_ON;
	else
		RELAY_OFF;
}







