#ifndef _REMOTE_COUNTER_H_
#define _REMOTE_COUNTER_H_

#include <stdint.h>
#include "numicro_hal.h"
#include <stdbool.h>

extern bool gbRemoteComand;
extern uint16_t gRemoteCounter;
extern bool gbRemotePowerOn;


void RemoteCounterClear();
void RemoteCounterHandle();
void RemoteCounterHandleForTmrInt();


#endif



