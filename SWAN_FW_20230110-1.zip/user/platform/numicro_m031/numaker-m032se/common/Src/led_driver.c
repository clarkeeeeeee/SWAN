#include "led_driver.h"
#include "Cy_iic.h"
#include "top.h"
#include "dev.h"


uint8_t LedDriverRamBuf[LED_DRIVER_RAM_LEN]={0};

#define BRIGHTNESS_LEVEL_8		(0<<4)
#define BRIGHTNESS_LEVEL_1		(1<<4)
#define BRIGHTNESS_LEVEL_2		(2<<4)
#define BRIGHTNESS_LEVEL_3		(3<<4)
#define BRIGHTNESS_LEVEL_4		(4<<4)
#define BRIGHTNESS_LEVEL_5		(5<<4)
#define BRIGHTNESS_LEVEL_6		(6<<4)
#define BRIGHTNESS_LEVEL_7		(7<<4)

#define SHOW_ON					1

#if HW_VER>=4
#if EE_TEST
uint8_t LedDriverRam[10]={0x48,BRIGHTNESS_LEVEL_1|SHOW_ON,\
			0x6c,0xff,\
			0x68,0xff,\
			0x6a,0xff,\
			0x6e,0xff,\
};
#else
uint8_t LedDriverRam[10]={0x48,BRIGHTNESS_LEVEL_7|SHOW_ON,\
			0x6c,0xff,\
			0x68,0xff,\
			0x6a,0xff,\
			0x6e,0xff,\
};
#endif
static uint8_t DisplayDim[2]={0x48,BRIGHTNESS_LEVEL_4|SHOW_ON};
#else
uint8_t LedDriverRam[10]={0x48,0x09,\
			0x6a,0,\
			0x6c,0,\
			0x6e,0,\
			0x68,0,\
};
#endif

bool test_brightness()
{
	static uint16_t ticks=0;
	
	if(++ticks>20)
		ticks=0;
	
	if(ticks==10)
	{
		LedDriverRam[1]=BRIGHTNESS_LEVEL_8|SHOW_ON;
		return true;
	}
	if(ticks==20)
	{
		LedDriverRam[1]=BRIGHTNESS_LEVEL_7|SHOW_ON;
		return true;
	}
	return false;
}

bool LedDriverUpdateDisplay()
{
//	LedDriverRamBuf[0]=0xff;
//	LedDriverRamBuf[1]=0xff;
//	LedDriverRamBuf[2]=0xff;
	
	bool update=false;
	
//	update=test_brightness();
	
	if(LedDriverRam[3]!=LedDriverRamBuf[0])
	{
		LedDriverRam[3]=LedDriverRamBuf[0];
		iic_write_bytes(&LedDriverRam[2],2);
		update=true;
	}
	if(LedDriverRam[5]!=LedDriverRamBuf[1])
	{
		LedDriverRam[5]=LedDriverRamBuf[1];
		iic_write_bytes(&LedDriverRam[4],2);
		update=true;
	}
	if(LedDriverRam[7]!=LedDriverRamBuf[2])
	{
		LedDriverRam[7]=LedDriverRamBuf[2];
		iic_write_bytes(&LedDriverRam[6],2);
		update=true;
	}
	#if HW_VER>=4
	if(LedDriverRam[9]!=LedDriverRamBuf[3])
	{
		LedDriverRam[9]=LedDriverRamBuf[3];
		iic_write_bytes(&LedDriverRam[8],2);
		update=true;
	}
	#endif	
	if(update)
	{
		if(gbDisplay)
			iic_write_bytes(LedDriverRam,2);
		else
			iic_write_bytes(DisplayDim,2);
	}
	return true;
	
	
	LedDriverRam[3]=LedDriverRamBuf[0];
	LedDriverRam[5]=LedDriverRamBuf[1];
	LedDriverRam[7]=LedDriverRamBuf[2];
	
	
	iic_write_bytes(&LedDriverRam[2],2);
	iic_write_bytes(&LedDriverRam[4],2);
	iic_write_bytes(&LedDriverRam[6],2);
	iic_write_bytes(LedDriverRam,2);
	
//	iic_write_bytes(LedDriverRam,8);
	
	return true;
}













