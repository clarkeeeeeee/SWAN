#include "board.h"
#include "port.h"
#include "timer_process.h"

#include "Hub.h"
#include "smg.h"
#include "key.h"
#include "dev.h"
#include "self_check.h"
#include "led.h"
#include "off_base.h"
#include "low_water.h"
#include "heating.h"
#include "keep_warm.h"
#include "adc_ex.h"
#include "connect.h"
#include "data_save.h"
#include "remote_counter.h"
#include "metrics.h"
#include "led_driver.h"



static uint8_t TimerUsTicker;
static uint8_t TimerMsTicker;


void Timer_0_Init(void)
{
    /* Set timer frequency to 1000HZ */
    TIMER_Open(TIMER0, TIMER_PERIODIC_MODE, 1000); // 100000Hz = 0.00001s = 0.01ms = 10us

    /* Enable timer interrupt */
    TIMER_EnableInt(TIMER0);
    NVIC_EnableIRQ(TMR0_IRQn);

    /* Start Timer 0 */
    TIMER_Start(TIMER0);
}

void TMR0_IRQHandler(void)
{
    TimerUsTicker++;
    //printf("%d sec\n", sec++);

	if(TimerUsTicker == 200)
		TimerUsTicker=0;
	
//	SmgScan();
		
    /* clear timer interrupt flag */
    TIMER_ClearIntFlag(TIMER0);
}


void Timer_1_Init(void)
{
    /* Set timer frequency to 1000HZ */
    TIMER_Open(TIMER1, TIMER_PERIODIC_MODE, 1000); // 1000Hz  = 1ms

    /* Enable timer interrupt */
    TIMER_EnableInt(TIMER1);
    NVIC_EnableIRQ(TMR1_IRQn);
	
	NVIC_SetPriority(TMR1_IRQn,0);

    /* Start Timer 0 */
    TIMER_Start(TIMER1);
}

extern uint16_t AckDelay;

volatile uint16_t delay_test;
static void delay2(uint16_t xx)
{
	for(delay_test=0;delay_test<xx;delay_test++)
	;
}
void TMR1_IRQHandler(void)
{
	static uint8_t Task=0;
	static uint8_t Delay=0;
	
	switch(Task)
	{
		case 0:
			SmgHandle();
		break;
		case 1:
//			printf("\n\nLedDriverUpdateDisplay\n");
			if(++Delay>=10)
			{
				Delay=0;
				LedDriverUpdateDisplay();
			}
		break;
		case 2:
			AdcHandle();
			BuzzerHandle();
		break;
		case 3:
			KeyHandle();
		break;
		case 4:
			UpdateTempCompPercent();
		break;
		case 5:
			LedHandle();
			LedHandleForTmrInt();
		break;
		
		case 6:
			#ifdef NEW_APP_API
			BoilCountsResetFlagClear();
			#ifdef TEST_DART_FUNC
			Inc_gBoilCounts();
			#endif
			#endif
		break;
		case 8:
			DevHandleForTmrInt();
			HeatingHandleForTmrInt();
			SmgHandleForTmrInt();
			DataSave_HandleForTmrInt();
		break;
		case 9:
			LowWaterHandleForTmrInt();
			KeepWarmHandleForTmrInt();
			Conn_ForTmrInt();
		break;
		
		default:
		break;
	}
	
	if(++Task>=10)
		Task=0;
	
	
	
	
	
	if(AckDelay)
		AckDelay--;
	
	
//	SelfCheckHandleForTmrInt();
//	LedHandleForTmrInt();
//	OffBaseHandleForTmrInt();
//	AdcHandleForTmrInt();
//	LedHandle();
//	MetricsHandleForTmrInt();
	
    /* clear timer interrupt flag */
    TIMER_ClearIntFlag(TIMER1);
}

