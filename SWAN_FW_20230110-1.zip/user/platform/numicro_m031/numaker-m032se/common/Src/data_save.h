#ifndef _DATA_SAVE_H_
#define _DATA_SAVE_H_

#include <stdint.h>
#include "numicro_hal.h"
#include <stdbool.h>


void DataSave_Test();
void DataSave_HandleForTmrInt();
void DataSave_Read();
void DataSave_Scan(bool update);


#endif



