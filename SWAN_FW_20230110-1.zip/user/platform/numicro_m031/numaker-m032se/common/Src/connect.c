#include "connect.h"
#include "ack.h"
#include "top.h"
#include "dev.h"
#include "heating.h"
#include "keep_warm.h"
#include "low_water.h"
#include "metrics.h"
#include "off_base.h"


extern ACKLifecycleState_t ACK_LifecycleState;

extern void Alexa_InitiateFactoryReset(void);
extern void Alexa_InitiateUserGuidedSetup(void);
extern void Alexa_SendChangeReportDueToLocalControl(void);
extern void Alexa_SendChangeReport_BoilCounts();
uint32_t BeaconTicks=0;

uint32_t CurrentTemperature=0;

uint8_t CanUseApp=1;

bool gbModuleInSetupMode=false;

bool gbforceReport=false;

uint32_t AutoReportDelay=0;

uint32_t SetCurrentTemperatureToZero_CauseOffBase_DelayTicks=0;

#if PCB_US
extern uint16_t SmgTempratureNow;
#endif

static void UpdateCurrentTemperature()
{
	static bool off_base=false;
	static uint32_t current_temp_c;
	
	#if PCB_US
		#if APP_DISPLAY_REAL_TEMP
		CurrentTemperature=current_temp_c=SmgTempratureNow;
		#else
		CurrentTemperature=SmgTempratureNow;
		#endif
	#else
	if(TempNow_Celsius==0xff)
	{
		if(!off_base)
		{
			off_base=true;
			SetCurrentTemperatureToZero_CauseOffBase_DelayTicks=3*60*1000;
		}
		else if(!SetCurrentTemperatureToZero_CauseOffBase_DelayTicks)
		{
			CurrentTemperature=0;
		}
		else
		{
			CurrentTemperature=current_temp_c;
		}
		return;
	}

	SetCurrentTemperatureToZero_CauseOffBase_DelayTicks=0;
	off_base=false;
	
	#if APP_DISPLAY_REAL_TEMP
	CurrentTemperature=current_temp_c=TempNow_Celsius;
	#else
	if(KeepWarmRetStatus() || gbTemp100HeatDone)
		CurrentTemperature=current_temp_c=TempSet;
	else 
		CurrentTemperature=current_temp_c=TempNow_Celsius;
	#endif
	
	#endif
}


eDevStatus_t eDevStatus=eDevStatus_None;
static void UpdateStatus()
{
//	if(!gbPower)
//		Status=0;
	if(gbLowWater)
		eDevStatus=eDevStatus_LowWater;
//	else if(gbOffBase)
//		eDevStatus=eDevStatus_OffBase;
	else if(HeatintRetStatus())
		eDevStatus=eDevStatus_Heating;
//	else if(HeatintRetHeatingDone() || gbReadyStatus)
//		eDevStatus=eDevStatus_WaterReady;
	else if(KeepWarmRetStatus())
		eDevStatus=eDevStatus_KeepWarm;
	else
		eDevStatus=eDevStatus_Off;
}

#define AUTO_REPORT_DELAY		300
#define TEMP_REPORT_DELAY		500
bool gbTempSet101Report=false;
static uint16_t temp_report_delay=0;

#ifdef NEW_APP_API
static bool report_BoilCounts()
{
	static uint16_t boil_counts;
	static bool lock=false;
	
	if(boil_counts!=gBoilCounts)
	{
		lock=true;
		boil_counts=gBoilCounts;
	}
	if(lock && !AutoReportDelay)
	{
		AutoReportDelay=AUTO_REPORT_DELAY;
		temp_report_delay=TEMP_REPORT_DELAY;
		Alexa_SendChangeReport_BoilCounts();
		printf("%s Alexa_SendChangeReport_BoilCounts \r\n",__func__);
		lock=false;
	}
	return lock;
}
#endif



static void AutoReport(bool reload)
{
	static bool power=false;
	static uint32_t curr_temp;
	static eDevStatus_t status;
	static uint16_t temp_set;
	static uint16_t pre_set;
	static bool keep_warm_switch=false;
	static bool swan=false;
	
	#ifdef NEW_APP_API
	static bool boil_counts_reset;
	#endif
	
	#if PCB_US
	static eTempratureUnit_t temp_unit;
	#endif
	
	static bool report=false;
	
	
	if(ACK_LifecycleState!=ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
		return;
	
	
	
	UpdateCurrentTemperature();
	UpdateStatus();
	
	
	
	if(reload)
	{
		report=false;
		AutoReportDelay=AUTO_REPORT_DELAY;
		temp_report_delay=TEMP_REPORT_DELAY;
		goto AutoReport_Reload;
	}
	
	#ifdef NEW_APP_API
	if(!report)
	{
		if(report_BoilCounts())
		{
			Metrics_ReloadMetricsBusy();
			return;
		}
	}
	#endif
		
	if(report)
		Metrics_ReloadMetricsBusy();
	
	if(AutoReportDelay)
		return;
	
	if(gbforceReport)
	{
		gbforceReport=false;
		goto need_report;
	}
	
	if(power!=gbPower)
		goto need_report;
	if(curr_temp!=CurrentTemperature && temp_report_delay==0)
		goto need_report;
	if(status!=eDevStatus)
		goto need_report;
//	if(temp_set!=TempSet)
//		goto need_report;
	if(pre_set!=PreSet)
		goto need_report;
	if(keep_warm_switch!=gbKeepWarmSwitch)
		goto need_report;
	if(swan!=gbSwan)
		goto need_report;
	#ifdef NEW_APP_API
	if(boil_counts_reset!=gbBoilTo100Degree_CountsReset)
		goto need_report;
	#endif
	
	
	#if PCB_US
	if(temp_unit!=gTempratureUnit)
		goto need_report;
	#endif
	
	
	goto AutoReport_Ex;
	
	need_report:
	report=true;
	AutoReport_Reload:
	{
		power=gbPower;
		curr_temp=CurrentTemperature;
		status=eDevStatus;
		temp_set=TempSet;
		pre_set=PreSet;
		keep_warm_switch=gbKeepWarmSwitch;
		swan=gbSwan;
		#ifdef NEW_APP_API
		boil_counts_reset=gbBoilTo100Degree_CountsReset;
		#endif
		#if PCB_US
		temp_unit=gTempratureUnit;
		#endif
		return;
	}
	
	AutoReport_Ex:
	{
//		if(ACK_LifecycleState!=ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
//		{
//			if(!AutoReportDelay)
//				AutoReportDelay=AUTO_REPORT_DELAY;
//			return;
//		}
			
		if(report && !AutoReportDelay)
		{
			report=false;
			Alexa_SendChangeReportDueToLocalControl();
			AutoReportDelay=AUTO_REPORT_DELAY;
			temp_report_delay=TEMP_REPORT_DELAY;
			
			Metrics__K70_change_report++;
			printf("Metrics__K70_change_report-->%d\n",Metrics__K70_change_report);
		}
	}
}

void Conn_Handle()
{
	if(ACK_LifecycleState==ACK_LIFECYCLE_IN_SETUP_MODE)
		gbModuleInSetupMode=true;
	else
		gbModuleInSetupMode=false;
	
	AutoReport(false);
}

bool Conn_ModuleRegistered()
{
	if(ACK_LifecycleState==ACK_LIFECYCLE_CONNECTED_TO_ALEXA)// || ACK_LifecycleState==ACK_LIFECYCLE_NOT_CONNECTED_TO_ALEXA)
		return true;
	return false;
}
static void ClrBeaconTicks()
{
	BeaconTicks=0;
}

uint16_t StartFrsDelay=0;

void Conn_StartUgs()
{
	Alexa_InitiateUserGuidedSetup();
	ClrBeaconTicks();
}
void Conn_StartFrs()
{
	Alexa_InitiateFactoryReset();
	ClrBeaconTicks();
	StartFrsDelay=800;
}


void Conn_ForTmrInt()
{
	if(ACK_LifecycleState==ACK_LIFECYCLE_IN_SETUP_MODE)
	{
		if(++BeaconTicks>=ACK_LIFECYCLE_IN_SETUP_MODE_OT_TIME)
			gbModuleInSetupMode=false;
	}
	if(AutoReportDelay)
		AutoReportDelay--;
	if(temp_report_delay)
		temp_report_delay--;
//	if(StartFrsDelay)
//	{
//		StartFrsDelay--;
//		if(!StartFrsDelay)
//			Conn_StartUgs();
//	}
}








