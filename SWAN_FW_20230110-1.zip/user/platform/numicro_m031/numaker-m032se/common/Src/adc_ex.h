#ifndef _ADC_EX_H_
#define _ADC_EX_H_

#include "board.h"
#include "LedScan.h"

void AdcInit();
void AdcHandle();
void AdcHandleForTmrInt();
void AdcHandle_Key();
extern uint16_t KeyAdcRes;

#endif








