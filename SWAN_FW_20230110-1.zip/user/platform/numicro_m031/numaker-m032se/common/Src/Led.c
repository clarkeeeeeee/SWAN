#include "led.h"
#include "dev.h"
#include "self_check.h"
#include "ack.h"
#include "top.h"
#include "connect.h"

extern ACKLifecycleState_t ACK_LifecycleState;

#define LED_WIFI_SEARCH_TICKS		(5*60*100)
uint32_t Led_WifiSearchTicks=LED_WIFI_SEARCH_TICKS;

bool GetWifiSearchTicks()
{
	return (Led_WifiSearchTicks>0);
}
bool LedResetWifiSearchTicks()
{
//	if(!Led_WifiSearchTicks && gbWifiLost)
	{
		Led_WifiSearchTicks=LED_WIFI_SEARCH_TICKS;
		return true;
	}
//	return false;
}



eLedStatus_t eLedStatus=eLedStatus_Off;
uint16_t WifiLedTicks=0;

bool gbWifiLedStatus=false;

#define DEF_WIFI_RED_LED_ON		gbWifiLedStatus=1
#define DEF_WIFI_RED_LED_OFF	gbWifiLedStatus=0
//#define DEF_WIFI_BLUE_LED_ON	//PC0=1
//#define DEF_WIFI_BLUE_LED_OFF	//PC0=0

bool gbWifiLost=false;

void LedInit()
{
	DEF_WIFI_RED_LED_OFF;
}

static void WifiLed()
{
	static eLedStatus_t eLedStatus_bkp;
	static bool bAlexaConnected=false;
	
//	eLedStatus=eLedStatus_Off;
	if(ACK_LifecycleState==ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
//	if(ACK_LifecycleState==ACK_LIFECYCLE_IN_SETUP_MODE || ACK_LifecycleState==ACK_LIFECYCLE_NOT_CONNECTED_TO_ALEXA || ACK_LifecycleState==ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
		Led_WifiSearchTicks=LED_WIFI_SEARCH_TICKS;
	else
	{
		if(!Led_WifiSearchTicks)
		{
			eLedStatus=eLedStatus_Off;
			goto LedEx;
		}
	}
	
	
	if(gbKeyUgsEn)
	{
		eLedStatus=eLedStatus_RedBlinkingAt2Hz;
		gbWifiLost=false;
		bAlexaConnected=false;
		goto LedEx;
	}
	if(gbKeyFrsEn)
	{
		eLedStatus=eLedStatus_RedBlinkingAt2Hz;
		gbWifiLost=false;
		bAlexaConnected=false;
		goto LedEx;
	}
	
	if(ACK_LifecycleState==ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
	{
		eLedStatus=eLedStatus_RedOn;
		bAlexaConnected=true;
		gbWifiLost=false;
	}
	else if(ACK_LifecycleState==ACK_LIFECYCLE_IN_SETUP_MODE)
	{
		eLedStatus=eLedStatus_RedBlinkingAt2Hz;
		gbWifiLost=false;
		bAlexaConnected=false;
		goto LedEx;
	}
	else 
	{
		if(bAlexaConnected)
			gbWifiLost=true;
		bAlexaConnected=false;
		if(gbWifiLost)
			eLedStatus=eLedStatus_RedBlinkingAt1Hz;
		else 
			eLedStatus=eLedStatus_Off;
	}
	
//	if(ACK_LifecycleState==ACK_LIFECYCLE_NOT_CONNECTED_TO_ALEXA)
//		eLedStatus=eLedStatus_RedBlueBlinkingAt1Hz;
//	
//	else if(ACK_LifecycleState==ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
//		eLedStatus=eLedStatus_BlueOn;
//	
//	else if(ACK_LifecycleState==ACK_LIFECYCLE_CONNECTED_TO_ALEXA)
//		eLedStatus=eLedStatus_RedOn;
//	
//	else if(ACK_LifecycleState==ACK_LIFECYCLE_IN_SETUP_MODE && ACK_LifecycleSubStateInfo.InSetupMode.IsUserGuidedSetupActive)
//		eLedStatus=eLedStatus_RedBlinkingAt2Hz;
//	
//	else //if(ACK_LifecycleState==ACK_LIFECYCLE_IN_SETUP_MODE)
//		eLedStatus=eLedStatus_RedBlinkingAt1Hz;
	
	LedEx:	
	if(eLedStatus_bkp!=eLedStatus)
	{
		eLedStatus_bkp=eLedStatus;
//		printf("\n\n eLedStatus = %d\n", eLedStatus_bkp);
	}
	switch(eLedStatus)
	{
		case eLedStatus_Off:
			DEF_WIFI_RED_LED_OFF;
		break;
		
		
		
		case eLedStatus_RedOn:
		case eLedStatus_RedBreath:
			DEF_WIFI_RED_LED_ON;
		break;
		
		case eLedStatus_BlueOn:
			DEF_WIFI_RED_LED_OFF;
		break;
		
		case eLedStatus_RedBlinkingAt1Hz:
			if(WifiLedTicks<50)
			{
				DEF_WIFI_RED_LED_ON;
			}
			else
			{
				DEF_WIFI_RED_LED_OFF;
			}
			if(WifiLedTicks>=100)
				WifiLedTicks=0;
		break;
			
		case eLedStatus_RedBlinkingAt2Hz:
			if(WifiLedTicks<25 || (WifiLedTicks>=50 && WifiLedTicks<75))
			{
				DEF_WIFI_RED_LED_ON;
			}
			else
			{
				DEF_WIFI_RED_LED_OFF;
			}
			if(WifiLedTicks>=100)
				WifiLedTicks=0;
		break;
			
		case eLedStatus_RedBlueBlinkingAt1Hz:
			if(WifiLedTicks<50)
			{
				DEF_WIFI_RED_LED_ON;
			}
			else
			{
				DEF_WIFI_RED_LED_OFF;
			}
			if(WifiLedTicks>=100)
				WifiLedTicks=0;
		break;
		
		default:
		break;
	}
}

void LedHandleForTmrInt()
{
	WifiLedTicks++;
	if(Led_WifiSearchTicks)
	{
		Led_WifiSearchTicks--;
		if(!Led_WifiSearchTicks)
		{
			gbKeyUgsEn=false;
			gbKeyFrsEn=false;
		}
	}
}




void LedHandle()
{
//	if(SelfCheckRetStatus() || gbSelfCheckKeysEn)
//	{
//		LedSelfCheck();
//		goto LedHandle_End;
//	}
	
//	if(LedFullTime)
//	{
//		DEF_WIFI_RED_LED_ON;
//		DEF_WIFI_BLUE_LED_ON;
//		goto LedHandle_End;
//	}
	
	#ifdef LED_IS_RELAY_STATUS
	if(gbRelay)
	{
		sLedRoutine.LedLeftWifiRedLedOn();
		sLedRoutine.LedRightWifiRedLedOn();
	}
	else
	{
		sLedRoutine.LedLeftWifiLedOff();
		sLedRoutine.LedRightWifiLedOff();
	}
	return;
	#endif
	
	WifiLed();
LedHandle_End:	
	;
}





