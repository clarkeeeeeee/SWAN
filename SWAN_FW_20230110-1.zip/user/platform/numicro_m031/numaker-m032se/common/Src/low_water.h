#ifndef _LOW_WATER_H_
#define _LOW_WATER_H_

#include <stdint.h>
#include "numicro_hal.h"
#include <stdbool.h>

extern bool gbLowWater;
extern bool gbRelayStatus_KeepWarmLowWaterHandle;
extern bool gbClear_bCompareTempBkp;
extern uint16_t TempBkp_KeepWarmLowWaterHandle;
extern bool gbTempBkp_KeepWarmLowWaterHandleUpdated;
extern uint32_t KeepWarmLowWaterHandleValidTime;


void LowWaterRemainTicksReload();
void LowWaterHandle();
void LowWaterHandleForTmrInt();
bool LowWaterRetStatus();

#endif



