#include "time.h"

sTime_t sTime;

void TimeUpdateCauseInternet(int16_t hh,int16_t mm,int16_t ss)
{
	sTime.hh=hh;
	sTime.mm=mm;
	sTime.ss=ss;
	sTime.valid=1;
	
//	printf("\n\n TimeUpdateCauseInternet  %d %d %d \n", sTime.hh,sTime.mm,sTime.ss);
}







