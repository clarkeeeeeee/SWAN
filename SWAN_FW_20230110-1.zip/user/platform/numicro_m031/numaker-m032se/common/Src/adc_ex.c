#include "adc_ex.h"
#include "top.h"
#include "dev.h"
#include "off_base.h"
#include "heating.h"

extern uint32_t ADC_temperature;

uint16_t AdcRes=0;

#ifdef NTC_10K
const uint16_t NTC_ADC_TAB[]={
3137	,
3099	,
3061	,
3021	,
2981	,
2940	,
2899	,
2857	,
2814	,
2771	,
2727	,
2683	,
2639	,
2594	,
2549	,
2504	,
2458	,
2413	,
2367	,
2321	,
2275	,
2229	,
2184	,
2138	,
2093	,
2048	,
2003	,
1958	,
1914	,
1870	,
1826	,
1783	,
1741	,
1699	,
1657	,
1616	,
1576	,
1536	,
1497	,
1459	,
1421	,
1384	,
1347	,
1312	,
1277	,
1242	,
1209	,
1176	,
1143	,
1112	,
1081	,
1051	,
1022	,
993	,
965	,
938	,
911	,
885	,
860	,
836	,
812	,
788	,
766	,
744	,
722	,
702	,
681	,
662	,
643	,
624	,
606	,
588	,
571	,
555	,
539	,
523	,
508	,
494	,
480	,
466	,
452	,
439	,
427	,
415	,
403	,
391	,
380	,
369	,
359	,
349	,
339	,
330	,
320	,
311	,
303	,
294	,
286	,
278	,
271	,
263	,
256	,
249	,
242	,
235	,
229	,
223	,
217	,
211	,
205	,
200	,
195	,
189	,
184	,
180	,
175	,
170	,
166	,
162	,
157	,
153	,
};
#else
const uint16_t NTC_ADC_TAB[]={
3973	,
3967	,
3961	,
3954	,
3948	,
3941	,
3933	,
3925	,
3917	,
3909	,
3900	,
3891	,
3882	,
3872	,
3862	,
3851	,
3840	,
3829	,
3817	,
3805	,
3793	,
3780	,
3766	,
3752	,
3738	,
3723	,
3708	,
3692	,
3676	,
3659	,
3642	,
3625	,
3607	,
3588	,
3569	,
3550	,
3530	,
3509	,
3488	,
3467	,
3445	,
3422	,
3399	,
3376	,
3352	,
3328	,
3303	,
3278	,
3252	,
3226	,
3199	,
3172	,
3145	,
3117	,
3089	,
3060	,
3031	,
3002	,
2972	,
2942	,
2912	,
2881	,
2850	,
2819	,
2788	,
2756	,
2724	,
2692	,
2660	,
2627	,
2594	,
2562	,
2529	,
2496	,
2462	,
2429	,
2396	,
2363	,
2329	,
2296	,
2263	,
2229	,
2196	,
2163	,
2130	,
2096	,
2063	,
2030	,
1997	,
1964	,
1931	,
1899	,
1867	,
1835	,
1804	,
1772	,
1741	,
1711	,
1680	,
1650	,
1621	,
1591	,
1562	,
1534	,
1506	,
1478	,
1450	,
1423	,
1397	,
1370	,
1344	,
1319	,
1294	,
1269	,
1245	,
1221	,
1197	,
1174	,
1151	,
1128	,

};
#endif

typedef enum
{
	ADC_CHN0=(1<<0),
	ADC_CHN1=(1<<1),
	ADC_CHN2=(1<<2),
	ADC_CHN3=(1<<3),
	ADC_CHN4=(1<<4),
	ADC_CHN5=(1<<5),
	ADC_CHN6=(1<<6),
	ADC_CHN7=(1<<7),
	ADC_CHN8=(1<<8),
	ADC_CHN9=(1<<9),
	ADC_CHN10=(1<<10),
	ADC_CHN11=(1<<11),
	ADC_CHN12=(1<<12),
	ADC_CHN13=(1<<13),
	ADC_CHN14=(1<<14),
	ADC_CHN15=(1<<15)
}eADC_CHN_DEF;

#define ADC_CVT_TOUNTS		100

volatile uint32_t g_u32AdcIntFlag;

u16 TempCvtDelay=1000;

u16 TempCelsius=0;
u16 TempFahr=0;


bool Round45(u16 ctx)
{
	if((ctx%10)>=5)
		return true;
	return false;
}

u16 CelsiusToFahr(u16 c,bool Neg)
{
	u16 buf;

	if(Neg)
	{
		buf=c;
		buf*=18;
		if(buf>=3200)
			buf=3200;
		buf=3200-buf;

		buf/=10;
		
		if(Round45(buf))
			return (buf/10+1);
		return (buf/10);
	}

	buf=c;
	buf*=18;
	buf=3200+buf;

	buf/=10;
	
	if(Round45(buf))
		return (buf/10+1);
	return (buf/10);
}

void ADC_IRQHandler(void)
{
    g_u32AdcIntFlag = 1;
    ADC_CLR_INT_FLAG(ADC, ADC_ADF_INT); /* Clear the A/D interrupt flag */
}


void AdcInit()
{
	/* Enable ADC module clock */
    CLK_EnableModuleClock(ADC_MODULE);

    /* ADC clock source is PCLK1, set divider to 1 */
    CLK_SetModuleClock(ADC_MODULE, CLK_CLKSEL2_ADCSEL_PCLK1, CLK_CLKDIV0_ADC(20));

	
	/* Set PB.2 - PB.3 to input mode */
	GPIO_SetMode(PB, BIT4, GPIO_MODE_INPUT);
	GPIO_SetMode(PB, BIT5, GPIO_MODE_INPUT);
	/* Configure the PB.2 - PB.3 ADC analog input pins.  */
	SYS->GPB_MFPL = (SYS->GPB_MFPL & ~(SYS_GPB_MFPL_PB4MFP_Msk|SYS_GPB_MFPL_PB5MFP_Msk)) |
					(SYS_GPB_MFPL_PB5MFP_ADC0_CH5|SYS_GPB_MFPL_PB4MFP_ADC0_CH4);
	/* Disable the PB.2 - PB.3 digital input path to avoid the leakage current. */
	GPIO_DISABLE_DIGITAL_PATH(PB, BIT4);
	GPIO_DISABLE_DIGITAL_PATH(PB, BIT5);
	/* Enable ADC converter */
    ADC_POWER_ON(ADC);

	/* Set input mode as single-end, Single mode, and select channel 2 */
    ADC_Open(ADC, ADC_ADCR_DIFFEN_SINGLE_END, ADC_ADCR_ADMD_SINGLE, BIT5);
	ADC_Open(ADC, ADC_ADCR_DIFFEN_SINGLE_END, ADC_ADCR_ADMD_SINGLE, BIT4);

    /* Clear the A/D interrupt flag for safe */
//    ADC_CLR_INT_FLAG(ADC, ADC_ADF_INT);

    /* Enable the sample module interrupt */
//    ADC_ENABLE_INT(ADC, ADC_ADF_INT);  /* Enable sample module A/D interrupt. */
//    NVIC_EnableIRQ(ADC_IRQn);
}

u16 AdcGetRes(u8 chn,uint8_t counts)
{
	u8 i;
	u32 sum=0;

	if(chn>15)
		return 0;

	/* Set input mode as single-end, Single mode, and select channel 2 */
    ADC_Open(ADC, ADC_ADCR_DIFFEN_SINGLE_END, ADC_ADCR_ADMD_SINGLE, (1<<chn));

	for(i=0;i<counts;i++)
	{
		/* Reset the ADC interrupt indicator and trigger sample module 0 to start A/D conversion */
        g_u32AdcIntFlag = 0;
        ADC_START_CONV(ADC);

        /* Wait ADC interrupt (g_u32AdcIntFlag will be set at IRQ_Handler function) */
//        while(g_u32AdcIntFlag == 0);
		while(!ADC_IS_DATA_VALID(ADC,chn));
        /* Disable the sample module interrupt */
        //ADC_DISABLE_INT(ADC, ADC_ADF_INT);

        /* Get the conversion result of ADC channel 2 */
		sum += ADC_GET_CONVERSION_DATA(ADC, chn);
		
		//printf("AdcGetRes chn=%d  res=%d",chn,sum/counts);
	}

	return sum/counts;
}

static u8 GetTemp(u16 adc)
{
	u8 i=0;
	
	static uint8_t print_adc=0;
	
	if(++print_adc>=10)
	{
		print_adc=0;
//		printf("  adc value now is ............... [%lu]\n", (uint32_t)adc);
	}
	
	if(adc>4000)
		return 0xff;
	
	if(adc>=NTC_ADC_TAB[0])
		return 0;
	
	for(i=0;i<sizeof(NTC_ADC_TAB)/2-1;i++)
	{
		if(adc<=NTC_ADC_TAB[i] && adc>NTC_ADC_TAB[i+1])
			break;
	}
	
	return i;
}
static u16 GetTempWithDot(u16 adc)
{
	u8 i=0;
	u32 diff;
	u32 diff2;
	u16 ret;
	
	static uint8_t print_adc=0;
	
	if(++print_adc>=10)
	{
		print_adc=0;
		//printf("  adc value now is ............... [%lu]\n", (uint32_t)adc);
	}
	
	if(adc>4000)
		return 0xffff;
	
	if(adc>=NTC_ADC_TAB[0])
		return 0;
	
	for(i=0;i<sizeof(NTC_ADC_TAB)-1;i++)
	{
		if(adc<=NTC_ADC_TAB[i] && adc>NTC_ADC_TAB[i+1])
		{
			ret=i*10;
			diff=NTC_ADC_TAB[i]-NTC_ADC_TAB[i+1];
			diff2=NTC_ADC_TAB[i]-adc;
			diff2*=10;
			ret+=(diff2/diff);
			break;
		}
	}
	
	return ret;
}


#define TEMP_SMOOTH		100
static float f_tmp;
static void TempratureSmooth2(u16 tmp)
{
	static u8 up=0;
	static u8 down=0;
	
	static u32 up_sum=0;
	static u32 down_sum=0;
	
	static bool ntc_open=false;
	
	uint32_t u32_tmp;
	
	if(tmp==0xffff)
	{
		up=down=0;
		up_sum=down_sum=0;
		ntc_open=true;
		goto update_TempNowWithDot_Celsius;
	}
	
	if(ntc_open)
	{
		up_sum+=tmp;
		if(++up>=10)
		{
			up=0;
			up_sum/=10;
			tmp=up_sum;
			up_sum=0;
			ntc_open=false;
			goto update_TempNowWithDot_Celsius;
		}
		return;
	}
	
	if(tmp>=TempNowWithDot_Celsius)
	{
		down=0;
		down_sum=0;
		
		up_sum+=tmp;
		if(++up>=TEMP_SMOOTH)
		{
			up=0;
			up_sum/=TEMP_SMOOTH;
			tmp=up_sum;
			up_sum=0;
			goto update_TempNowWithDot_Celsius;
		}
		return;
	}
	else
	{
		up=0;
		up_sum=0;
		
		down_sum+=tmp;
		if(++down>=TEMP_SMOOTH)
		{
			down=0;
			down_sum/=TEMP_SMOOTH;
			tmp=down_sum;
			down_sum=0;
			goto update_TempNowWithDot_Celsius;
		}
		return;
	}	
	
	update_TempNowWithDot_Celsius:
	
	if(tmp==0xffff)
	{
		//printf("TempratureSmooth2 -->> off base\n");
		TempNowWithDot_Celsius=tmp;
		TempNow_Celsius=0xff;
		gfTempNowFahrenheit=-1;
		gTempNowFahrenheit=0xff;
		return;
	}
//	TempNowWithDot_Celsius=(TempNowWithDot_Celsius*2+tmp)/3;
	
	u32_tmp=tmp;
	u32_tmp*=TempCompPercent;
	u32_tmp/=100;
	
	
	if(u32_tmp<=650)
	{
		u32_tmp*=TEMPRATURE_FACTOR0;
	}
	else if(u32_tmp<=920)
	{
		u32_tmp*=TEMPRATURE_FACTOR1;
	}
	else
	{
		u32_tmp*=TEMPRATURE_FACTOR2;
	}
	u32_tmp/=100;
	
	if(u32_tmp>1000)
		u32_tmp=1000;
	
	if(TempNowWithDot_Celsius==0xffff)
		TempNowWithDot_Celsius=0;
	if(TempNowWithDot_Celsius==0)
		TempNowWithDot_Celsius=u32_tmp;
	else
	{
		u32 u32_tmp2=u32_tmp*9+TempNowWithDot_Celsius*1;
		u32_tmp2/=10;
//		f_tmp=u32_tmp*0.2+TempNowWithDot_Celsius*0.8;
		TempNowWithDot_Celsius=(uint16_t)u32_tmp2;
	}
	
	TempNow_Celsius=TempNowWithDot_Celsius/10;
	
	
	float f_tmp=TempNowWithDot_Celsius;
	f_tmp/=10;
	gfTempNowFahrenheit=C2F(f_tmp);
	gTempNowFahrenheit=(uint16_t)gfTempNowFahrenheit;
	
	
	if(TempNow_Celsius<90)
		gbTemp100HeatDone=false;
	
	if(!gbOffBase_TempCompareInKw)
		OffBase_TempNowBkp=TempNow_Celsius;
}
void AdcHandle()
{
	TempratureSmooth2(GetTempWithDot(AdcRes=AdcGetRes(5,10)));
}

uint16_t KeyAdcRes=0xffff;

void AdcHandle_Key()
{
	static u16 ticks=0;
	
	KeyAdcRes=AdcRes=AdcGetRes(4,10);
	
	if(++ticks>=100)
	{
		ticks=0;
//		printf("AdcHandle_Key -->> KeyAdcRes= %d \n",KeyAdcRes);
	}
}

void AdcHandleForTmrInt()
{
	if(TempCvtDelay)
		TempCvtDelay--;
}


//adc end
















