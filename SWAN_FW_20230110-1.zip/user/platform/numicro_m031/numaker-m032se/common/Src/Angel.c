#include "Angel.h"

//#define SM_DEBUG

#define PHASE_A_ON			PA4=1
#define PHASE_A_OFF			PA4=0
#define PHASE_B_ON			PA3=1
#define PHASE_B_OFF			PA3=0
#define PHASE_C_ON			PA2=1
#define PHASE_C_OFF			PA2=0
#define PHASE_D_ON			PA1=1
#define PHASE_D_OFF			PA1=0

#define KEY_NUM		8

#ifdef SM_DEBUG
#define STEPS_FULL_CIRCLE		3600//16304		//需要被16整除，否则可能导致设置角度不准
#else
#define STEPS_FULL_CIRCLE		16928
#endif

#define SM_SPPED_PRA				2
#define CUT_45			4

#define STEPS_HALF_CIRCLE		(STEPS_FULL_CIRCLE/2)
#define SM_KEY_POS_PRA			(STEPS_FULL_CIRCLE/KEY_NUM/CUT_45)			//�ȷ�Ϊ�����İ�����Ŀ�����ڸ��µ���SmKeyPosTab
#define SM_KEY_POS_MAX			(KEY_NUM*CUT_45)	
#define SM_LED_POS_PRA			(STEPS_FULL_CIRCLE/KEY_NUM)	
#define STEPS_UNIT_PER_ANGEL	(STEPS_FULL_CIRCLE/360)
	
uint16_t SmStepPosNow=0;				//��ǰλ��
uint16_t SmStepPosObjStart=0;		//��ʼĿ��λ��
uint16_t SmStepPosObjStop=0;		//����Ŀ��λ��

uint16_t SmStepPosIdxNow=0;
uint16_t SmStepPosIdxObjStart=0;
uint16_t SmStepPosIdxObjStop=0;

uint16_t SmClockwise=0;				//����
uint16_t SmRun=0;							//�����
uint16_t SmEnable=0;					//�������

uint8_t SmSpeedPra=0;
uint8_t SmPhase=0;

uint8_t	SmInitDone=0;

uint8_t SmKeyPosTab[KEY_NUM]={0};		//0-(2*KEY_NUM-1)
uint16_t AngelLedPosTab[KEY_NUM]={0};

const uint8_t PHASE_TAB[8]={1,3,2,6,4,12,8,9};

bool bLocalAllAngelKeyEn=false;
bool bSmClockwise_LocalAllAngelKeyEn=false;

bool AngelGetIf_SmStepPosObjStart_Equal_SmStepPosObjStop()
{
	return (bool)(SmStepPosObjStart==SmStepPosObjStop);
}

uint16_t AngelGetSmFullSteps()
{
	return STEPS_FULL_CIRCLE;
}

void AngelUpdateHubAngelLedSmPos()
{
	u16 start,stop;
	
	if(SmStepPosObjStart==SmStepPosObjStop)
	{
		if(SmStepPosObjStart>=SM_LED_POS_PRA)
		{
			start=SmStepPosObjStart-SM_LED_POS_PRA+1;
			stop=SmStepPosObjStart;
		}
		else
		{
			start=STEPS_FULL_CIRCLE+SmStepPosObjStart-SM_LED_POS_PRA+1;
			stop=SmStepPosObjStart;
		}
		
		HubAngelLedStartSmPos=start;
		HubAngelLedStopSmPos=stop;
	}
	else //if(SmStepPosObjStart>SmStepPosObjStop)
	{
		start=SmStepPosObjStart;
		stop=SmStepPosObjStop;
		
		HubAngelLedStartSmPos=start;
		HubAngelLedStopSmPos=stop;
	}
}

uint16_t AngelGetSmOn()
{
	return SmRun;
}

bool AngelCkSmArriveStopPos()
{
	if(SmStepPosNow==SmStepPosObjStop)
		return true;
	else
		return false;
}

uint8_t AngleSmInitDone()
{
	return SmInitDone;
}

void SmResetPra()
{
	SmStepPosObjStart=SmStepPosObjStop=SmStepPosNow;
	SmEnable=0;
	bLocalAllAngelKeyEn=false;
	
}


uint16_t AngleGetSmStepPosObjStart()
{
	return SmStepPosObjStart;
}

uint16_t AngleGetSmStepPosObjStop()
{
	return SmStepPosObjStop;
}

uint8_t AngleGetAngleKeyNum()
{
	return KEY_NUM;
}

void UpdateSmKeyPosTab(uint16_t step_pos_now)		//ʵʱ���°�����Ӧλ�ýڵ����
{
		uint8_t i=0;
		uint16_t temp;
		uint16_t temp2;
		
		if(step_pos_now%SM_KEY_POS_PRA)
			temp=step_pos_now/SM_KEY_POS_PRA+1;
		else
			temp=step_pos_now/SM_KEY_POS_PRA;
		
		for(i=0;i<KEY_NUM;i++)
		{
			temp2=temp+i*CUT_45;
			
			if(temp2>=SM_KEY_POS_MAX)
				temp2-=SM_KEY_POS_MAX;
			SmKeyPosTab[i]=temp2;
		}
		
		SmStepPosIdxNow=temp;
		
		
//update led pos tab
		for(i=0;i<KEY_NUM;i++)
		{
			temp=SM_LED_POS_PRA*i;
			temp+=SmStepPosNow;
			if(temp>=STEPS_FULL_CIRCLE)
				temp-=STEPS_FULL_CIRCLE;
			AngelLedPosTab[i]=temp;
		}
}



uint8_t TestVal1=0;
uint8_t TestVal2=0;
#define UNVALID		0XFF

bool bForceUse_bHubWindDirection180_SmDirClockwise=false;

void CalcSmStepPosObj_BaseRodateValue(u8 rotate)
{
	bHubRotate_OneCircle=0;
	
	if(rotate>1)
	{
		gRotateSwitch=1;
		
		SmStepPosIdxObjStart=SmStepPosIdxObjStop=SmStepPosIdxNow;
		
		if(rotate==2)
		{
			SmStepPosObjStart=SmStepPosNow;
			
			if(SmStepPosNow)
				SmStepPosObjStop=SmStepPosNow-1;
			else
				SmStepPosObjStop=STEPS_FULL_CIRCLE-1;
		}
		else
		{
			SmStepPosObjStop=SmStepPosNow;
			
			SmStepPosObjStart=SmStepPosNow+1;
			if(SmStepPosObjStart>=STEPS_FULL_CIRCLE)
				SmStepPosObjStart=0;
		}
		
		AngelUpdateHubAngelLedSmPos();
	}
	else
		gRotateSwitch=0;
}

void CalcSmStepPosObj(uint16_t sm_key_msk)		//��֤�����ԣ��磺0x03,0x81,0xc0	��Ч�����磺0x09
{
		uint8_t start_idx=UNVALID;
		uint8_t stop_idx=UNVALID;
		uint8_t i=0;
		uint16_t pos_obj_start;
		uint16_t pos_obj_stop;
		uint8_t key_msk_valid=0;		//������Чλ����Ŀ
		uint8_t tmp;
	
		bForceUse_bHubWindDirection180_SmDirClockwise=false;
		bHubRotate_OneCircle=0;
	
		if(!sm_key_msk)
			return;
		
		gRotate=1;
		bHubRotate_OneCircle=false;
		gRotateSwitch=0;
				
		for(i=0;i<KEY_NUM;i++)
		{
			if(sm_key_msk&(1<<i))
			{
					key_msk_valid+=1;
			}
		}
		
		for(i=0;i<KEY_NUM;i++)
		{
			if(sm_key_msk&(1<<i))
			{
				start_idx=i;
				break;
			}
		}
		i++;
		
		if(key_msk_valid<=1)
			gOscAngel=0;
		else if(key_msk_valid==2)
			gOscAngel=90;
		else if(key_msk_valid==3)
			gOscAngel=135;
		else if(key_msk_valid==4)
			gOscAngel=180;
		else if(key_msk_valid==5)
			gOscAngel=225;
		else if(key_msk_valid==6)
			gOscAngel=270;
		else if(key_msk_valid==7)
			gOscAngel=315;
		else if(key_msk_valid==8)
			gOscAngel=360;
		
		switch(key_msk_valid)
		{
				case 1:
					stop_idx=start_idx;
					bLocalAllAngelKeyEn=false;
				break;
				
				case KEY_NUM:
					if(HubGetFirstValidAngelSetKeyIdx()==HubGetLastAngelSetKeyIdx())
					{
						bLocalAllAngelKeyEn=true;
						
						stop_idx=start_idx=HubGetLastAngelSetKeyIdx();
						tmp=HubGetSecondLastAngelSetKeyIdx();
						if(stop_idx==(KEY_NUM-1))
						{
							if(!tmp)
								gRotate=3;
							else
								gRotate=2;
						}
						else if(stop_idx)
						{
							if(tmp<stop_idx)
								gRotate=2;
							else
								gRotate=3;
						}
						else
						{
							if(tmp==1)
								gRotate=3;
							else
								gRotate=2;
						}
						
						break;
					}
					
					stop_idx=HubGetLastAngelSetKeyIdx();
					start_idx=stop_idx+1;
					if(start_idx>=KEY_NUM)
						start_idx=0;
					
					gRotateSwitch=1;
					
//					tmp=HubGetSecondLastAngelSetKeyIdx();
//					if(stop_idx==(KEY_NUM-1))
//					{
//						if(!tmp)
//							bSmClockwise_LocalAllAngelKeyEn=false;
//						else
//							bSmClockwise_LocalAllAngelKeyEn=true;
//					}
//					else if(stop_idx)
//					{
//						if(tmp<stop_idx)
//							bSmClockwise_LocalAllAngelKeyEn=true;
//						else
//							bSmClockwise_LocalAllAngelKeyEn=false;
//					}
//					else
//					{
//						if(tmp==1)
//							bSmClockwise_LocalAllAngelKeyEn=false;
//						else
//							bSmClockwise_LocalAllAngelKeyEn=true;
//					}
				break;
				
				default:
					bLocalAllAngelKeyEn=false;
				
					gRotateSwitch=1;
			
					for(;i<start_idx+key_msk_valid;i++)
					{
						if(sm_key_msk&(1<<i))
						{
								
						}
						else
						{
								stop_idx=i-1;
								break;
						}
					}
					
					if(stop_idx==UNVALID)
						stop_idx=i-1;
					
					if(stop_idx!=(start_idx+key_msk_valid-1))
						start_idx=KEY_NUM+stop_idx+1-key_msk_valid;
				break;
		}
				
		if(start_idx==stop_idx)
		{
			gOscAngel=0;
			
			if(gRotate>1)
			{
				CalcSmStepPosObj_BaseRodateValue(gRotate);
				
				AngelUpdateHubAngelLedSmPos();
				return;
			}
			
			pos_obj_start=SmStepPosIdxNow+CUT_45*start_idx;
			if(pos_obj_start>=SM_KEY_POS_MAX)
				pos_obj_start-=SM_KEY_POS_MAX;
			SmStepPosIdxObjStart=SmStepPosIdxObjStop=pos_obj_start;
			
			pos_obj_start=SM_KEY_POS_PRA*CUT_45*start_idx;
			pos_obj_start+=SmStepPosNow;
			if(pos_obj_start>=STEPS_FULL_CIRCLE)
				pos_obj_start-=STEPS_FULL_CIRCLE;
			SmStepPosObjStop=SmStepPosObjStart=pos_obj_start;
			
			AngelUpdateHubAngelLedSmPos();
			return;
		}
		else 
		{
			gWindDirection=DEFAULT_WIND_DIRECTION;
			
			pos_obj_start=SmStepPosIdxNow+CUT_45*start_idx;
			if(pos_obj_start>=SM_KEY_POS_MAX)
				pos_obj_start-=SM_KEY_POS_MAX;
			if(pos_obj_start>=CUT_45/2)
				pos_obj_start-=CUT_45/2;
			else
				pos_obj_start=SM_KEY_POS_MAX+pos_obj_start-CUT_45/2;
			SmStepPosIdxObjStart=pos_obj_start;
			
			pos_obj_stop=SmStepPosIdxNow+CUT_45*stop_idx;
			pos_obj_stop+=CUT_45/2;
			if(pos_obj_stop>=SM_KEY_POS_MAX)
				pos_obj_stop-=SM_KEY_POS_MAX;
			SmStepPosIdxObjStop=pos_obj_stop;
			
			pos_obj_start=SM_KEY_POS_PRA*CUT_45*start_idx;
			pos_obj_start+=SmStepPosNow;
			if(pos_obj_start>=SM_KEY_POS_PRA*CUT_45/2)
				pos_obj_start-=SM_KEY_POS_PRA*CUT_45/2;
			else
				pos_obj_start=STEPS_FULL_CIRCLE+pos_obj_start-SM_KEY_POS_PRA*CUT_45/2;
			if(pos_obj_start>=STEPS_FULL_CIRCLE)
			{
				pos_obj_start-=STEPS_FULL_CIRCLE;
			}
		
			pos_obj_stop=SM_KEY_POS_PRA*CUT_45*stop_idx;
			pos_obj_stop+=SmStepPosNow;
			pos_obj_stop+=SM_KEY_POS_PRA*CUT_45/2;
			if(pos_obj_stop>=STEPS_FULL_CIRCLE)
			{
				pos_obj_stop-=STEPS_FULL_CIRCLE;
			}
			if(pos_obj_stop)
				pos_obj_stop-=1;
			else
				pos_obj_stop=STEPS_FULL_CIRCLE;
			
			SmStepPosObjStart=pos_obj_start;
			SmStepPosObjStop=pos_obj_stop;
			
			AngelUpdateHubAngelLedSmPos();
			return;
		}
}

void CalcSmStepPosObjBaseOnExactAngel(uint32_t angel)		
{
		uint32_t tmp;
	
		bForceUse_bHubWindDirection180_SmDirClockwise=false;
		bHubRotate_OneCircle=0;
	
		if(!angel)
		{
			SmStepPosObjStart=SmStepPosObjStop=SmStepPosNow;
			AngelUpdateHubAngelLedSmPos();
			return;
		}
				
		tmp=angel;
		tmp*=STEPS_UNIT_PER_ANGEL;
		tmp/=2;
		
		SmStepPosObjStop=SmStepPosNow+tmp;
		if(SmStepPosObjStop>=STEPS_FULL_CIRCLE)
			SmStepPosObjStop-=STEPS_FULL_CIRCLE;
		
		tmp-=1;
		if(SmStepPosNow>=tmp)
			SmStepPosObjStart=SmStepPosNow-tmp;
		else
			SmStepPosObjStart=SmStepPosNow+STEPS_FULL_CIRCLE-tmp;
		
		AngelUpdateHubAngelLedSmPos();
}


void CalcSmStepPosObjFromApp(uint32_t sm_key_msk)		
{
		uint8_t start_idx=UNVALID;
		uint8_t stop_idx=UNVALID;
		uint8_t i=0;
		uint16_t pos_obj_start;
		uint16_t pos_obj_stop;
		uint8_t key_msk_valid=0;		//������Чλ����Ŀ
	
		bool b360=false;
	
		bForceUse_bHubWindDirection180_SmDirClockwise=false;
		bHubRotate_OneCircle=0;
		
		if(!sm_key_msk)
			return;
				
		for(i=0;i<32;i++)
		{
				if(sm_key_msk&(1<<i))
				{
						key_msk_valid+=1;
				}
		}
		
		for(i=0;i<32;i++)
		{
				if(sm_key_msk&(1<<i))
				{
						start_idx=i;
						break;
				}
		}
		i++;
		
		switch(key_msk_valid)
		{
				case 1:
						stop_idx=start_idx;
					if(stop_idx==16)	//180°
						bForceUse_bHubWindDirection180_SmDirClockwise=true;
				break;
				
				case 32:
					stop_idx=start_idx=16;
					b360=true;
				break;
				
				default:
						for(;i<start_idx+key_msk_valid;i++)
						{
								if(sm_key_msk&(1<<i))
								{
										
								}
								else
								{
										stop_idx=i-1;
										break;
								}
						}
						
						if(stop_idx==UNVALID)
								stop_idx=i-1;
						
						
						
						if(stop_idx!=(start_idx+key_msk_valid-1))
								start_idx=32+stop_idx+1-key_msk_valid;
				break;
		}
				
		if(start_idx==stop_idx)
		{
			pos_obj_start=SmStepPosIdxNow+start_idx;
			if(pos_obj_start>=SM_KEY_POS_MAX)
				pos_obj_start-=SM_KEY_POS_MAX;
			SmStepPosIdxObjStart=SmStepPosIdxObjStop=pos_obj_start;
			
			pos_obj_start=SM_KEY_POS_PRA*start_idx;
			pos_obj_start+=SmStepPosNow;
			if(pos_obj_start>=STEPS_FULL_CIRCLE)
				pos_obj_start-=STEPS_FULL_CIRCLE;
			
			if(b360)
			{
				
				SmStepPosObjStart=pos_obj_start;
				
				if(SmStepPosObjStart)
					SmStepPosObjStop=SmStepPosObjStart-1;
				else
					SmStepPosObjStop=STEPS_FULL_CIRCLE;
				
				AngelUpdateHubAngelLedSmPos();
				return;
			}
			
			
			
			
			
			
			SmStepPosObjStop=SmStepPosObjStart=pos_obj_start;
			
			AngelUpdateHubAngelLedSmPos();
			return;
			
		}
		else 
		{
			pos_obj_start=SmStepPosIdxNow+start_idx;
			if(pos_obj_start>=SM_KEY_POS_MAX)
				pos_obj_start-=SM_KEY_POS_MAX;
			SmStepPosIdxObjStart=pos_obj_start;
			
			pos_obj_stop=SmStepPosIdxNow+stop_idx;
			if(pos_obj_stop>=SM_KEY_POS_MAX)
				pos_obj_stop-=SM_KEY_POS_MAX;
			SmStepPosIdxObjStop=pos_obj_stop;
			
				pos_obj_start=SM_KEY_POS_PRA*SmStepPosIdxObjStart;
				pos_obj_stop=SM_KEY_POS_PRA*SmStepPosIdxObjStop;
			
				if(pos_obj_stop)
					pos_obj_stop-=1;
				else
					pos_obj_stop=STEPS_FULL_CIRCLE;
				
				SmStepPosObjStart=pos_obj_start;
				SmStepPosObjStop=pos_obj_stop;
				
				AngelUpdateHubAngelLedSmPos();
				return;
		}
		
}

void SmDrive(uint8_t phase)		//�����������0�ر� 1-8���
{
#ifdef SM_DEBUG	
		if(0)
#else
		if(phase)
#endif
		{
				if(PHASE_TAB[phase-1] & 1)
						PHASE_D_ON;
				else
						PHASE_D_OFF;
						
				if(PHASE_TAB[phase-1] & 2)
						PHASE_C_ON;
				else
						PHASE_C_OFF;
						
				if(PHASE_TAB[phase-1] & 4)
						PHASE_B_ON;
				else
						PHASE_B_OFF;
						
				if(PHASE_TAB[phase-1] & 8)
						PHASE_A_ON;
				else
						PHASE_A_OFF;
		}
		else
		{
				PHASE_A_OFF;
				PHASE_B_OFF;
				PHASE_C_OFF;
				PHASE_D_OFF;
		}
}

void SmDirCk_StartEqualStop()		//��������ж�
{
		uint16_t temp;
		
		if(!SmEnable)			//���δʹ��״̬��ֱ�ӷ���
				return;
		
		if(bForceUse_bHubWindDirection180_SmDirClockwise)
		{
			SmClockwise=bHubWindDirection180_SmDirClockwise;
			return;
		}
				
		if(SmStepPosObjStop>SmStepPosNow)
		{
				temp=SmStepPosObjStop-SmStepPosNow;
				if(temp>STEPS_HALF_CIRCLE)
				{
						SmClockwise=0;
				}
				else
				{
						SmClockwise=1;
				}
		}
		else if(SmStepPosObjStop<SmStepPosNow)
		{
				temp=SmStepPosNow-SmStepPosObjStop;
				if(temp>STEPS_HALF_CIRCLE)
				{
						SmClockwise=1;
				}
				else
				{
						SmClockwise=0;
				}
		}
//		else
//			SmClockwise=bHubWindDirection180_SmDirClockwise;
}
void SmDirCk_StartBiggerThanStop()		//��������ж�
{
		uint16_t temp;
		
		if(!SmEnable)			//���δʹ��״̬��ֱ�ӷ���
				return;
		
		if(gRotate>1)
		{
			if(gRotate==2)
				SmClockwise=1;
			else if(gRotate==2)
				SmClockwise=0;
			else
				SmClockwise=bSmClockwise_LocalAllAngelKeyEn;
			return;
		}
			
		if(SmStepPosNow>SmStepPosObjStop && SmStepPosNow<SmStepPosObjStart)
		{
			if(SmStepPosNow-SmStepPosObjStop >= SmStepPosObjStart-SmStepPosNow)
				SmClockwise=1;
			else
				SmClockwise=0;
		}
		else
		{
			if(SmClockwise)
			{
				if(SmStepPosNow==SmStepPosObjStop)
					SmClockwise=0;
			}
			else
			{
				if(SmStepPosNow==SmStepPosObjStart)
					SmClockwise=1;
			}
		}
}
void SmDirCk_StartSmallerThanStop()		//��������ж�
{
		uint16_t temp;
		
		if(!SmEnable)			//���δʹ��״̬��ֱ�ӷ���
				return;
		
		if(gRotate>1)
		{
			if(gRotate==2)
				SmClockwise=1;
			else if(gRotate==2)
				SmClockwise=0;
			else
				SmClockwise=bSmClockwise_LocalAllAngelKeyEn;
			return;
		}
			
		if(SmStepPosNow<SmStepPosObjStart || SmStepPosNow>SmStepPosObjStop)
		{
				if(SmStepPosNow<SmStepPosObjStart)
				{
						if(SmStepPosObjStart-SmStepPosNow >= STEPS_FULL_CIRCLE+SmStepPosNow-SmStepPosObjStop)
								SmClockwise=0;
						else
								SmClockwise=1;
				}
				else
				{
						if(SmStepPosNow-SmStepPosObjStop >= STEPS_FULL_CIRCLE+SmStepPosNow-SmStepPosObjStart)
								SmClockwise=1;
						else
								SmClockwise=0;
				}
				
		}
		else
		{
				if(SmClockwise)
				{
						if(SmStepPosNow==SmStepPosObjStop)
								SmClockwise=0;
				}
				else
				{
						if(SmStepPosNow==SmStepPosObjStart)
								SmClockwise=1;
				}
		}
}
void SmDirCk_Initial()		//֧ܺ׽вƐ׏
{
	SmClockwise=0;
}

u8 SmTestFullSteps=0;
u16 SmFullSteps=0;



u16 SmStepForLedFadeDownUseTotal=0;
u16 SmStepForLedFadeDownUseNow=0;

void CalcSmStepForLedFadeDownUseTotal()
{
	if(SmStepPosObjStart>=SmStepPosObjStop)
	{
		SmStepForLedFadeDownUseTotal=STEPS_FULL_CIRCLE+SmStepPosObjStop-SmStepPosObjStart;
	}
	else
	{
		SmStepForLedFadeDownUseTotal=SmStepPosObjStop-SmStepPosObjStart;
	}
}
void UpdateSmStepForLedFadeDownUseNow()
{
	if(SmStepPosObjStart>=SmStepPosObjStop)
	{
		if(SmStepPosNow>=SmStepPosObjStart || SmStepPosNow<=SmStepPosObjStop)
			if(SmStepForLedFadeDownUseNow<SmStepForLedFadeDownUseTotal)
				SmStepForLedFadeDownUseNow++;
	}
	else
	{
		if(SmStepPosNow>=SmStepPosObjStart && SmStepPosNow<=SmStepPosObjStop)
			if(SmStepForLedFadeDownUseNow<SmStepForLedFadeDownUseTotal)
				SmStepForLedFadeDownUseNow++;
	}
}

bool CkSmStepForLedFadeDown()
{
	if(SmStepForLedFadeDownUseNow>=SmStepForLedFadeDownUseTotal)
		return true;
	else
		return false;
}

void SmRunHandle()
{
	static u8 run=0;
	
	if(!SmInitDone)
	{
#ifdef SM_DEBUG		
//		#if 1
		SmInitDone=1;
		UpdateSmKeyPosTab(SmStepPosNow=0);
		SmStepPosObjStart=SmStepPosObjStop=SmStepPosNow;
		SmRun=0;
		return;
#endif		
		PA0=1;
		
		SmDirCk_Initial();
		
		if(SmRun)
		{
			if(++SmSpeedPra>=SM_SPPED_PRA)
			{
				SmSpeedPra=0;
				if(SmClockwise)
				{
					SmPhase++;
					if(SmPhase>8)
						SmPhase=1;
				}
				else
				{
					if(SmPhase>1)
						SmPhase--;
					else
						SmPhase=8;
				}
				
				if(PF15)
				{
					SmInitDone=1;
					UpdateSmKeyPosTab(SmStepPosNow=0);
					SmStepPosObjStart=SmStepPosObjStop=SmStepPosNow;
					SmRun=0;
				}
			}
		}
				
		if(!SmInitDone)
		{
			SmRun=1;	
		}
		
		if(SmRun)
			SmDrive(SmPhase);
		else
			SmDrive(0);
		
		return;
	}
	
	if(SmTestFullSteps)
	{
		PA0=1;
		
		SmClockwise=1;
		
		if(SmRun)
		{
			if(++SmSpeedPra>=SM_SPPED_PRA)
			{
				SmSpeedPra=0;
				if(SmClockwise)
				{
					SmPhase++;
					if(SmPhase>8)
						SmPhase=1;
				}
				else
				{
					if(SmPhase>1)
						SmPhase--;
					else
						SmPhase=8;
				}
				
				SmFullSteps++;
				
				if(PF15 && SmFullSteps>=1019)
				{
					SmTestFullSteps=0;
					UpdateSmKeyPosTab(SmStepPosNow=SM_KEY_POS_PRA);
					SmStepPosObjStart=SmStepPosObjStop=SmStepPosNow;
					SmRun=0;
				}
			}
		}
				
		if(SmTestFullSteps)
		{
			SmRun=1;	
		}
		
		if(SmRun)
			SmDrive(SmPhase);
		else
			SmDrive(0);
		
		return;
	}
	
		if(SmStepPosObjStart==SmStepPosObjStop)
		{
				if(SmRun)
				{
						run=1;
					
					if(++SmSpeedPra>=SM_SPPED_PRA)
						{
								SmSpeedPra=0;
							
							SmDirCk_StartEqualStop();
							
								if(SmClockwise)
								{
										SmPhase++;
										if(SmPhase>8)
												SmPhase=1;
												
										SmStepPosNow++;
										if(SmStepPosNow>=STEPS_FULL_CIRCLE)
												SmStepPosNow=0;
										UpdateSmKeyPosTab(SmStepPosNow);
								}
								else
								{
										if(SmPhase>1)
												SmPhase--;
										else
												SmPhase=8;
												
										if(SmStepPosNow)
												SmStepPosNow--;
										else
												SmStepPosNow=STEPS_FULL_CIRCLE;
										UpdateSmKeyPosTab(SmStepPosNow);
								}
								
								if(!SmEnable)
										SmRun=0;
						}
				}
				
				if(SmStepPosObjStop!=SmStepPosNow)
				{
						if(SmEnable)
								SmRun=1;
				}
				else
				{
						SmRun=0;
						if(!HubGetAngleSetTicks() && (gWindDirection!=DEFAULT_WIND_DIRECTION) && run)
						{
							run=0;
							gWindDirection=DEFAULT_WIND_DIRECTION;
//							HubAlexa_SendChangeReportDueToLocalControl();
						}
				}
				
				if(SmRun)
						SmDrive(SmPhase);
				else
						SmDrive(0);
		}
		else if(SmStepPosObjStart>SmStepPosObjStop)
		{
				CalcSmStepForLedFadeDownUseTotal();
				
				if(SmRun)
				{
						if(++SmSpeedPra>=SM_SPPED_PRA)
						{
								SmSpeedPra=0;
							
								SmDirCk_StartBiggerThanStop();
							
								if(SmClockwise)
								{
										SmPhase++;
										if(SmPhase>8)
												SmPhase=1;
												
										SmStepPosNow++;
										
										
										if(SmStepPosNow>=STEPS_FULL_CIRCLE)
												SmStepPosNow=0;
										UpdateSmKeyPosTab(SmStepPosNow);
								}
								else
								{
										if(SmPhase>1)
												SmPhase--;
										else
												SmPhase=8;
												
										if(SmStepPosNow)
												SmStepPosNow--;
										else
												SmStepPosNow=STEPS_FULL_CIRCLE-1;
										UpdateSmKeyPosTab(SmStepPosNow);
								}
								
								UpdateSmStepForLedFadeDownUseNow();
								
//								if(gRotate>1 && (SmStepPosNow==SmStepPosObjStop))
//									bHubRotate_OneCircle=true;
								
								if(CkSmStepForLedFadeDown() && ((SmClockwise && (SmStepPosNow==SmStepPosObjStop)) || (!SmClockwise && (SmStepPosNow==SmStepPosObjStop))))
									bHubRotate_OneCircle=true;
									
								
								if(!SmEnable)
										SmRun=0;
						}
				}
				
				if(SmEnable)
					SmRun=1;
				
				if(SmRun)
						SmDrive(SmPhase);
				else
						SmDrive(0);
		}
		else 
		{
				CalcSmStepForLedFadeDownUseTotal();
			
				if(SmRun)
				{
						if(++SmSpeedPra>=SM_SPPED_PRA)
						{
								SmSpeedPra=0;
							
							SmDirCk_StartSmallerThanStop();
							
								if(SmClockwise)
								{
										SmPhase++;
										if(SmPhase>8)
												SmPhase=1;
												
										SmStepPosNow++;
										if(SmStepPosNow>=STEPS_FULL_CIRCLE)
												SmStepPosNow=0;
										UpdateSmKeyPosTab(SmStepPosNow);
								}
								else
								{
										if(SmPhase>1)
												SmPhase--;
										else
												SmPhase=8;
												
										if(SmStepPosNow)
												SmStepPosNow--;
										else
												SmStepPosNow=STEPS_FULL_CIRCLE-1;
										UpdateSmKeyPosTab(SmStepPosNow);
								}
								
								UpdateSmStepForLedFadeDownUseNow();
								
								if(CkSmStepForLedFadeDown() && ((SmClockwise && (SmStepPosNow==SmStepPosObjStop)) || (!SmClockwise && (SmStepPosNow==SmStepPosObjStop))))
									bHubRotate_OneCircle=true;
								
//								if(gRotate>1 && (SmStepPosNow==SmStepPosObjStop))
//									bHubRotate_OneCircle=true;
								
								if(!SmEnable)
										SmRun=0;
						}
				}
				
				
				if(SmEnable)
					SmRun=1;
				
				if(SmRun)
						SmDrive(SmPhase);
				else
						SmDrive(0);
		}
}

